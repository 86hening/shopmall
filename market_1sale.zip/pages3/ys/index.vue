<template>
	<view class="cbody">
		<u-navbar back-text="返回" title="商品预售" :border-bottom="false" back-icon-color="#FFFFFF" :back-text-style="{color:'#FFFFFF'}" title-color="#FFFFFF" :background="background"></u-navbar>
		 
			<view class="memubox">
				<u-tabs name="tname" :list="cate_menu" active-color="#FFFFFF" bold="false" font-size="32" inactive-color="#FFFFFF" bg-color="#fa3534"  :gutter="10" :duration="0.2" :is-scroll="true" :current="current_num" @change="change"></u-tabs>
			</view>		
	
			<view class="ttbox">
				<!-- <text class="ptitle">新品上市，火爆预售中</text> -->
			</view>
		 
 
		<view class="pro_box">
			<ul>
				<li v-for="(item,index) in product_list" :key="index">
					<view class="left_pic"><img :src="item.thum" @click="show_other_pro('ys',item.shop_id,item.id)"><view class="fdata">{{item.atimes_str}}</view></view>
					<view class="right_con">
						<view class="title" @click="show_other_pro('ys',item.shop_id,item.id)">{{item.product_name}}</view>
						<view class="ctitl"><text class="price">订金:￥{{item.presell_price}}</text> <text class="rvpric">售价:￥{{item.retail_price}}</text></view> 
						<view class="tip_box">
							<view style="width:98%;">
						       <u-line-progress active-color="#fa3534" :striped="true" :percent="item.process" height="20" :show-percent="true"></u-line-progress>
						    </view>
						</view>
						<view class="acbox">
						    <view class="price"> </view>
						    <view class="btn_box" @click="buy_now(item)"><view class="btn">立即下单</view></view>
						    <view class="clear"></view>
						</view>
					</view>
					<view class="clear"></view>
				</li>				 
			</ul>
		</view>
		
		
		<view class="footer_positon">
		<foot_bar ></foot_bar>
		</view>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	export default {
		components: {
			foot_bar
		 },
		data() {
			return {
				top_pic:'',				 
				current_num: 0,				 
				product_list:'',
				cate_menu:{},//滚动分类
				background: {
					backgroundColor: '#fa3534',
					// 渐变色
					// backgroundImage: 'linear-gradient(45deg, rgb(28, 187, 180), rgb(141, 198, 63))'
				}
			}
		},
		onLoad() {
			
			this._get_cate_menu() //幻灯上滑动分类
			 this._get_product()
		},
		mounted() {
			 
		},
 
		methods: {
			async _get_cate_menu () { //幻灯上滑动分类
				const res = await this.$AjaxRequest_product({
					url: 'category',
					method:'post',
					data:{value_data:{'is_index':1}}  //
				})
				this.cate_menu = res.data
			},
			show_other_pro(type,shop_id,product_id){ //详情页面
				uni.navigateTo({
				   url: '/pages3/show_product/index?type='+type+'&shop_id='+shop_id+'&id='+product_id
				})
			},
			buy_now(item){
			    let  buy_str =  item.shop_id+'|'+item.id+'|1|0|'+ item.presell_price
				uni.navigateTo({
				    url: '/pages/shop_cart/ac_buy?type=ys&buy_str='+buy_str
				})
			},
			 
			async _get_product(){
				const res = await this.$AjaxRequest_product({
					url: 'get_ys_list',
					method:'post',
					 data:{value_data:{}}  //
				})
 				this.product_list = res.data
			},
			change(index){ //Tab切换			
				 console.log(index)
			 
				this.current = index;
			}
		}
	}
</script>

<style  scoped>
 
	.fdata{width: 250rpx;height: 60rpx;background-color: rgba(0, 0, 0,0.5);position: relative;top:-70rpx;left:5rpx;text-align: center;color:#FFFFFF;line-height: 60rpx;}
	.rvpric{float: right;}
	.btn{width: 160rpx;height: 50rpx;background: #fa3534;text-align: center;color:#ffffff;font-size:26rpx;line-height:50rpx;border-radius:40rpx;margin:0 auto;}
	.btn_box{width: 40%;height: 80rpx;float:right;text-align: right;}
	.price{font-size: 32rpx;color:#fa3534;font-weight: 700;}
	.ctitl{width: 100%;height:50rpx;font-size:32rpx;margin-top: 15rpx;}
	.cprice{color:#ddd;font-size: 24rpx;text-decoration:line-through;font-weight: normal;margin-left:20rpx;}
	.acbox{width: 100%;height: 60rpx;}
    .tip_box{width:60%;height:40rpx;}
	.title{width: 100%;height:60rpx;line-height:60rpx;font-size:32rpx;color:#666; text-overflow: -o-ellipsis-lastline;overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp:1; line-clamp:1; -webkit-box-orient: vertical;}
	.right_con{width: 410rpx;height: 240rpx;float: right;margin-right: 10rpx;;}
	
	.left_pic img{width:250rpx;height:210rpx;margin-top:15rpx;border-radius: 10rpx;}
	.left_pic{width: 260rpx;height: 240rpx;float: left;margin-left: 10rpx;text-align: center;}
	.pro_box li{width: 700rpx;height:245rpx;background-color: #FFFFFF;margin-bottom: 30rpx;border-radius: 20rpx;border:2rpx #F2F2F2 solid;border-bottom:8rpx solid #f2f2f2}
	.pro_box{width:700rpx;height: auto;margin:0 auto; padding-bottom:100rpx;position: absolute;top:220rpx;left:25rpx;}
	.ptitle{margin-left:40rpx;}
	.ttbox{width: 100%;height:150rpx;background-color: #fa3534;font-weight: 650;color:#FFFFFF;font-size:36rpx; padding-top:50rpx;border-bottom-left-radius:60rpx;border-bottom-right-radius: 60rpx;;}
	.memubox{width: 100%;height: 80rpx;background-color: #fa3534;}
	
	.tt_ocon{width: 100%;height: auto;position: absolute;z-index: -1;}
	
	.footer_positon{position: absolute;bottom: 0;z-index: 9999;}
	 
 
</style>
