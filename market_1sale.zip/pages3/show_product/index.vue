<template>
	  <view>		  
		  <u-navbar back-text="返回" :title="bar_title"></u-navbar>
		  
		  <view class="content">
			 <view class="head_slide">
			 	<u-swiper :list="product_info.slide" name="item" height="560" bg-color="#ffffff" img-mode="aspectFit" mode="dot" ></u-swiper>
			  </view>
			   
			   
			   <view class="price_box"  v-if="product_info.type == 'ys'">
			      <view class="price_left">
					  <view class="presell_price">
						  <text class="tips">订金:</text>￥{{product_info.presell_price}} 
					      <text class="retail_price">售价:￥{{product_info.retail_price}}</text>
					  </view>
					  
					  </view>
				  <view class="price_right">
					  <view class="price_right_top">已售数量：{{product_info.presell_buy_num}} 件</view>
					  <view class="price_right_times">截至日期：{{product_info.presell_ftime}}</view>
					  </view>
				  <view class="clear"></view>
			   </view>
			   
			   <view class="price_act"  v-if="product_info.type == 'act'">
				   <view class="price_left">
				   		<view class="activity_price">
				   			<text class="tips">售价:</text>￥{{product_info.activity_price}} 
				   			<text class="cost_price">￥{{product_info.cost_price}}</text>
				   		</view>				   					  
				   </view>
				   <view class="price_right">
				   		<view class="price_right_top">已售数量：{{product_info.activity_buy}} 件</view>
				   		<view class="price_right_times">剩余数量：{{product_info.kc_num}} 件</view>
				   </view>
				   <view class="clear"></view>
			   </view>
		 
			   	 <!---->
			   	   <view class="pro_title" v-if="product_info.product_name != undefined ">{{product_info.product_name}}</view>
			   	 <!---->
			   	  <view class="pro_description" v-if="product_info.notice != undefined ">{{product_info.notice}}</view>
			   	<!---->
				<view class="press_tag" v-if="product_info.type == 'ys'">
					 <u-icon name="info-circle" color="#fa3534" size="28" class="it_ico"></u-icon>
					   本品为预售商品，支付订金后{{product_info.final_pay_stime}}至{{product_info.final_pay_etime}}为尾款支付期，请在该期间内及时支付尾款以便及时发货！
				</view> 
				
			<view class="box2">
				<view class="box2_a">
					<view class="box2_a_left">
						  <view class="logo_pic" v-if="shop_info.shop_pic != undefined "><img  :src="shop_info.shop_pic"></view>
					</view>
					<view class="box2_a_right" v-if="shop_info.shop_name != undefined ">
								   <ul>
									   <li><i class="iconfont icon-store"/> {{shop_info.shop_name}}</li>
									   <li><i class="iconfont icon-map"/> {{shop_info.address}}</li>
									   <li><i class="iconfont icon-mobile-phone"/> {{shop_info.contact_tel}}</li>
								   </ul>
					</view>
					<view class="clear"></view>
				</view>
				<view class="box2_b">
								 <ul>
									 <li>商品总数<br>{{shop_info.product_total}}</li>
									 <li>订单总数<br>{{shop_info.order_total}}</li>
									 <li>收藏本店<br>{{shop_info.fav_num}}</li>
								  </ul>
								<view class="clear"></view>
						   </view>
						   <view class="box2_c">
							   <view class="box2_c_left" :class="active_shop_style" @click="shop_fav(active_shop_style,shop_info.id,shop_info.fav_num)" ><u-icon name="grid"></u-icon>收藏本店</view>
								<view class="box2_c_right" @click="shop_url(shop_info.id)"><u-icon name="shopping-cart"></u-icon>逛逛本店</view>
							   <view class="clear"></view>
						   </view>
					</view>
					<!---->
					
					<!---->
					<view class="box3">
						<view class="box3_title">
 							<u-section title="推荐商品"  sub-title="" :arrow="false" :right="false"></u-section>
						 </view>
								   <view class="box3_con">
									   <ul>
										   <li v-for="(item,index) in shop_product" :key="index" @click="show_produt(item)">
											   <view class="box3_con_pic"><img :src="item.thum"></view>
											   <view class="box3_con_title">{{item.product_name}}</view>
											   <view class="box3_con_price">￥ {{item.retail_price}}  </view>
										   </li>
					
										   <view class="clear"></view>
									   </ul>
								   </view>
							   </view>
							   <!---->
				<view class="box4">
					<view class="box4_title">
						<u-section title="商品详情" sub-title="" :arrow="false" :right="false"></u-section>
					 </view>
					<view class="content_box" >
						<view  v-for="(item2,index2) in product_info.content_pic" :key="index2">
							 <u-image :src="item2" mode="widthFix"></u-image>
						</view>
						
					</view>
				</view>
				
		  </view>
		   <!---->
		    <view class="navigation">
		    	<view class="left">		    		
		    		<view class="item" @click="home">
		    			<u-icon name="home" :size="40" :color="$u.color['contentColor']"></u-icon>
		    			<view class="text u-line-1">首页</view>
		    		</view>
					<view class="item">
 						<u-icon name="kefu-ermai" :size="40" :color="$u.color['contentColor']" ></u-icon>
						<view class="text u-line-1">客服</view>
					</view>
		    		<view class="item car" @click="shop_cart()">
		    			<u-badge class="car-num" :count="count" type="error" :offset="[-3, -6]"></u-badge>
		    			<u-icon name="shopping-cart" :size="40" :color="$u.color['contentColor']"></u-icon>
		    			<view class="text u-line-1">购物车</view>
		    		</view>
		    	</view>
		    	<view class="right">
 		    		<view class="buy btn u-line-1" @click="buy_now(product_info)">立即下单</view>
		    	</view>
		   				</view>	
		   <!---->
		   
		    <u-toast ref="uToast" />
			<u-modal v-model="show_model" :show-title="false" :content="content" @confirm="confirm"></u-modal>
	 </view>
</template>

<script>
	//#ifdef H5
	 let jweixin = require('jweixin-module');
	//#endif
	export default {
		data(){
			return {
				product_info:'',
				query_String : '',
				count:0 || this.$store.getters.Shop_nums,
				shop_info:'',
				shop_product:'',
				wx_user_info:'',
				product_content:'',
				active_shop_style:'active_1',
				wxapp_openid : '',
				shop_coupons :'',
				show: false,
				show_model:false,
				content:'',
				show_share:false,
				bar_title:'商品详情',
 			}
		},
		created() {		 
		   //console.log(this.$store.getters.Shop_nums)
		},
		onLoad(options) {
			
			this.query_String = options	 
			if(this.query_String.type == 'tg'){
				this.bar_title = '拼团商品'
			}else if(this.query_String.type == 'ys'){
				this.bar_title = '预售商品'
			}else if(this.query_String.type == 'act'){
				this.bar_title = '活动商品'
			}					 
			
 			//微信公众号
			//#ifdef H5 			
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }	
				 this._get_product(this.$store.getters.get_wx_user.openid) //获取单品
				 this._get_shop_coupon(this.query_String.shop_id,this.$store.getters.get_wx_user.openid)	
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}					 
			    }else{ //登陆后检测手机状态				
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				this._get_product(this.$store.getters.get_ali_user.user_id) //获取用户地址列表
				this._get_shop_coupon(this.query_String.shop_id,this.$store.getters.get_ali_user.user_id)
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	
 			 this._get_product(this.$store.getters.get_wxapp_openid) //获取用户地址列表
			 this._get_shop_coupon(this.query_String.shop_id,this.$store.getters.get_wxapp_openid)
			//#endif			
			 	
		    this._get_product_select() //获取推荐商品  
		},
		methods:{
			async _get_shop_coupon (shop_id,openid) { //获取本店卡券			  
			    //#ifdef MP-WEIXIN
			      let value = {'shop_id':shop_id,'wxapp_openid':openid}
			      //#endif
			      //#ifdef H5
				  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				  	 let value = {'shop_id':shop_id,'wx_openid':openid}			 
				  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				  	 let value = {'shop_id':shop_id,'ali_openid':openid}			 			 
				  }			     
			      //#endif
				const res = await this.$AjaxRequest({
					url: 'get_coupon',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {
  					 this.shop_coupons =  res.data 
 				}) 
			},			
			buy_now(item){//立即购买
			    let type
                 let  price
                 if(item.type == 'act'){
                      type = 'act'
                     price = item.activity_price
                 }else if(item.type == 'tg'){
                     type = 'tg'
                     price = item.tg_price
                }else if(item.type == 'ys'){
                      type='ys'
                     price = item.presell_price
                 }
                let  buy_str =  item.shop_id+'|'+item.id+'|1|0| '+price				
 				uni.navigateTo({
				    url: '/pages/shop_cart/ac_buy?type='+type+'&buy_str='+buy_str,			
				})
			},
			home(){//跳转首页
				uni.switchTab({
				    url: '/pages/index/index'
				})
			},
			change(e) { //焦点图片切换
				this.current = e.detail.current;
			},
			//#ifdef H5		 
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },
				async _wx_get_code(){ //获取code
				   const res_wx = await this.$AjaxRequest({
					url: '/get_config',
					method:'POST',
					data:{value_data:{}}
				   })	
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					 window.location.href = auth_get_code_url
				},				 
			//#endif
			async _get_product (openid) { //获取单品信息
				 //#ifdef H5
				      let value
					  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
						value  = {'type':this.query_String.type,'shop_id':this.query_String.shop_id,'id':this.query_String.id,'wx_openid':openid}		 
					  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						value = {'type':this.query_String.type,'shop_id':this.query_String.shop_id,'id':this.query_String.id,'ali_openid':openid}					 
					  }
				 //#endif
				 //#ifdef MP-WEIXIN
				     let value = {'type':this.query_String.type,'shop_id':this.query_String.shop_id,'id':this.query_String.id,'wxapp_openid':openid}
				 //#endif				  
				let res2 = await this.$AjaxRequest_product({
					url: 'product_find',
					method:'post',
					data:{value_data:value}  //
				}) 				 
			     this.product_info = res2.data				
 			     this.shop_info =  res2.data.shop_info
			},			
	 			
			async _get_product_select(){ //获取推荐商品
				 const res = await this.$AjaxRequest_product({
					url: 'product_select',
					method:'post',
					data:{value_data:{'type':'nor','shop_id':this.query_String.shop_id,limit:6}}  //
				})
				this.shop_product = res.data
			},
			onClick (e) {
			   uni.showToast({
			     title: `点击${e.content.text}`,
			     icon: 'none'
			    })
			},
			buttonClick (e) {			  
			  this.options[2].info++
		    },
		 
			confirm(){
				this.content = ""
				this.show_model = false
				this.show = false
				let page = getCurrentPages().pop(); //跳转页面成功之后
 				uni.navigateTo({
				    url: page.$page.fullPath
				})				 
			},
			//跳转商品详情
			show_produt(item){
				uni.navigateTo({
				    url: '/pages/category/product_show?id='+item.id+'&shop_id='+item.shop_id
				})
			},
			 
		   shop_fav(active_shop_style,shop_id){ //店铺收藏
		   	if(active_shop_style == 'no'){
		           this.active_shop_style = 'active_2';
		       }else{
		           this.active_shop_style = 'active_1';
		       }
		   	//#ifdef MP-WEIXIN
		   	  let value = {'shop_id':shop_id,'wxapp_openid':this.$store.getters.get_wxapp_openid}
		   	//#endif
		   	//#ifdef H5	
				let value 
				if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
					value = {'shop_id':shop_id,'wx_openid':this.$store.getters.get_wx_user.openid}					 
				}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
					value = {'shop_id':shop_id,'ali_openid':this.$store.getters.get_ali_user.user_id}					 			 
				}
		   	//#endif
		   	const res =  this.$AjaxRequest({
		   		url: 'shop_fav',
		   		method:'post',
		   		data:{value_data:value}  //
		   	}).then((res) => {			
		   		console.log(res)
		   		if(res.sta == 'success'){	
		   			if(res.act == '1'){
		                   this.content = "商铺添加收藏成功"
		                   this.show_model = true;                    
		                }else{
		                   this.content = "商铺取消收藏成功"
		                   this.show_model = true;   
		                 }
		   		} 
		   	})			   	
		   },		 
			show_produt(item){ //商品详情
				uni.navigateTo({
				   url: '/pages/product/product_show?id='+item.id+'&shop_id='+item.shop_id
				})
			},
			
			shop_url(shop_id){ //商家首页跳转
				uni.navigateTo({
				   url: '/pages/shop/shop?shop_id='+shop_id
				})
				
			},
			share_wx(item){
				console.log(item)
                 
            },
			
		},
		
	}	
</script>

<style  lang="scss" scoped>
	
	.activity_price{width: 100%;font-weight: 500;color:#FFFFFF;font-size: 44rpx;line-height: 100rpx;color:#FFFFFF;}
	.cost_price{color:#FFFFFF;;font-size: 28rpx;margin-left: 18rpx;text-decoration: line-through;}
	.price_act{width: 100%;height: 100rpx;margin: 0 auto;background-color:#19be6b;}
	
	.it_ico{margin-right: 10rpx;;}
	.press_tag{width: 96%;height: auto;margin-bottom: 10rpx;fonts-size:24rpx;line-height: 48rpx;margin:0 auto;border:2rpx #fa3534 dashed;padding:10rpx;}
	.price_right_times{text-align: right;}
	.price_right_top{margin-top:10rpx;text-align: right;}
	.price_right{width: 41%;height: 100rpx; float: right;margin-right: 1%;line-height:40rpx;font-size: 28rpx;color:#FFFFFF;text-align:left;;}
	
	.retail_price{color:#FFFFFF;;font-size: 28rpx;margin-left: 18rpx;}
	
	.tips{font-size: 24rpx;font-weight: normal;}
	.presell_price{width: 100%;font-weight: 500;color:#FFFFFF;font-size: 44rpx;line-height: 100rpx;color:#FFFF00;}
	.price_left{width: 55%;height: 100rpx;float: left;margin-left:2%;}
	.price_box{width: 100%;height: 100rpx;margin: 0 auto;background-color: #fa3534;}
	
	
	
	.dj_price{font-size: 28rpx;}
	.vsx_price{text-decoration: none;font-weight: none;font-size: 24rpx;margin-left: 20rpx;color:#333;}
	
	.slot-wrap {display: flex;align-items: right;text-align: right;flex: 1;}	
	.axleft{margin-left:90%;float: right;width: 50rpx;}
	
	.head_slide  img{width: 100%;height:100%;}
	.head_slide{width: 100%;height: auto;background: #FFFFFF;}
	.pro_price{width: 100%;height: 100rpx;background: white;}
	.pro_real_price{ width:90%;font-size: 50rpx;color:#ff0000;float: left;padding-left: 5%;font-weight:600;line-height: 100rpx;}
	.col_price{ font-weight: normal;font-size: 28rpx;color:#ccc;text-decoration: line-through;}
	.pro_fav_box{width: 20%;height: 100rpx;float: right;text-align: right;padding-right:3%;}
	.fav_ico{width: 100%;text-align: right;height: 60rpx;}
	.fav_ico i{top:10rpx;}
	.fav_num{width: 100%;height: 40rpx;font-size: 24rpx;}  
	.pro_description{width:98%;color:#999;height: 70rpx;font-size:26rpx;line-height:48rpx;overflow:hidden;padding-right: 3%;padding-left: 3%;background: white;text-overflow: -o-ellipsis-lastline;
		   overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;border-bottom-left-radius: 20rpx;border-bottom-right-radius: 20rpx;padding-bottom:40rpx;padding-top:10rpx;}
		 
	.pro_title{width:98%;margin:0 auto;pading-left:3%;padding-right: 3%;  max-height: 110rpx;height: auto; margin-top: 10rpx;; line-height:50rpx;background: white;font-size: 32rpx;font-weight: 580;text-align: left;text-overflow: -o-ellipsis-lastline;
		   overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
	.box2{width: 96%;height: auto;background: white;border-radius: 30rpx;margin:0 auto;margin-top:20rpx;padding: 2%;}
	.box2_a{ width: 100%;height: 160rpx;}
	 .box2_a_left{ width: 29%;height: 160rpx;float: left;margin-left:1%;text-align: center;}
	 
	.logo_pic{width: 98%;height: 98%;margin:0 auto;overflow: hidden;border-radius: 20rpx;text-align: center;}
	 .logo_pic img{width: 96%;height: 96%;border-radius: 20rpx;}
	 .box2_a_right{width: 68%;height: 160rpx;float: right; margin-right: 2%;}
	 
	    .box2_a_right li{width: 100%;height: 50rpx;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;font-size:30rpx;color:#666;}
	    
	    .box2_b{ width:100%;height: 80rpx;color:#666;font-weight: 600;font-size: 20rpx;margin-top:20rpx;}
	    .box2_b  li{width: 30%;height: 80rpx;float: left;margin-left:1.5%;margin-right: 1.5%;text-align: center;line-height:50rpx;font-size: 28rpx; }
	    .box2_b  li:nth-child(2){border-left:2rpx #f5f5f5 solid;border-right:2rpx #f5f5f5 solid;}
	    .box2_c{width: 100%;height: 100rpx;margin-top:40rpx;color:#333}
	    .box2_c  i{top:4rpx;margin-right:4rpx;}    
	    
	    .box2_c_left{width: 30%;height: 70rpx;float: left; text-align: center;line-height:70rpx;margin-left:15%;border:2rpx #ffa31a solid;color:#ffa31a;border-radius: 360rpx;}
	    .box2_c_right{ width: 30%;height: 70rpx;float: right; text-align: center;line-height:70rpx;margin-right:15%;border:2rpx #fd5332 solid;color:#fd5332;border-radius: 360rpx}
	  
	   .pop_us{width: 100%;min-height: 60%;background: none;background-color:transparent}
	   .pop_us img{width: 100%;height: 60%;}
 
	    .coupon_box{width: 100%;height: 80rpx;background:white;margin-top:20rpx;border-radius: 10rpx;}
	    .coupon_box ul{position: absolute;left: 20rpx;width: calc(98% - 40rpx);height: 80rpx; vertical-align:top;white-space: nowrap;
	         overflow-x:scroll; overflow-y:hidden;-webkit-overflow-scrolling : touch;list-style-type: none;}
	    .coupon_item{height:60rpx;color: white; background: #FF0033;background-image: linear-gradient(to bottom,#ff416c,#ff4b2b,#ff416c); padding-left: 10rpx;padding-left: 10rpx;border-radius:10rpx;}
	    .coupon_box li{font-size:26rpx;margin-right: 20rpx;margin-left:20rpx;margin-top:10rpx;display: inline-block;line-height:60rpx;text-align: center;}
	   .r_crl{width: 8px;height: 16rpx;float: right;margin-left: 10rpx;margin-top:4rpx;border-radius: 360rpx;background:white;margin-right:4rpx;}
	   
	   .coupon_list_box{width: 96%;height: auto;background:white;margin: 0 auto;padding: 20rpx;}
	   .coupon_list_box li{width:750rpx;height:160rpx;border:2rpx #FFCC99 solid;box-shadow: 2rpx 2rpx 2rpx #FF9966;border-radius:6rpx;margin-top:20rpx;}
	   	 .cou_left{width:47%;height:160rpx;float:left;}
	   	 .c_price{width:100%;height:100rpx;line-height:120rpx;text-align:center;font-size:36rpx;color:#FF6666;}
	   	 .c_price_tag{font-size:20rpx;}
	   	 .c_tag{width:100%;height:40rpx;text-align:center;font-size:20rpx;color:#666;}
	   
	   	 .cou_mid{width:30%;height:100rpx;float:left;padding-top: 60rpx;}
	   	 .coup_mid_title{width:90%;height:auto;font-size:60rpx;line-height:120rpx;padding-top: 10%;}
	   	 .coup_mid_time{width:100%;font-size:24rpx;color:#666;margin-left:20rpx;line-height: 50rpx;}
	   	 .cou_line:before{content:"";display:block;width:100%;height:20rpx;background:white;position:relative;top:-10rpx;border-bottom-left-radius:360rpx;border-bottom-right-radius:306rpx;}
	   	 .cou_line{width:3%;height:168rpx;float:left;overflow:hidden;background-image:linear-gradient(to right,#FF9966,#FF6666);;position:relative;top:-2rpx;bottom:-2rpx;}
	   	 .cou_line:after{content:"";display:block;width:100%;height:20rpx;position:relative;top:82%;		background:white;
	   		 border-top-left-radius:360rpx;border-top-right-radius:360rpx;
	          }
	   
	   	 .cou_right{width:20%;height:160rpx;float:right;}
	    	 .lq_btn{width:80%;height:40rpx;background:#FF0033;margin:0 auto;font-size:24rpx;text-align:center;margin-top:40%;border-radius:360rpx;line-height:40rpx;color:#fff;}
	   
	      .yes{color:#ff0000;}
	      .no{color:#999999;}
	   
	    .box4{width:98%;height: auto;background: white;border-radius:30rpx;margin: 0 auto;margin-top:20rpx;margin-bottom:80rpx;}
	      .box4  img{width: 100%;height: auto;}
	      .box4_title{width: 100%;height:auto;line-height: auto;text-align: left;border-bottom:4rpx #f5f5f5 solid;}
	      .box4_title i{top:4rpx;color:#ff0000;margin-right: 10rpx;}
	      .content_box img{width: 98%;height:450rpx;margin: 0 auto;}
	      .content_box{width: 100%;height: auto;min-height: 600rpx;; margin-top:20rpx;padding-bottom: 20rpx;}
	   
	      .box3{width:98%;height: auto;background: white;border-radius: 30rpx;margin: 0 auto;margin-top:20rpx;}
	      .box3_title{width: 100%;height: auto;line-height: auto;border-bottom:4rpx #f5f5f5 solid;}
	       .box3_title i{top:4rpx;color:#ff0000;}
	       .box3_con{width: 100%;height: auto;}
	        .box3_con  li{width: 31.333%;height: 380rpx;float: left;margin-left:1%;margin-right: 1%;}
	        .box3_con_pic{width: 100%;height: 240rpx;text-align: center;}
	         .box3_con_pic  img{width: 90%;height: 90%;margin-top:5%;}
	        .box3_con_title{width: 100%;height: 75rpx;font-size:28rpx;color:#666;overflow: hidden;text-overflow: -o-ellipsis-lastline;
	     overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
	        .box3_con_price{width: 100%;height: 60rpx; color:#ff0000;font-weight:600;font-size: 28rpx;}


     .navigation {
     	display: flex;
     	margin-top: 100rpx;
     	border: solid 2rpx #f2f2f2;
     	background-color: #ffffff;
     	padding: 12rpx 0;
		position: fixed;bottom: 0;	
			width: 100%;
     	.left {
     		display: flex;
     		font-size: 20rpx;
     		.item {
     			margin: 0 36rpx;
     			&.car {
     				text-align: center;
     				position: relative;					
     				.car-num {
     					position: absolute;
     					top: -10rpx;
     					right: -10rpx;
     				}
     			}
     		}
     	}
     	.right {
     		display: flex;
     		font-size: 28rpx;
     		align-items: center;
     		.btn {
     			line-height: 66rpx;
     			padding: 0 30rpx;
     			border-radius: 36rpx;
     			color: #ffffff;				 
     		}     		 
     		.buy {
     			background-color: #ff0000;		
				position: absolute;
				right: 25rpx;
     		}
     	}
     }
	 
	 .coupon_list_box{width: 100%;height: auto;background:white;}
	      .coupon_list_box li{width:100%;height:80px;border:1px #FFCC99 solid;box-shadow: 1px 1px 1px #FF9966;border-radius:3px;margin-top:10px;}
	 	 .cou_left{width:27%;height:80px;float:left;}
	 	 .c_price{width:100%;height:50px;line-height:70px;text-align:center;font-size:28px;color:#FF6666;}
	 	 .c_price_tag{font-size:12px;}
	 	 .c_tag{width:100%;height:20px;text-align:center;font-size:11px;color:#666;}
	 
	 	 .cou_mid{width:50%;height:85px;float:left;}
	 	 .coup_mid_title{width:100%;height:50px;font-size:14px;line-height:60px;}
	 	 .coup_mid_time{width:100%;font-size:12px;color:#666;}
	 	 .cou_line:before{content:"";display:block;width:100%;height:10px;background:white;position:relative;top:-5px;border-bottom-left-radius:180px;border-bottom-right-radius:180px;}
	 	 .cou_line{width:3%;height:84px;float:left;overflow:hidden;background-image:linear-gradient(to right,#FF9966,#FF6666);;position:relative;top:-1px;bottom:-1px;}
	 	 .cou_line:after{content:"";display:block;width:100%;height:10px;position:relative;top:82%;		background:white;
	 		 border-top-left-radius:180px;border-top-right-radius:180px;
	        }
	 
	 	 .cou_right{width:20%;height:80px;float:right;}
	  	 .lq_btn{width:80%;height:20px;background:#FF0033;margin:0 auto;font-size:12px;text-align:center;margin-top:40%;border-radius:180px;line-height:20px;color:#fff;}
		 
</style>
