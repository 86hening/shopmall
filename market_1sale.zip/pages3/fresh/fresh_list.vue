<template>
	<view>
		<u-navbar v-if="_tname == '生鲜商品'" back-text="返回" :title="_tname" back-icon-color="#9bd439" :back-text-style="{color:'#9bd439'}" title-color="#9bd439"  :border-bottom="true" ></u-navbar>
		<u-navbar v-else='' back-text="返回" :title="_tname" back-icon-color="#9bd439" :back-text-style="{color:'#9bd439'}" title-color="#9bd439"  :border-bottom="false" ></u-navbar>
		<view class="menxu"  v-if="product_list != '' ">
			<u-subsection active-color="#9bd439" :list="c_list" :bold="false" mode="subsection" height="80" :current="curNow" @change="sectionChange"></u-subsection>
		</view>
		 <view class="cboxs">
			 <ul>
				 <li v-for="(item,index) in product_list" :key="index">
					 <view class="pics"><u-lazy-load @click="fresh_show(item)" :image="item.thum" img-mode="aspectFill" height="250" border-radius='10'></u-lazy-load></view>
					 <view class="titles">{{item.product_name}}</view>
					 <view class="infos">
						 <view class="prices">￥{{item.retail_price}}</view>
						 <view class="buys">
							 <view class="tbuy" @click="buy(item)"><u-icon name="shopping-cart" color="#ffffff" size="28"></u-icon></view>
						 </view>
						 <view class="clear"></view>
					 </view>
				 </li>
				 
			 </ul> 
			 <view v-if="product_list == '' ">
			 	  <u-empty :margin-top='400' text="列表记录为空" mode="list"></u-empty>
			  </view>
		 </view>
		
		 
		<view class="bags">			
			<view class="bags_ico" @click="fresh_cart()">
				<u-icon name="shopping-cart-fill" color="#FFFFFF" size="50"></u-icon>
			     <view class="bags_num">{{cart_num}}</view>
			</view>
		</view>
		 
		<u-toast ref="uToast" />
		<u-back-top :scroll-top="scrollTop"></u-back-top>
		<foot_bar ></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	export default {
		components: {
			foot_bar
		 },
		data() {
			return {
				c_list: [
					{
						name: '新发布'
					}, 
					{
						name: '销量高'
					}, 
					{
						name: '价格低'
					}
				],
				curNow:0,
				background: {
					backgroundColor: '#19be6b',
					// 渐变色
					// backgroundImage: 'linear-gradient(45deg, rgb(28, 187, 180), rgb(141, 198, 63))'
				},
				product_list:'',
				_tname:'生鲜商品',
				cart_num:0,
				scrollTop: 0,
			}
		},
		onShow() { //
			this.cart_num = this.$store.getters.fresh_nums
		},
		onLoad(options) {			
			if(options.tname != undefined){
				this._tname = options.tname 
			} 
 			if(options.cid != undefined){
				this._get_product_c_list(options.cid); //二级类
			}
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }				 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
 			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	 		
			//#endif
			
			
			//
		},
		mounted() {
			 
		},
		methods: {
			fresh_show(item){
				uni.navigateTo({
				   url: '/pages3/fresh/fresh_show?id='+item.id+'&cid='+item.cid
				})
			},
			fresh_cart(){
				uni.navigateTo({
				   url: '/pages/shop_cart/fresh_cart'
				})
			},
			buy(item){
				this.$store.commit('store_fresh_cart_add',item)				 
				this.cart_num = this.$store.getters.fresh_nums
				this.$refs.uToast.show({
				    title: '加入成功！',
				})		
			},
			sectionChange(index) { //标签切换
				this.curNow = index;
			    if(index == 0){ //新发布
				 	this.product_list = this.product_list.sort(this._sortBy('times',false))  //false 降序   true  升序
				}else if(index == 1){ //销量高
				 	this.product_list = this.product_list.sort(this._sortBy('sales_num',false))  //false 降序   true   升序
				}else if(index == 2){ //价格低
				 	this.product_list = this.product_list.sort(this._sortBy('retail_price',true))  //false 降序   true   升序
				}
			},
			async _get_product_c_list(cid){ //获取二级分类商品列表
			    const res =  await this.$AjaxRequest_fresh({
			    	url: '/get_product_list',
			    	method:'POST',
			    	data:{value_data:{'cid':cid}}
			    }).then((res) => { 	
					 if(res.sta == 'success'){
						this.product_list = res.data
 					 }			    	 				
			     })				
			},
			_sortBy(attr,rev){	//排序				 
					if(rev ==  undefined){
						rev = 1;
					}else{  rev = (rev) ? 1 : -1;    }
						return function(a,b){
					 a = parseInt(a[attr]);
						b = parseInt(b[attr]);
			 			if(a < b){  return rev * -1;         }
						if(a > b){     return rev * 1;        }
						 return 0;
					}
			},
		}
	}
</script>
<style  scoped>
	
	.bags_num{width: auto;min-width: 40rpx;height: 40rpx;background-color: red;line-height: 40rpx; position: absolute;top:-20rpx;right: -10rpx;font-size:22rpx;color:#FFFFFF;text-align: center;  border-radius: 180rpx;;}
 	.bags_ico{width: 80rpx;height: 80rpx;margin:0 auto;text-align: center;line-height:80rpx;padding-top:10rpx;}
	.bags{width: 80rpx;height: 80rpx;position: fixed; background-color: #9bd439;z-index: 999;right:30rpx;bottom:150rpx;border-radius: 180rpx;;}
	
	.menxu{margin-bottom: 20rpx;;}
	
	.tbuy{width: 50rpx;height: 50rpx;background-color: #9bd439;color: #FFFFFF;margin-top:10rpx;  text-align: center;border-radius: 180rpx;line-height: 50rpx;}
	.buys{width: 50rpx;height: 60rpx;float: right;}
	.prices{width: 170rpx;height: 60rpx;float: left;line-height: 60rpx;font-size: 32rpx;font-weight: 500;color:#fa3534;}
	.infos{width: 220rpx;height: 60rpx;margin: 0 auto; }
	.titles{width: 220rpx;height: 80rpx;margin: 0 auto;line-height: 40rpx;font-size: 28rpx; word-break:break-all;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;}
	.pics img{width: 100%;height: 100%;;}
	.pics{width: 220rpx;height: 250rpx;margin:0 auto;}
	.cboxs li{width:240rpx;height: 400rpx;float: left;margin-bottom: 20rpx;margin-left:5rpx;margin-right: 5rpx;}
	.clear{clear: both;}
	.cboxs{width: 100%;height: auto;}
</style>
