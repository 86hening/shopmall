<template>
	<view>
		<u-navbar back-text="返回" title="商品详情" back-icon-color="#9bd439" :back-text-style="{color:'#9bd439'}" title-color="#9bd439"  :border-bottom="true" ></u-navbar>
 
		<view class="head_slide">
			<u-swiper :list="product_info.slide" name="item" height="560" bg-color="#ffffff" img-mode="aspectFit" mode="dot" ></u-swiper>
		</view>
		<view class="price_tag">
			<view class="price_box1"><text class="mficon">￥</text>{{product_info.retail_price}}</view>
			<view class="price_num">已售 {{product_info.sales_num}} 件</view>
			<view class="clear"></view>
		</view>
		
		<view class="product_title">{{product_info.product_name}}</view> 
		<view class="product_desc">{{product_info.notice}}</view>
		<view class="rec_title"><u-icon class="icon_sty" name="grid" size="32"></u-icon> 推荐商品</view>
		<view class="rec_box">
			<ul>
				<li v-for="(item,index) in product_list" :key="index">
					<view class = "pic_a"><img @click="fresh_show(item)" :src="item.thum"></view>
					<view class="con_a">{{item.product_name}}</view>
					<view class="pinfo">
						<view class="price_a">￥{{item.retail_price}}</view>
						<view class="buys"><u-icon name="shopping-cart" color="#FFFFFF" size="30"></u-icon></view>
						<view class="clear"></view>
					</view>
				</li>	
				<view class="clear"></view>
			</ul>
		</view>
		<view class="rec_title"><u-icon class="icon_sty" name="grid" size="32"></u-icon> 商品详情</view>
		<view class="content_bbox">
			<u-parse :html="product_info.content"></u-parse>
		</view>
		
		
	    <!---->
	     <view class="navigation">
	     	<view class="left">		    		
	     		<view class="item" @click="home">
	     			<u-icon name="home" :size="40" :color="$u.color['contentColor']"></u-icon>
	     			<view class="text u-line-1">首页</view>
	     		</view>
	    		<view class="item">
	     				<u-icon name="kefu-ermai" :size="40" :color="$u.color['contentColor']" ></u-icon>
	    						<view class="text u-line-1">客服</view>
	    				</view>
	     		<view class="item car" >
	     			<u-badge class="car-num" :count="cart_num" type="error" :offset="[-3, -6]"></u-badge>
	     			<u-icon name="shopping-cart" :size="40" :color="$u.color['contentColor']"></u-icon>
	     			<view class="text u-line-1">菜篮子</view>
	     		</view>
	     	</view>
	     	<view class="right">
	     		<view class="cart btn u-line-1" @click="buy_cart(product_info)">加入菜篮子</view>
	     		<view class="buy btn u-line-1" @click="buy_now(product_info)">立即购买</view>
	     	</view>
	    </view>	
	    <!---->	
	    <view class="bags">
	    	<view class="bags_ico" @click="fresh_cart()">
	    		<u-icon name="shopping-cart-fill" color="#FFFFFF" size="50"></u-icon>
	    	     <view class="bags_num">{{cart_num}}</view>
	    	</view>
	    </view>	
		
	 <u-toast ref="uToast" />
	 <u-back-top :scroll-top="scrollTop"></u-back-top>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				product_info:'',
				product_list:'',
				cart_num:0,
				scrollTop: 0,
			}
		},
		onShow() { //
			this.cart_num = this.$store.getters.fresh_nums
		},
		onLoad(options) {
			let cid = options.cid
			let id = options.id
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }				 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
 			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	 		
			//#endif
			
			this._get_product_info(id) //单品信息
			this._get_product_list(cid,6)//同类商品 6 条
			
		},
		methods: {	
			home(){//跳转首页
				uni.switchTab({
				    url: '/pages/index/index'
				})
			},
			buy_cart(item){
				this.$store.commit('store_fresh_cart_add',item)
				this.cart_num = this.$store.getters.fresh_nums
				this.$refs.uToast.show({
				    title: '加入成功！',
				})	
			},
			fresh_cart(){
				uni.navigateTo({
				   url: '/pages/shop_cart/fresh_cart'
				})
			},
			buy_now(item){//立即购买
				let  buy_str =  item.shop_id+'|'+item.id+'|1|0| '+item.retail_price
				uni.navigateTo({
				    url: '/pages/shop_cart/fresh_buy?type=fresh&buy_str='+buy_str
				})
			},
			async _get_product_info(id){ //单品
				const res =  await this.$AjaxRequest_fresh({
					url: '/get_product_info',
					method:'POST',
					data:{value_data:{'id':id}}
				}).then((res) => { 			
					if(res.sta == 'success'){
						console.log(res)
 						this.product_info =  res.data
					}	
				 })
			},
			fresh_show(item){
				uni.navigateTo({
				   url: '/pages3/fresh/fresh_show?id='+item.id+'&cid='+item.cid
				})
			},
			async _get_product_list(cid,limit){ //商品列表
				const res =  await this.$AjaxRequest_fresh({
					url: '/get_product_list',
					method:'POST',
					data:{value_data:{'cid':cid,'limit':6}}
				}).then((res) => { 			
					if(res.sta == 'success'){
 						this.product_list =  res.data
					}	
				 })
			}
		}
	}
</script>

<style lang="scss" scoped>
 
 .bags_num{width: auto;min-width: 40rpx;height: 40rpx;background-color: red;line-height: 40rpx; position: absolute;top:-20rpx;right: -10rpx;font-size:22rpx;color:#FFFFFF;text-align: center;  border-radius: 180rpx;;}
 .bags_ico{width: 80rpx;height: 80rpx;margin:0 auto;text-align: center;line-height:80rpx;padding-top:10rpx;}
 .bags{width: 80rpx;height: 80rpx;position: fixed; background-color: #9bd439;z-index: 999;right:30rpx;bottom:150rpx;border-radius: 180rpx;;}
 
 .content_bbox{width: 100%;height: auto;padding-bottom: 110rpx;;}
 .clear{clear: both;}
 .icon_sty{margin-right: 10rpx;;}
 .buys{width: 50rpx;height: 50rpx;background-color:#9bd439;float: right;margin-right:20rpx; border-radius: 180rpx;text-align:center;line-height:50rpx;margint-op:30rpx;;}
 .price_a{width: 50%;height: 60rpx;float: left;font-size: 34rpx;font-weight:500;color:#fa3534;}
 .pinfo{width: 100%;height:60rpx;line-height: 60rpx; ;}
 .con_a{width: 100%;height: 50rpx;line-height: 50rpx;overflow: hidden;text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: 1;-webkit-box-orient: vertical;}
 .pic_a img{width: 100%;height: 96%;}
.pic_a{width: 230rpx;height: 250rpx;overflow: hidden;}
 .rec_box li{width:230rpx;height: auto;float: left;margin-left: 10rpx;margin-right: 10rpx;margin-bottom: 20rpx;;}
 .rec_box{width: 100%;height: auto;margin: 0 auto;padding-top:20rpx;padding-bottom: 30rpx;;}
.rec_title{width: 98%;height: 60rpx;line-height: 60rpx;margin: 0 auto;font-size: 30rpx;font-weight: 550;;}
.product_desc{width: 98%;height:80rpx;margin: 0 auto;color:#c8c9cc;overflow: hidden;text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;;}
.mficon{font-weight:normal;font-size: 28rpx;;}
.price_num{width: 45%;height: 80rpx;float: right;margin-right: 5%;line-height: 80rpx;font-size:28rpx;color:#FF9900;text-align:right;}
.price_box1{width:45%;height: 80rpx;float: left;margin-left:5%;font-size: 44rpx;font-weight: 550;color:#fa3534;line-height: 80rpx;;}
.price_tag{width: 100%;height: 80rpx;background-color: #f4f4f4;}
.product_title{width: 100%;height: 100rpx;color:#303133;margin-top:10rpx; padding:10rpx;font-size: 32rpx;font-weight: 550;overflow: hidden;
  text-overflow: ellipsis;display: -webkit-box;-webkit-line-clamp: 2;-webkit-box-orient: vertical;}
.head_slide{width: 100%;height: 560rpx;background: #FFFFFF;}
.head_slide  img{width: 100%;height:100%;}

 .navigation {
     	display: flex;
     	margin-top: 100rpx;
     	border: solid 2rpx #f2f2f2;
     	background-color: #ffffff;
     	padding: 12rpx 0;
		position: fixed;bottom: 0;	
			width: 100%;
     	.left {
     		display: flex;
     		font-size: 20rpx;
     		.item {
     			margin: 0 36rpx;
     			&.car {
     				text-align: center;
     				position: relative;					
     				.car-num {
     					position: absolute;
     					top: -10rpx;
     					right: -10rpx;
     				}
     			}
     		}
     	}
     	.right {
     		display: flex;
     		font-size: 28rpx;
     		align-items: center;
     		.btn {
     			line-height: 66rpx;
     			padding: 0 30rpx;
     			border-radius: 36rpx;
     			color: #ffffff;
     		}
     		.cart {
     			background-color: #9bd439;
     			margin-right: 30rpx;
     		}
     		.buy {
     			background-color: #ff7900;		
     		}
     	}
     }
</style>
