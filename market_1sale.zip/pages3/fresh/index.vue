<template>
	<view >
		<u-navbar back-text="返回" title="生鲜商品" back-icon-color="#9bd439" :back-text-style="{color:'#9bd439'}" title-color="#9bd439" :border-bottom="true" ></u-navbar>
		 <!-- back-icon-color="#FFFFFF" :back-text-style="{color:'#FFFFFF'}" title-color="#FFFFFF" :background="background" -->
		<view class="u-search-box">			 
			<u-search placeholder="请输入关键字..." v-model="keyword"></u-search>		 
		</view>
	   <view class="u-menu-wrap">
		       <!-- <u-sticky offset-top="230">
				   :class="scroll_sta == true  ?'curr_left':''" -->
	   			<scroll-view scroll-y scroll-with-animation class="u-tab-view menu-scroll-view"   :scroll-top="scrollTop">
	   				<view v-for="(item,index) in b_cate_list" :key="index" class="u-tab-item" :class="[current==index ? 'u-tab-item-active' : '']"
	   				 :data-current="index" @tap.stop="swichMenu(index)">
	   					<text class="u-line-1">{{item.tname}}</text>
	   				</view>
	   			</scroll-view>
				<!-- </u-sticky> -->
	   			<block v-for="(item,index) in b_cate_list" :key="index">
					<!-- :class="scroll_sta == true  ?'curr_right':''"  -->
	   				<scroll-view scroll-y class="right-box"  v-if="current==index">
	   					<view class="page-view">
	   						<view class="class-item">
	   							<view class="item-title">
	   								<text>{{item.tname}}</text>
	   							</view>
	   							<view class="item-container">									 
	   								<view class="thumb-box" v-for="(item1, index1) in s_cate_list" :key="index1">
	   									<image @click="fresh_list(item1)" class="item-menu-image" :src="item1.cate_pic" mode=""></image>
	   									<view class="item-menu-name">{{item1.tname}}</view>
	   								</view>
	   							</view>
	   						</view>
	   					</view>
	   				</scroll-view>
	   			</block>
	   		</view>
	        

		
		<foot_bar ></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
 	export default {
		components: {
			foot_bar
		 },
		data() {
			return {	 				 
				scrollTop: 0, //tab标题的滚动条位置
				current: 0, // 预设当前项的值
				menuHeight: 0, // 左边菜单的高度
				menuItemHeight: 0, // 左边菜单item的高度
				scroll_sta:false,
				
				background: {
					backgroundColor: '#9bd439',					
				},
				keyword: '',
				b_cate_list:'', //大分类
				s_cate_list:'',//二级分类
			}
		},
		onLoad(options) {
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }				 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
 			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	 		
			//#endif
 
			 this._get_fresh_cate() //生鲜大分类
		},
		 
		/* onPageScroll: function(Object) {
		   //console.log(Object.scrollTop);//实时获取到滚动的值
		   if(Object.scrollTop > 0){
			  //this.scroll_sta = true
		   } 
		   
		} , */
		methods: {
			fresh_list(item){
				uni.navigateTo({
				   url: '/pages3/fresh/fresh_list?cid='+item.id+'&tname='+item.tname
				})
			},
			//#ifdef H5
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },
			 async _wx_get_code(){ //微信公众号获取code
					const res_wx = await this.$AjaxRequest({
						url: '/get_config',
						method:'POST',
						data:{value_data:{}}
					})			 
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					window.location.href = auth_get_code_url
			},		     	  
			//#endif     
			async _get_fresh_cate(){ //获取生鲜大类					 
				    const res =  await this.$AjaxRequest_fresh({
				    	url: '/get_b_cate',
				    	method:'POST',
				    	data:{value_data:{'a':''}}
				    }).then((res) => { 								 
						 if(res.sta == 'success'){
							 this.b_cate_list = res.data
							 this.s_cate_list=  res.s_data
						 }			
				     })				  
			 },
			async _get_right_data(pid){ //获取右侧二级类目
				const res =  await this.$AjaxRequest_fresh({
					url: '/get_s_cate',
					method:'POST',
					data:{value_data:{'pid':pid}}
				}).then((res) => { 			
					 if(res.sta == 'success'){						  
						 this.s_cate_list = res.data
					 }			
				 })
			}, 			
		  
			// 点击左边的栏目切换
			async swichMenu(index) {
				if(index == this.current) return ;
				this.current = index;
				// 如果为0，意味着尚未初始化
				if(this.menuHeight == 0 || this.menuItemHeight == 0) {
					await this.getElRect('menu-scroll-view', 'menuHeight');
					await this.getElRect('u-tab-item', 'menuItemHeight');
				}
				// 将菜单菜单活动item垂直居中
				this.scrollTop = index * this.menuItemHeight + this.menuItemHeight / 2 - this.menuHeight / 2;				
				this._get_right_data(this.b_cate_list[index].id); 
			},
			// 获取一个目标元素的高度
			getElRect(elClass, dataVal) {
				new Promise((resolve, reject) => {
					const query = uni.createSelectorQuery().in(this);
					query.select('.' + elClass).fields({size: true},res => {
						// 如果节点尚未生成，res值为null，循环调用执行
						if(!res) {
							setTimeout(() => {
								this.getElRect(elClass);
							}, 10);
							return ;
						}
						this[dataVal] = res.height;
					}).exec();
				})
			}
			
			
		}
	}
</script> 
<style lang="scss" scoped>
	.u-wrap {
		height: calc(100vh);
		/* #ifdef H5 */
		height: calc(100vh - var(--window-top));
		/* #endif */
		display: flex;
		flex-direction: column;
	}
	.u-search-box {padding: 18rpx 30rpx;}
	.u-menu-wrap {flex: 1;display: flex;overflow: hidden;}
	.u-search-inner {background-color: rgb(234, 234, 234);border-radius: 100rpx;display: flex;align-items: center;padding: 10rpx 16rpx;}
	.u-search-text {font-size: 26rpx;color: $u-tips-color;margin-left: 10rpx;}
	.u-tab-view {width: 200rpx;height: 100%;}
	.u-tab-item {height: 110rpx;background: #f6f6f6;box-sizing: border-box;display: flex;align-items: center;justify-content: center;
		font-size: 26rpx;color: #444;font-weight: 400;line-height: 1;}	
	.u-tab-item-active {position: relative;color: #000;font-size: 30rpx;font-weight: 600;background: #fff;}	
	.u-tab-item-active::before {content: "";position: absolute;border-left: 4px solid $u-type-primary;height: 32rpx;left: 0;top: 39rpx;}
	.u-tab-view {height: 100%;}	
	.curr_left{margin-top: 30rpx;}
	.curr_right{margin-left:200rpx;}
	.right-box {background-color: rgb(250, 250, 250);width: 550rpx;}	
	.page-view {padding: 16rpx;}	
	.class-item {margin-bottom: 30rpx;background-color: #fff;padding: 16rpx;border-radius: 8rpx;}
	.item-title {font-size: 26rpx;color: $u-main-color;font-weight: bold;}	
	.item-menu-name {font-weight: normal;font-size: 24rpx;color: $u-main-color;}	
	.item-container {display: flex;flex-wrap: wrap;}	
	.thumb-box {width: 33.333333%;display: flex;align-items: center;justify-content: center;flex-direction: column;	margin-top: 20rpx;}
	.item-menu-image {width: 120rpx;height: 120rpx;
	}
</style>
