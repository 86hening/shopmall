<template>
	<view>
 		<u-navbar back-text="返回" title="拼团商品"></u-navbar>
		<view>		 
			<scroll-view class="swiper-tab" scroll-x :scroll-left="scrollLeft" :scroll-with-animation="true">
					<view v-for="(item, index) in cate_time" 
						:key="index" 
						:class="['swiper-tab-list',index == tabIndex ? 'qg_active' : '']"
						:id="index" 						
						@tap="gettqg(item,index)" 
						>	
						<view class="list-item" >
							<text>{{item.title}}</text>
							<view class="j_st" v-if="item.sta == 0 ">进行时</view>
							<view class="j_st" v-else-if="item.sta == 1 ">待开始</view>
							<view class="j_st" v-else-if="item.sta == -1 ">已结束</view>							
						</view>
					</view>						
					
				</scroll-view> 	
			
		</view>
		<view class="tg_box">
			<ul  v-if="product_list !=  '' ">
                       <li v-for="(item_child,index2) in product_list" :key="index2">
                           <view class="left_pic" v-if="item_child.f_sta == 0 " @click="show_other_pros('tg',item_child.shop_id,item_child.id)"> 
 						       <u-image width="95%" height="95%" :src="item_child.thum"></u-image>
						   </view>  
							<view class="left_pic" v-else="">
							    <u-image width="95%" height="95%" :src="item_child.thum"></u-image>
							</view> 				  
                           <view class="right_item">
                              <view class="title" v-if="item_child.f_sta == 0 " @click="show_other_pros('tg',item_child.shop_id,item_child.id)">{{item_child.product_name}}</view>
							  <view class="title" v-else="">{{item_child.product_name}}</view>
                               <view class="item_end">
                                   <view class="item_left">
                                       <view class="price_box">￥ {{item_child.tg_price}}</view>
                                       <view class="process">
                                           <view  style="width: 100%;">  <!---->
 											   <u-line-progress active-color="#ff014e" :percent="item_child.process" height="20" :show-percent="true"></u-line-progress>
										   </view>
                                       </view>
                                   </view>
                                   <view class="item_right">
                                       <view class="btn" v-if="item_child.f_sta == '-1'"  style="background: #E6E6E6;">立即下单</view>
                                       <view class="btn" v-else-if="item_child.f_sta == '0'"   @click="buy_now(item_child)"  >立即下单</view>
                                       <view class="btn" v-else-if="item_child.f_sta == '1'" style="background: #4DD2FF;">等待开启</view>
                                   </view>
                                   <view class="clear"></view>
                               </view>
                           </view>
                           <view class="clear"></view>
                        </li>
                   </ul>
				   <u-empty v-else="" text="记录为空" margin-top="100" mode="list"></u-empty>
		</view>		
		<foot_bar ></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	
	export default {
		components: {
			foot_bar,			
		 },
		 created() {
		 	this._get_prolist() 	
		 },		 
		data() {
			return {
			 // defaultIndex: 2,			 
			  cate_time:'',	 
			  product_list:'',			  
			  tabIndex: 0,	//选中项下标
			  scrollLeft:0,	//滚动位置		  
  			  
 			}
		},	
		mounted(){
 			
					
		},
		methods: {	
			show_other_pros(type,shop_id,product_id){ //详情页面
				uni.navigateTo({
				   url: '/pages3/show_product/index?type='+type+'&shop_id='+shop_id+'&id='+product_id
				})
			},
			buy_now(item){
			    let  buy_str =  item.shop_id+'|'+item.id+'|1|0| '+ item.tg_price
				uni.navigateTo({
				    url: '/pages3/buy/index?type=tg&buy_str='+buy_str
				})
			},
			  async _get_prolist(){ //获取商品列表
				const res = await this.$AjaxRequest_product({
					url: 'get_tg_list',
					method:'post',
					data:{value_data:{}}  //
				})  
				 this.cate_time = res.data
				 for(let i=0;i<res.data.length;i++){		
					 if(res.data[i]['active'] > 0){
						this.tabIndex = res.data[i]['active']
					 	this.product_list = res.data[i]['pro_list']	
						this.scrollLeft = 320			
 					  }
				 }			
			},
			gettqg(item, index) {				 
				if (this.tabIndex !== index) {
					this.tabIndex = index;
					//this.scrollLeft = index*60;
					this.scrollLeft = 320
 					this.product_list = item['pro_list']	
				}
			},
		 
		}
	}
</script>

<style  scoped lang="less">
 .colon {display: inline-block; margin: 0 8rpx; color: #ee0a24;}
  .block {display: inline-block;width:50rpx; color: #fff; font-size:24rpx;text-align: center;background-color: #FF1A5E; }
  .box{width: 100%;height:80rpx;background: white;margin-bottom: 10rpx;}
  .box_left{width: 48%;height:80rpx;line-height:80rpx;float: left;font-size: 28rpx;color:#333;padding-left: 2%;}
  .box_right{width: 48%;height:50rpx;float: right;text-align: right;padding-right: 2%; padding-top:20rpx;}
   .btn{width: 80%;height: 50rpx;line-height: 50rpx;background: #FF1A5E;border-radius: 360rpx; margin-top:30rpx;  font-size: 24rpx;color:#ffffff;text-align: center;border:none;margin:0 auto;}
    .process{width:80%;height: 60rpx;font-size: 24rpx;margin-top:10rpx;}
    .price_box{width: 100%;height: 60rpx;line-height: 60rpx;color:#FF1A5E;font-size: 32rpx;}
    .item_right{width: 35%;height: 120rpx;float: right;}
    .item_left{width: 60%;height: 120rpx;float: left;}
    .item_end{width: 100%;height: 120rpx;}
    .title{width: 100%;height: 80rpx;font-size: 28rpx;color:#666; text-overflow: -o-ellipsis-lastline;overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
    .right_item{width: 68%;height: 160rpx;float: right;margin-right: 2%;}
    .left_pic{width: 30%;height: 190rpx;float: left;text-align: center;overflow:hidden;}
    .tg_box  li{width: 100%;height: 220rpx;background: white;padding-top: 10rpx;padding-bottom: 10rpx;  margin-bottom:20rpx;border-radius:20rpx;border-bottom: 5px #f5f5f5 solid;}
   .tg_box{width: 100%;height: auto;padding-bottom: 120rpx;padding-top: 20rpx;}
   
    
    .list {
    		width: 750upx;
    		height: 100%;
    	}
		.j_st{font-size: 24rpx;font-weight: normal;}
    	.swiper-box {
    		flex: 1;
    		width: 100%;
    		height: calc(100% - 100upx);
    	}
    	.swiper-tab {
    		width: 100%;
    		white-space: nowrap;
    		line-height: 64upx;
    		height: 116upx;
    		border:0;
    		font-size:24upx;
    	}
    	.swiper-tab-list {
    		font-size: 30upx;
    		width: 180upx;
    		padding: 5px 0;
    		display: inline-block;
    		text-align: center;
    		color: #fff;
    		background: #000;
    		line-height:20px;
    	}
    	.list-item{
    		display:flex;
    		flex-direction: column;
    		align-items: center;
			font-weight: bold;
    	}
    	.qg_active {
    		color: #fff;
    		background-image: linear-gradient(#ff014e,#ff00d1);
    	}
    	.qgactive-item{
    		width: 0;
    		height: 0;
    		border-width: 5px;
    		border-style: solid;
    		border-color: #FF502E transparent transparent transparent;
    		position:absolute;
    		margin-top:45px;
    	} 
   
   
</style>
