import Vue from 'vue'
import Vuex from 'vuex'

Vue.use(Vuex)
import shop_cart from '@/store/shop_cart';
import fresh_cart from '@/store/fresh_cart';
import tab_bar from '@/store/tab_bar';
import wxapp from '@/store/wxapp';
import user from '@/store/user';
import ali from '@/store/ali';
 export default new Vuex.Store({
  state: {
  },
  mutations: {
  },
  actions: {
  },
  modules: {      
      shop_cart,
	  fresh_cart,
	  tab_bar,
	  wxapp,
	  user,
	  ali
   }
})
