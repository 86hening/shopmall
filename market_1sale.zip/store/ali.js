export default {
    state: {
		 ali_user:"" || uni.getStorageSync('ali_user'), 
		 
    },
    getters: {		 
		get_ali_user(state){
			return state.ali_user
		},
		 
	},
    mutations: {
      set_ali_user(state,params){//          
		   state.ali_user = params	
		   uni.setStorageSync('ali_user',state.ali_user)
      },  	   
      
    },
    actions: {

    }
}