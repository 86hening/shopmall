export default {
    state: {
		 wx_user:"" || uni.getStorageSync('wx_user'), 
    },
    getters: {		 
		get_wx_user(state){
			return state.wx_user
		},		
	},
    mutations: {
      set_wx_user(state,params){//          
		   state.wx_user = params	
		   uni.setStorageSync('wx_user',state.wx_user)
      },  	  
    },
    actions: {

    }
}