export default {
    state: {
        fresh_cart: ""  || uni.getStorageSync('fresh_cart'), 
     },
    getters: {
          fresh_nums(state){ //计算商品数量  5|10|  2  |0|1.5 ，6|50|  3  |0|25.6    [商铺ID|商品id|数量|促销标识0|单价]
              if(state.fresh_cart != "" &&  state.fresh_cart != "null" &&  state.fresh_cart != null){
                     let reg=/,$/gi;
                     let arr=state.fresh_cart.replace(reg,"").split(',');//去除逗号-转数组
                   let  goods_num = 0;
                  for(let i=0;i<arr.length;i++){
                        let item_arr = arr[i].split('|')
                      goods_num += parseInt(item_arr[2])
                  }
                  return  goods_num
               }else{
                  return  0
              }
          },
    },
    mutations: {  //同步
        store_fresh_cart_add(state,params){  //添加购物车
            if(state.fresh_cart == "" || state.fresh_cart == "null" ||  state.fresh_cart == null){ //购物车空的，首次添加购物车
                        state.fresh_cart =  params.shop_id+'|'+params.id+'|1|0'+'|'+params.retail_price+','
            } else{  //购物车不为空  5|10|  3|0|1.5 ，6|50|  3  |0|25.6，6|50|  3  |0|25.6
                  //1检测列表是否已存在商品
                   let reg_pat = new RegExp(String.raw`(${params.shop_id}\|${params.id}\|)(\d{1,})(\|\d{1,}\|[\.|\d]{1,}\,)`);
                   let result = state.fresh_cart .match(reg_pat);
                        if(result != null) { //匹配成功，增加商品数量 --
                                  let num = parseInt(result[2])+parseInt(1)  //原始该商品数量+1
							     state.fresh_cart  =  state.fresh_cart .replace(reg_pat, "$1"+num+"$3")
                        }else{ //不存在，则追加商品
                               state.fresh_cart  += params.shop_id+'|'+params.id+'|1|0'+'|'+params.retail_price+','
                        }
            }
 		   uni.setStorageSync('fresh_cart',state.fresh_cart)
          },
        store_fresh_cart_edit(state,params){ //编辑购物车数量
                   let reg_pat = new RegExp(String.raw`(\d{1,}\|${params.id}\|)(\d{1,})(\|\d{1,}\|[\.|\d]{1,}\,)`);
                  let result = state.fresh_cart .match(reg_pat);
                   if(result != null) { //匹配成功，更新为最新数量
                        state.fresh_cart  = state.fresh_cart .replace(reg_pat, "$1" + params.num + "$3")
                   }
 			  uni.setStorageSync('fresh_cart',state.fresh_cart)
          },
        store_fresh_cart_del(state,params){//删除购物车商品--单
                          let reg_pat = new RegExp(String.raw`(${params.shop_id}\|${params.id}\|)(${params.buy_num})(\|\d{1,}\|[\.|\d]{1,},)`);
                          let result = state.fresh_cart .match(reg_pat);
                          if(result != null){ //匹配成功，移除
                               state.fresh_cart = state.fresh_cart.replace(reg_pat, "")
   						 }
 						  uni.setStorageSync('fresh_cart',state.fresh_cart)
         },
         store_fresh_cart_clear(state,params) {//清空购物车
               state.fresh_cart  = ""
 			   uni.removeStorageSync('fresh_cart')
         },


    },
    actions: {  //异步

    }
}