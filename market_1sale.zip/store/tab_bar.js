export default {
    state: {
		 search_key:[],
		 shop_num : 0,
          tab_bar_list : [{
						iconPath: "home",
						selectedIconPath: "home-fill",
						text: '首页',
						//count: 2,
						//isDot: false,
						customIcon: false,
						pagePath:'/pages/index/index',
					},
					{
						iconPath: "grid",
						selectedIconPath: "grid-fill",
						text: '分类',
						customIcon: false,
						pagePath:'/pages/product/category',
					},
					{
						iconPath: "account",
						selectedIconPath: "account-fill", //http图片路径
						text: '我的',						 
						midButton: true,
						customIcon: false,
						pagePath:'/pages/user/index',
					},
					{
						iconPath: "shopping-cart",
						selectedIconPath: "shopping-cart-fill",
						text: '购物车',
						//count: this.$store.getters.Shop_nums,
						count:0,
						customIcon: false,
						pagePath:'/pages/shop_cart/shop_cart',
					},
					{
						iconPath: "coupon",
						selectedIconPath: "coupon-fill",
						text: '订单',						
						isDot: false,
						customIcon: false,
						pagePath:'/pages/orders/orders',
					},
				]
    },
    getters: {
		tabr_list(state){
			state.tab_bar_list[3]['count'] = state.shop_num
			return state.tab_bar_list
		},
		get_search_key(state){
			return state.search_key
		},
	 
		
    },
    mutations: {
      get_shop_num(state,params){//          
		   state.shop_num = params		  
      },  
	  save_clear_cart(state,params){
		  state.clear_cart = params		   
	  },
      save_search_key(state,params){  //修改属性
         if(state.search_key != null &&  state.search_key !='null'){
             //检测重复
              if(!state.search_key.includes(params)){ //不存在
                 state.search_key.push(params);
               }
         }else{ //空的
            state.search_key[0] = params;
           }
      },
    },
    actions: {

    }
}