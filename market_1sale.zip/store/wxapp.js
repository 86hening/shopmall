export default {
    state: {
		 wxapp_user:"" || uni.getStorageSync('wxapp_user'), 
		 wxapp_openid:"" || uni.getStorageSync('wxapp_openid'), 
    },
    getters: {		 
		get_wxapp_user(state){
			return state.wxapp_user
		},
		get_wxapp_openid(state){
			return state.wxapp_openid
		},
		
    },
    mutations: {
      save_wxapp_user(state,params){//          
		   state.wxapp_user = params	
		   uni.setStorageSync('wxapp_user',state.wxapp_user)
      },  	   
      save_wxapp_openid(state,params){//
      		   state.wxapp_openid = params	
      		   uni.setStorageSync('wxapp_openid',state.wxapp_openid)
      }, 
    },
    actions: {

    }
}