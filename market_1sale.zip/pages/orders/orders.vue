<template>
	<view>
		<!-- <u-navbar :is-back="true" back-text="返回" title="我的订单"></u-navbar> -->	
		<view>
			 <u-navbar :is-back="false"   >
				<view class="slot-wrap">
					<view class="ico_left">
						<u-icon name="home" size="30" @click="home()"></u-icon>
					</view>
					 <view class="ico_center"> 我的订单 </view>
					<view class="ico_right">
						 
					</view>
					<view class="clear"></view>
				</view>		
			 </u-navbar>
		</view>	
		<view class="wrap">
			<u-sticky>
			<view class="u-tabs-box">
				<u-tabs-swiper activeColor="#f29100" ref="tabs" :list="list" :current="current" @change="change" :is-scroll="false" swiperWidth="750"></u-tabs-swiper>
			</view>
			</u-sticky>
			<swiper class="swiper-box" :current="swiperCurrent" @transition="transition" @animationfinish="animationfinish">
				
				<swiper-item class="swiper-item" >
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="reachBottom">
						<view class="page-box">
							<!--for-start-->
							<view v-if="order_in == '' ">
								<view class="centre">
									<image src="https://cdn.uviewui.com/uview/template/taobao-order.png" mode=""></image>
									<view class="explain">
										您还没有相关的订单
										<view class="tips">可以去看看有那些想买的</view>
									</view>
									<view class="btn">随便逛逛</view>
								</view>
							</view>
							<view  class="order"  v-for="(item,index) in  order_in" :key="index">
								<view class="top">
									<view class="left">
										<u-icon name="home" :size="30" color="rgb(94,94,94)"></u-icon>
										<view class="store">{{item.shop.shop_name}}</view>
										<u-icon name="arrow-right" color="rgb(203,203,203)" :size="26"></u-icon>
									</view>
									<view class="right">		
										 <!--状态start-->										 
										<view v-if="item.order_type == 'nor' ||   item.order_type == 'act'  ||   item.order_type == 'fresh' ">
											<u-tag v-if="item.sta == '1'  && item.ps_fs == '0'" text="待自取"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '1'  && item.ps_fs == '1'" text="待配送"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '2' && item.ps_fs == '1'   "  text="配送中"type="warning" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '3'" text="订单取消"  type="info" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta >= '4'" text="完成订单"  type="success" shape="circle" size="mini" />								
									   </view>
									  <view v-else-if="item.order_type == 'tg' ">					 
										  <u-tag v-if="item.sta == '-1'" text="待开团"type="warning" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta == '1'  && item.ps_fs == '0'" text="待自取"  type="primary" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta == '1'  && item.ps_fs == '1'" text="待配送"  type="primary" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta == '2' && item.ps_fs == '1' "  text="配送中"type="warning" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta == '3'" text="订单取消"  type="info" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta >= '4'" text="完成订单"  type="success" shape="circle" size="mini" />
										  
									  </view>
									  <view v-else-if="item.order_type == 'ys' "> 
											<u-tag v-if=" item.sta == '1'  &&  item.pre_sta=='1' &&  item.ps_fs =='0'" text="待自取"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if=" item.sta == '1'  &&  item.pre_sta=='1' &&  item.ps_fs =='1'" text="待配送"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if=" item.sta == '1'  &&  item.pre_sta=='0' "  text="待付尾款"  type="warning" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '2'  &&  item.ps_fs == '1'" text="配送中"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '3'" text="订单取消"  type="info" shape="circle" size="mini" />											 
											<u-tag v-else-if="item.sta >= '4'" text="完成订单"  type="success" shape="circle" size="mini" />
									  </view>						
										 <!--状态end-->
									</view>
								</view>
								<view class="item" v-for="(item_child,index2) in item.product" :key="index2">
									<view class="left"><image :src="item_child.pic" mode="aspectFill"></image></view>
									<view class="content">
										<view class="title u-line-2">{{item_child.product_name}}</view>
										<view class="type">
											<u-tag v-if="item.order_type == 'nor'" text="普通订单"  type="info" shape="circle" size="mini" />
											<u-tag v-else-if="item.order_type == 'ys'" text="预售订单"  type="warning" shape="circle" size="mini" />
											<u-tag v-else-if="item.order_type == 'tg'" text="拼团订单"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if="item.order_type == 'act'" text="活动订单"  type="error" shape="circle" size="mini" />
											<u-tag v-else-if="item.order_type == 'fresh'" text="生鲜订单"  type="success" shape="circle" size="mini" />
											<u-tag v-if="item.source_id == '0'" text="公众号"  type="success" shape="circle" size="mini" class="mar_left10" />
											<u-tag v-else-if="item.source_id == '1'" text="小程序"  type="warning" shape="circle" size="mini"  class="mar_left10" />
											<u-tag v-else-if="item.source_id == '2'" text="支付宝"  type="primary" shape="circle" size="mini"  class="mar_left10" />
										</view>
										<view class="delivery-time">{{item.addtime}}</view>
									</view>
									<view class="right">
										<view class="price">
											￥{{item_child.sale_price | fee_file}}
											<text class="decimal"></text>
										</view>
										<view class="number">×{{item_child.buy_num}}</view>
									</view>
								</view>
									
								<view class="total">									
																 
									<u-line color="#f5f5f5" margin="20rpx 0" />
									<u-table border-color="#ffffff"	align="left">											 
											<u-tr>
												<u-td >
												<text v-if="item.order_type != 'ys' ">商品总价 ￥ {{item.order_fee | fee_file}}</text>
												<text v-else-if="item.order_type == 'ys' && item.pre_sta == 0 ">订金总价 ￥ {{item.order_fee | fee_file}}</text>
												<text v-else-if="item.order_type == 'ys' && item.pre_sta == 1 ">预售总价 ￥ {{item.order_fee | fee_file}}</text>
												<text v-else="">商品总价 ￥ {{item.order_fee | fee_file}}</text>	
												
												</u-td>
												<u-td>配送费用：￥{{item.delivery_fee | fee_file}}</u-td>												
											</u-tr>
											<u-tr>
												<u-td>包装费用：￥{{item.packag_fee | fee_file}}</u-td>
												<u-td>合计支付：￥{{item.order_fee | fee_file}}</u-td>												
											</u-tr>
										</u-table>	
									<view class="cobox_btn">
										   <u-button v-if="item.order_type == 'ys' && item.pre_sta=='0' && item.is_ys_pay_sta==1 " size="mini" class="btn_left" shape="circle" @click="pay_r(item)" type="warning">立即支付尾款</u-button>
										   <u-button v-else-if="item.order_type == 'ys' && item.pre_sta=='0' && item.is_ys_pay_sta==0 " size="mini" class="btn_left" shape="circle" @click="pay_r(item)" type="info">等待尾款付款</u-button>
										   <u-button  v-if="item.order_type == 'ys' && item.pre_sta=='0' " size="mini" class="btn_right" shape="circle" @click="close_order(item.order_type,item.id)">取消订单</u-button>
										   <u-button  v-else-if="item.order_type == 'ys' && item.pre_sta=='1' " size="mini" class="btn_right" shape="circle" type="primary">待自提/配送</u-button>
										   
										   <view v-else-if="item.sta == '2'  &&  item.ps_fs == '1'">
											  <view class="zxt_ps_box" v-if="item.info != 'null'">
											  	  <text class="ps_name">配送专员：{{item.info.servie_name}}</text>
											  	  <text class="ps_tel" @click="tel_me(item.info.servie_tel)"> 配送电话：{{item.info.servie_tel}}</text>
											   </view> 
										   </view>
										   
										   <!-- <u-button   size="mini" class="btn_right" shape="circle" type="primary">配送中</u-button> -->
										   <u-button v-else=''  size="mini" class="btn_right" shape="circle" @click="close_order(item.order_type,item.id)">取消订单</u-button>
									</view>									 
								</view>								  
							</view>
							<!--for-end-->
							<!-- <u-loadmore  bgColor="#f2f2f2"></u-loadmore> -->
						</view>
					</scroll-view>
				</swiper-item>
				
				 
				<swiper-item class="swiper-item">
					<scroll-view scroll-y style="height: 100%;width: 100%;" @scrolltolower="reachBottom">
						<view class="page-box">
							<!--for-start-->
							<view v-if="order_fin == '' ">
								<view class="centre">
									<image src="https://cdn.uviewui.com/uview/template/taobao-order.png" mode=""></image>
									<view class="explain">
										您还没有相关的订单
										<view class="tips">可以去看看有那些想买的</view>
									</view>
									<view class="btn">随便逛逛</view>
								</view>
							</view>
							<view class="order" v-for="(item,index) in  order_fin" :key="index">								
								<view class="top">
									<view class="left">
										<u-icon name="home" :size="30" color="rgb(94,94,94)"></u-icon>
										<view class="store">{{item.shop.shop_name}}</view>
										<u-icon name="arrow-right" color="rgb(203,203,203)" :size="26"></u-icon>
									</view>
									<view class="right">		
										 <!--状态start-->										 
										<view v-if="item.order_type == 'nor' ||   item.order_type == 'act' ||   item.order_type == 'fresh' ">
											<u-tag v-if="item.sta == '1'  && item.ps_fs == '0'" text="待自取"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '1'  && item.ps_fs == '1'" text="待配送"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '2' && item.ps_fs == '1'   "  text="配送中"type="warning" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '3'" text="订单取消"  type="info" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta >= '4'" text="完成订单"  type="success" shape="circle" size="mini" />								
									   </view>
									  <view v-else-if="item.order_type == 'tg' ">					 
										  <u-tag v-if="item.sta == '-1'" text="待开团"type="warning" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta == '1'  && item.ps_fs == '0'" text="待自取"  type="primary" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta == '1'  && item.ps_fs == '1'" text="待配送"  type="primary" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta == '2' && item.ps_fs == '1'    "  text="配送中"type="warning" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta == '3'" text="订单取消"  type="info" shape="circle" size="mini" />
										  <u-tag v-else-if="item.sta >= '4'" text="完成订单"  type="success" shape="circle" size="mini" />
										  
									  </view>
									  <view v-else-if="item.order_type == 'ys' "> 
 											<u-tag v-if=" item.sta == '1'  &&  item.pre_sta=='1' &&  item.ps_fs =='0'" text="待自取"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if=" item.sta == '1'  &&  item.pre_sta=='1' &&  item.ps_fs =='1'" text="待配送"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if=" item.sta == '1'  &&  item.pre_sta=='0' "  text="待付尾款"type="warning" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '2'  &&  item.ps_fs == '1'" text="配送中"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta == '3'" text="订单取消"  type="info" shape="circle" size="mini" />
											<u-tag v-else-if="item.sta >= '4'" text="完成订单"  type="success" shape="circle" size="mini" />
									  </view>						
										 <!--状态end-->
									</view>
								</view>
								<view class="item" v-for="(item_child,index2) in item.product" :key="index2">
									<view class="left"><image :src="item_child.pic" mode="aspectFill"></image></view>
									<view class="content">
										<view class="title u-line-2">{{item_child.product_name}}</view>
										<view class="type">
											<u-tag v-if="item.order_type == 'nor'" text="普通订单"  type="info" shape="circle" size="mini" />
											<u-tag v-else-if="item.order_type == 'ys'" text="预售订单"  type="warning" shape="circle" size="mini" />
											<u-tag v-else-if="item.order_type == 'tg'" text="拼团订单"  type="primary" shape="circle" size="mini" />
											<u-tag v-else-if="item.order_type == 'act'" text="活动订单"  type="error" shape="circle" size="mini" />
											<u-tag v-else-if="item.order_type == 'fresh'" text="生鲜订单"  type="success" shape="circle" size="mini" />
											<u-tag v-if="item.source_id == '0'" text="公众号"  type="success" shape="circle" size="mini" class="mar_left10" />
											<u-tag v-else-if="item.source_id == '1'" text="小程序"  type="warning" shape="circle" size="mini"  class="mar_left10" />
											<u-tag v-else-if="item.source_id == '2'" text="支付宝"  type="primary" shape="circle" size="mini"  class="mar_left10" />
										</view>
										<view class="delivery-time">{{item.addtime}}</view>
									</view>
									<view class="right">
										<view class="price">
											￥{{item_child.sale_price | fee_file}}
											<text class="decimal"></text>
										</view>
										<view class="number">×{{item_child.buy_num}}</view>
									</view>
								</view>
								
								<view class="total">
									<!-- 共{{ totalNum(item.product)}}件商品 合计支付:
									<text class="total-price">
										 ￥{{item.order_fee}}
										<text class="decimal"></text>
									</text> -->
									<u-line color="#f5f5f5" margin="20rpx 0" />
									<u-table border-color="#ffffff"	align="left">											 
											<u-tr>
												<u-td >
												<text v-if="item.order_type != 'ys' ">商品总价 ￥ {{item.order_fee | fee_file}}</text>
												<text v-else-if="item.order_type == 'ys' && item.pre_sta == 0 ">订金总价 ￥ {{item.order_fee | fee_file}}</text>
												<text v-else-if="item.order_type == 'ys' && item.pre_sta == 1 ">预售总价 ￥ {{item.order_fee | fee_file}}</text>
												<text v-else="">商品总价 ￥ {{item.order_fee | fee_file}}</text>	
												
												</u-td>
												<u-td>配送费用：￥{{item.delivery_fee | fee_file}}</u-td>												
											</u-tr>
											<u-tr>
												<u-td>包装费用：￥{{item.packag_fee | fee_file}}</u-td>
												<u-td>合计支付：￥{{item.order_fee | fee_file}}</u-td>												
											</u-tr>
										</u-table>
									 
								</view>
								 
							</view>
							<!--for-end-->
							<!-- <u-loadmore  bgColor="#f2f2f2"></u-loadmore> -->
 						</view>
					</scroll-view>
				</swiper-item>
				
			</swiper>
		</view>
		<u-modal v-model="show" :show-title="false" :content="content" :show-cancel-button="true" @confirm="close_order_action"></u-modal>
		
		<u-modal v-model="show_result" :show-title="false" :content="content_result"  @confirm="result_confirm"></u-modal>
		<u-back-top :scroll-top="scrollTop"></u-back-top>
		<foot_bar></foot_bar>
	</view>
</template>

<script>
import foot_bar from '@/components/common/foot_tab_bar.vue'
//#ifdef H5
	  let jweixin = require('jweixin-module');
//#endif
export default {
	components: {
		foot_bar
	 },
	data() {
		return {
			scrollTop: 0,
			order_in:'', //进行中
		    order_fin:'', //已完成
			wx_user_info:'',
			orderList: [[], [], [], []],		 
			list: [
				{
					name: '进行中'
				},
				{
					name: '已完成'
				},				
			],
			current: 0,
			swiperCurrent: 0,
			tabsHeight: 1,
			dx: 1,
			loadStatus: ['loadmore','loadmore'],
			show:false,
			content:'',
			cdata:'', //临时交换区
			show_result:false,
			content_result:'',
			
		};
	},
	created() {
		let _that = this
		 
	   //#ifdef H5	 
	   let url_s = window.location.href.split("#")[0];  //当前url去掉#及后面所有
	   const res_wx = _that.$AjaxRequest({
	   	url: 'get_jssdk',
	   	method:'post',
	   	data:{value_data:{'url':url_s}}
	   }).then((res_wx) => {
	   	 jweixin.config({
	   	    debug: false, // 开启调试模式,
	   	    appId: res_wx.data.appId, // 必填，企业号的唯一标识，此处填写企业号corpid
	   	     timestamp: res_wx.data.timestamp, // 必填，生成签名的时间戳
	   	    nonceStr: res_wx.data.nonceStr, // 必填，生成签名的随机串
	   	     signature: res_wx.data.signature,// 必填，签名，见附录1
	   	     jsApiList: [   // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
	   	        'chooseWXPay',
	   	        'getLocation',
	   	        'getNetworkType',
	   	        'openLocation',
	   	        'showOptionMenu',
	   	        'closeWindow',
	   	        'scanQRCode',
	   	       ]
	   	  });				
	    })     
	   //#endif	
	},
	onShow() {
		this.$store.commit('get_shop_num',this.$store.getters.Shop_nums)  		
	},
	onLoad(options) {		 
		if(options != null & options.is_resh == 1){
			location.reload()
		} 		
		//微信公众号
		 //#ifdef H5 
		 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
		     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
		     	if(options.code == null || options.code === ''){			     		 
		     			 this._wx_get_code()  //本页面方法 	 
		     	}else{
		     		this.$Basic._get_wx_user(options.code)  //获取用户信息
		     	}
		     }else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
			 }
			 this._get_order_list(this.$store.getters.get_wx_user.openid) //获取当前单品
		 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
		    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
		    	if(options.auth_code == null || options.auth_code === ''){			     
		    			 this._ali_get_code() //本页面方法 	 
		    	}else{
		    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
		    	}
		    }else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
			}	
			this._get_order_list(this.$store.getters.get_ali_user.user_id) //获取当前单品	 
		 }			  
		//#endif
		//#ifdef MP-WEIXIN
		//检测小程序是否有openid缓存
		if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
			 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
		}else{ //登陆后检测手机状态					
			this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
		}	
		 this._get_order_list(this.$store.getters.get_wxapp_openid) //获取当前单品	
		//#endif		
				
	},
	onShow() {		 
		//#ifdef H5
		 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
		    this._get_order_list(this.$store.getters.get_wx_user.openid) //获取当前单品
		 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端		
			this._get_order_list(this.$store.getters.get_ali_user.user_id) //获取当前单品
		 }	
		//#endif
		//#ifdef MP-WEIXIN
		 this._get_order_list(this.$store.getters.get_wxapp_openid) //获取当前单品	
		//#endif		
	},
	computed: {
	 
	},
	filters: {
		fee_file(value) {			
		        let realVal = ''
		        if (!isNaN(value) && value!== '') { 
		          let tempVal = parseFloat(value).toFixed(3)
		          realVal = tempVal.substring(0, tempVal.length - 1)
		        } else {
		          realVal = '--'
		        }
		        return realVal
 		}
	},
	methods: {
		home(){
		 	uni.switchTab({
				url: '/pages/index/index'
			}) 
		},
		//#ifdef H5		
		async  _ali_get_code(){ //支付宝授权 获取code
		    const res =  await this.$AjaxRequest_ali({
		    	url: '/get_appid',
		    	method:'POST',
		    	data:{value_data:{'a':'0'}}
		    }).then((res) => { 			
					let urls= window.location.href
					let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
					window.location.href = auth_get_code_url						
		     })				  
		 },
		 async _wx_get_code(){ //微信获取code
		 	   const res_wx = await this.$AjaxRequest({
		 		url: '/get_config',
		 		method:'POST',
		 		data:{value_data:{}}
		 	   })	
		 		let urls= window.location.href
		 		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
		 		 window.location.href = auth_get_code_url
		 	},	
		//#endif		
		//支付尾款
		 pay_r(item){
			//#ifdef H5
			if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端
				let value_data = {'pre_final_price':item.pre_final_price,'wx_openid':item.wx_openid,'pre_order':item.pre_order}
				this.$Basic._final_wx_pay(jweixin,value_data)
			}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				let value_data = {'pre_final_price':item.pre_final_price,'ali_openid':item.ali_openid,'pre_order':item.pre_order}
				this.$Basic._final_ali_pay(value_data)		 
			}
			
		  //#endif
		  //#ifdef MP-WEIXIN
		   let value_data = {'pre_final_price':item.pre_final_price,'wxapp_openid':item.wxapp_openid,'pre_order':item.pre_order}
		   this.$Basic._final_wxapp_pay(value_data)			 
			
	    //#endif	
		},	
		
		 
		 close_order(order_type,order_id){ //关闭订单			
			this.content = "确定取消该订单么?"
			this.show = true
			this.cdata = {'order_type':order_type,'order_id':order_id}	
	    },		
		 
		 close_order_action(){ //取消订单确认
			const res =  this.$AjaxRequest({
				url: 'close_order',
				method:'post',
				data:{value_data:this.cdata}  //
			}).then((res) => {			
				 if(res.sta == 'success'){
                   this.content_result = "订单取消成功！"                   
                }else{
                   this.content_result = "订单取消失败！"
                } 
				this.show_result = true
				
			})			
		},
		result_confirm(){ //结果提示关闭
			this.show_result = false
			//#ifdef H5
			if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				this._get_order_list(this.$store.getters.get_wx_user.openid) //获取订单列表					 
			}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				this._get_order_list(this.$store.getters.get_ali_user.user_id) //获取订单列表				 			 
			}			
			//#endif
			//#ifdef MP-WEIXIN
			this._get_order_list(this.$store.getters.get_wxapp_openid) //获取当前单品	
			//#endif 
		},		
		async _get_order_list(openid){
			  let value
			 //#ifdef MP-WEIXIN
			  value = {'wxapp_openid':openid}
			  //#endif
			  //#ifdef H5
			  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			  	 value = {'wx_openid':openid}			 
			  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
			  	 value = {'ali_openid':openid}			 			 
			  }			  
			  //#endif
			
			let res2 = await this.$AjaxRequest({
				url: 'user_order',
 				method:'post',
				data:{'value_data':value}  //
			}).then((res2) => {
  				 this.order_in = res2.orderIn
                 this.order_fin = res2.orderFi				 
			})
		},
		
		// 总件数
		totalNum(item) {	 
			 return item.length
		}, 
		
		 reachBottom() {
			// 此tab为空数据
		 
		},
		//拨打电话
		tel_me(tel){
			uni.makePhoneCall({
			    phoneNumber: tel  
			})
		},
		 
		// tab栏切换
		change(index) {
			this.swiperCurrent = index;
			//this.getOrderList(index);
		},
		transition({ detail: { dx } }) {
			this.$refs.tabs.setDx(dx);
		},
		animationfinish({ detail: { current } }) {
			this.$refs.tabs.setFinishCurrent(current);
			this.swiperCurrent = current;
			this.current = current;
		}
	}
};
</script>

<style>
/* #ifndef H5 */
page {
	height: 100%;
	background-color: #f2f2f2;
}
/* #endif */
</style>

<style lang="scss" scoped>
.slot-wrap {display: flex;align-items: right;text-align: right;flex: 1;}	
.ico_left{width: 30%;height: auto;float: left;text-align:left;padding-left: 3.333%;}
.ico_center{width: 53.333%;height: auto;float: left;text-align:center;font-size:32rpx;}
.ico_right{width: 10.333%;height: auto;float: right;}	
.cobox_btn{width: 100%;padding: 10rpx;border-top: 1px #f5f5f5 solid;}	
 .mar_left10{margin-left: 10rpx;}
.demo-layout{text-align: right;}

.zxt_ps_box{width: 96%;line-height: 50rpx;height: 50rpx;font-weight: 650;}
.ps_name{float: left;}
.ps_tel{float: right;}

.order {
	width: 710rpx;
	background-color: #ffffff;
	margin: 20rpx auto;
	border-radius: 20rpx;
	box-sizing: border-box;
	padding: 20rpx;
	font-size: 28rpx;
	.top {
		display: flex;
		justify-content: space-between;
		.left {
			display: flex;
			align-items: center;
			.store {
				margin: 0 10rpx;
				font-size: 32rpx;
				font-weight: bold;
			}
		}
		.right {
			color: $u-type-warning-dark;
		}
	}
	.item {
		display: flex;
		margin: 20rpx 0 0;
		.left {
			margin-right: 20rpx;
			image {
				width: 200rpx;
				height: 200rpx;
				border-radius: 10rpx;
			}
		}
		.content {
			.title {
				font-size: 28rpx;
				line-height: 50rpx;
			}
			.type {
				margin: 10rpx 0;
				font-size: 24rpx;
				color: $u-tips-color;
			}
			.delivery-time {
				color: #e5d001;
				font-size: 24rpx;
			}
		}
		.right {
			margin-left: 10rpx;
			padding-top: 20rpx;
			text-align: right;
			.decimal {
				font-size: 24rpx;
				margin-top: 4rpx;
			}
			.number {
				color: $u-tips-color;
				font-size: 24rpx;
			}
		}
	}
	.total {
		margin-top: 20rpx;
		text-align: right;
		font-size: 24rpx;
		.total-price {
			font-size: 32rpx;
		}
	}
	.bottom {
		display: flex;
		margin-top: 40rpx;
		padding: 0 10rpx;
		justify-content: space-between;
		align-items: center;
		.btn {
			line-height: 52rpx;
			width: 160rpx;
			border-radius: 26rpx;
			border: 2rpx solid $u-border-color;
			font-size: 26rpx;
			text-align: center;
			color: $u-type-info-dark;
		}
		.evaluate {
			color: $u-type-warning-dark;
			border-color: $u-type-warning-dark;
		}
	}
}
.btn_left{float: left;}
.centre {
	text-align: center;
	margin: 200rpx auto;
	font-size: 32rpx;
	image {
		width: 164rpx;
		height: 164rpx;
		border-radius: 50%;
		margin-bottom: 20rpx;
	}
	.tips {
		font-size: 24rpx;
		color: #999999;
		margin-top: 20rpx;
	}
	.btn {
		margin: 80rpx auto;
		width: 200rpx;
		border-radius: 32rpx;
		line-height: 64rpx;
		color: #ffffff;
		font-size: 26rpx;
		background: linear-gradient(270deg, rgba(249, 116, 90, 1) 0%, rgba(255, 158, 1, 1) 100%);
	}
}
.wrap {
	display: flex;
	flex-direction: column;
	height: calc(100vh - var(--window-top));
	width: 100%;
	padding-bottom:60rpx;
 }
.swiper-box {
	flex: 1;
}
.swiper-item {
	height: 100%;
}
</style>
