<template>
	<view>
		<u-navbar back-text="返回" title="支付成功"></u-navbar>
			
        <view class="cbox"><img src="~@/static/svg/success2_ico.svg"></view>
        <view class="ctitle">支付成功</view>
        <view class="ctip"><u-icon name="kefu-ermai" size="26"></u-icon> 有问题请及时联系客服咨询！</view>


        <view class="cbtn" @click="home_url()"><u-icon name="arrow-left" size="26"></u-icon>返回首页</view>
        <view class="cctn" @click="order_url()"><u-icon name="order" size="26"></u-icon>返回订单</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
			   wx_user_info:'',	
			}
		},
		onLoad(options){
			let goods_str = options.goods_str
			let order_type = options.order_type
              if(goods_str != ''){
                let reg=/,$/gi;
                let arr=goods_str.replace(reg,"").split(',');//去除逗号-转数组                
                for(let i=0;i<arr.length;i++){
                   let item_arr = arr[i].split('|');
				   if(order_type == 'nor'){
					   this.$store.commit('store_shop_cart_del',{'shop_id':item_arr[0],'id':item_arr[1],'buy_num':item_arr[2]})	
				   }else if(order_type == 'fresh'){
					   this.$store.commit('store_fresh_cart_del',{'shop_id':item_arr[0],'id':item_arr[1],'buy_num':item_arr[2]})
				   }
                }
              }			  
			  //this._get_user() //获取用户信息
		},
		methods: {
			//async _get_user () { //获取用户信息  
					//this.wx_user_info =  this.$store.getters.get_wx_user 				 
			//},
		    home_url(){
               uni.switchTab({
                   url: '/pages/index/index'
               })
            },
            order_url(){
				uni.switchTab({
				    url: '/pages/orders/orders?is_resh=1'
				})
              },
		}
	}
</script>

<style  scoped>
.body{background: white;width:100%;height: 100%;position: absolute;bottom:0;}
    .cbox{width: 100%;height: 20%;text-align:center;padding-top: 25%;}

    .cbox img{ width:180rpx;height: 180rpx;}
    .ctitle{width: 100%;height: 70rpx;line-height: 70rpx;text-align: center;font-weight: 700;font-size: 50rpx;color:#333;}

       .cctn{width: 45%;height: 35px;color:#fff;background: #FFCC00;text-align: center;line-height: 70rpx;margin:0 auto;border-radius: 360rpx;margin-top:20rpx;font-size: 28rpx;}
      .cctn  i{top:4rpx;margin-right: 10rpx;}

    .cbtn{width: 45%;height:70rpx;color:#fff;background: #99CCFF;text-align: center;line-height: 70rpx;margin:0 auto;border-radius: 360rpx;margin-top:20rpx;font-size:28rpx;}
   .cbtn  i{top:4rpx;margin-right:10rpx;}

    .ctip{width: 100%;height:60rpx;text-align: center;color:#999;line-height: 60rpx;font-size: 24rpx;}
   .ctip i{top:4rpx;}
</style>
