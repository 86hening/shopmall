<template>
	<view>
		<u-navbar back-text="返回"  back-icon-size	="30" title="立即购买" >
			<view class="slot-wrap">
				<u-icon name="home" class="axleft"  size="30" @click="home()"></u-icon>
			</view>
		</u-navbar>
		<view class="content">
			<view class="add_box">			
			    <u-input :border="border" type="select" :select-open="selectShow" v-model="address_str" placeholder="请选择配送地址" @click="selectShow = true"></u-input>
			</view>
				<u-line color="#f5f5f5" />

			<view class="items">
				<!---->
				<view class="htop"  v-if="shop_pro_list" v-for="(item,index) in shop_pro_list" :key="index">
               <view class="ht_shop" v-if="item.shop != null  && item.shop !='shop_end'"><u-icon name="grid"  size="28"></u-icon> {{item.shop.shop_name}}</view>
                <view class="ps_fs"  v-if="item.shop != null  && item.shop !='shop_end'">
                   <view class="ps_left">配送方式：</view>
                   <view class="ps_right">					 
						<u-radio-group v-model="item.shop.ps_fs_placeholder">							
							<u-radio @change="radioChange(item.shop,$event)"  name="0"  :disabled="false" >自取</u-radio>
							<u-radio @change="radioChange(item.shop,$event)"  name="1" v-if="item.shop.ps_fs == 0" :disabled="true" >配送</u-radio>
							<u-radio @change="radioChange(item.shop,$event)"  name="1" v-else=""  :disabled="false" >配送</u-radio>						 
					</u-radio-group>					
						
                   </view>
                   <view class="clear"></view>
               </view>
               <view class="ps_fs"  v-if="item.shop != null  && item.shop !='shop_end'  && coupon_list[item.shop_id] !='' ">
                   <view class="ps_left">优惠卡券：</view>
                   <view class="ps_right">				 
                           <text class="testyle"  @click="open_coupon(item.shop_id)" v-text="coupon_title[item.shop_id]"></text>
                           <u-select v-model="show_select" mode="single-column" :list="coupons_lists2" value-name="values" label-name="labels"  @confirm="change_coupon"></u-select>
                   </view>
                   <view class="clear"></view>
               </view>
              <view class="notice_box"   v-if="item.shop != null  && item.shop !='shop_end'">
                   <view class="notice_left">备注信息：</view>
                   <view class="notice_right">
					   <u-input  type="textarea" :border="notice_border" border-color="#f5f5f5" height="35" @input="change_notice(item.shop_id,$event)"  />
                          
                   </view>
               </view>
               <view class="ht_pro">
                               <view class="pro_left"><img :src="item.pic"></view>
                              <view class="pro_right">
                                  <view class="pro_title">{{item.product_name}}</view>
                                  <view  class="pro_price"><span class="price_font">￥{{item.retail_price}}</span><span class="fnum">× {{item.buy_num}}</span> <span class="fright">￥{{item.retail_price * item.buy_num}}</span></view>
                              </view>
                              <view class="clear"></view>
                </view>

              <view class="price_box" v-if="item.suffix == 'show'">
                        <ul>
                            <li><u-icon name="rmb-circle" size="36"></u-icon> 总价：￥<span class="price_sty">{{item.fee_item.pro_total}}</span></li>
                            <li><u-icon name="rmb-circle" size="36"></u-icon>配送：
                                <span class="price_sty">￥{{delivery_fee[item.shop_id]}}</span>
                             </li>
                            <li><u-icon name="rmb-circle" size="36"></u-icon>包装：<span class="price_sty">￥{{packag_fee[item.shop_id]}}</span></li>
                            <li><u-icon name="rmb-circle" size="36"></u-icon>支付：<span class="price_sty">￥{{all_price[item.shop_id]}} </span></li>
                            <view class="clear"></view>
                        </ul>
               </view>

           </view>
				<!---->
				
			</view>
	 
		</view>
		
		<u-toast ref="uToast" />		
		<u-modal v-model="show_modal" :title='title_modal' :content="dialog_content" @confirm="confirm_psfs"></u-modal>
		<u-select mode="single-column" :list="address_list" label-name="text" value-name="id" v-model="selectShow" @confirm="selectConfirm"></u-select>
 	    <!---->
	     <view class="navigation">			 
	     	<view class="left">		    		
	     	 
	     		<view class="item_bar car">
	     			 <text class="vtext">合计 :</text>  {{pay_price | showPrice}}
	     		</view>
	     	</view>
	     	<view class="right">
	     		<view class="cart btn u-line-1" @click="pay_order">立即支付</view>
	     	</view>
	    	</view>	
	    <!---->
	
	    
	
	
	</view>
</template>

<script>
	//#ifdef H5
	  let jweixin = require('jweixin-module');
	//#endif
	export default {
		data() {
			return {
				coupon_title:[],
				coupons_lists2:[],
				show_select: false,
				query_String:'',
				address_str:'', //默认地址
 				address_default_arr:'', //默认地址信息
				address_sid:'',
				address_list: [],
				type :'',
				buy_str:[],
                shop_pro_list:{},
                f_str:'', //商铺ID+商品ID+数量组合
                f_notice:[], //备注信息数组
                f_ps_fs:[], //配送方式数组默认创建
                f_shop_total:[],//每个商铺的总价-不含配送费+包装费
                delivery_fee:[], //清单：配送费用
                packag_fee:[], //清单：包装费用
                coupon_list:[], //清单：店铺结算当前可使用卡券列表
                coupon_num_arr:[], //清单：本次支付使用的卡券编号
                coupon_fee_arr:[], //清单：本次支付使用的卡券抵扣金额
                all_price:[], //清单：支付金额
                shop_mf:[], //是否免配送费
                pay_price : 0.00 , //本单支付费用
                show_pop:false, //展示弹出框
                radio_selected:'',  //默认选项地址I
                wx_openid:'',
                wx_user_info:'',							 
				border: false,			
				selectShow: false,  
			   notice_border:true,
			   show_modal:false,		 
			   dialog_content:'',
			   title_modal:'',
			   change_psfs_data:'', //配送方式切换临时数据
			   couponSelected:'',			   
			}
		},
		 
		created(){
 		 
			let _that = this
			//#ifdef H5
			let url_s = window.location.href.split("#")[0];  //当前url去掉#及后面所有
			const res_wx = _that.$AjaxRequest({
				url: 'get_jssdk',
				method:'post',
				data:{value_data:{'url':url_s}}
			}).then((res_wx) => {
				 jweixin.config({
				    debug: false, // 开启调试模式,
				    appId: res_wx.data.appId, // 必填，企业号的唯一标识，此处填写企业号corpid
				     timestamp: res_wx.data.timestamp, // 必填，生成签名的时间戳
				    nonceStr: res_wx.data.nonceStr, // 必填，生成签名的随机串
				     signature: res_wx.data.signature,// 必填，签名，见附录1
				     jsApiList: [   // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
				        'chooseWXPay',
				        'getLocation',
				        'getNetworkType',
				        'openLocation',
				        'showOptionMenu',
				        'closeWindow',
				        'scanQRCode',
				       ]
				  });				
			 })     
			//#endif
			
		},		 
		onLoad(options){
			this.query_String = options	
			this.buy_str = options.buy_str
			this.type = options.type	
		 
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }
				 this._user_address_list (this.$store.getters.get_wx_user.openid) //获取用户地址
				 this._fresh_pay_order(this.$store.getters.get_wx_user.openid) //获取 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	  				
				this._user_address_list (this.$store.getters.get_ali_user.user_id) //获取用户地址
				this._fresh_pay_order(this.$store.getters.get_ali_user.user_id) //获取  
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}		 
			this._user_address_list(this.$store.getters.get_wxapp_openid) //获取用户地址
			this._fresh_pay_order(this.$store.getters.get_wxapp_openid) //获取  
			//#endif	
			 
		},
		mounted(){
			let buy_arr = this.buy_str.split('|')
            this.f_str = this.buy_str
            this.f_ps_fs[buy_arr[0]]  = '0'  // 0，0，0，
            this.f_notice[buy_arr[0]] ='null'// null,null,null 
			this.coupon_title[buy_arr[0]] = '选择优惠券'
           //配送初始化end		  
		   //this._fresh_pay_order() //执行获取结算列表
 
		},
		methods: {
			change_notice(shop_id,e){ //处理备注信息
				 if(e == ""){
                    this.f_notice[shop_id] = 'null'
                 }else{
                    this.f_notice[shop_id] = e
                 } 
			},			
			pay_order(){ //最终确认
				let notice_str=''
                for (var index in this.f_notice){//这里需要使用for in语句进行访问
                    notice_str += index+'|'+this.f_notice[index]+',' // 商铺ID|null    , 商铺ID|'用户填写的单信息'
                }
                let psfs_str = '';
                for (var index in this.f_ps_fs){//这里需要使用for in语句进行访问
                    psfs_str += index+'|'+this.f_ps_fs[index]+','  //[5|0|3|1]  //商铺ID|配送方式0/1
                }
               let   all_price_str = ''
                for (var index in this.f_shop_total){//这里需要使用for in语句进行访问
                    all_price_str += index+'|'+this.f_shop_total[index]+','  //每家商铺的总钱数
                }
                let  coupon_num = ''
                 for (var index in this.coupon_num_arr){//这里需要使用for in语句进行访问
                     if(this.coupon_num_arr[index]  != ''){
                           coupon_num+= index+'|'+this.coupon_num_arr[index]+','  //每家商铺的使用该卡券号
                     }else{
                          coupon_num+= index+'|null,'  //每家商铺的使用该卡券号
                     }
                }
                    let  coupon_fee = ''
                 for (var index in this.coupon_fee_arr){//这里需要使用for in语句进行访问
                    coupon_fee += index+'|'+this.coupon_fee_arr[index]+','  //每家商铺的卡券抵扣金额
                }

               // console.log("商品信息："+this.f_str)  //商铺ID+商品ID+数量组合
               // console.log("店铺总价："+all_price_str) //备注字符串格式
               // console.log("备注信息："+notice_str) //备注字符串格式
               // console.log("配送信息："+psfs_str) //备注字符串格式
               // console.log("支付总价："+this.pay_price) //支付总价 元
               // console.log("用户地址："+this.address_sid) //用户地址ID
               // console.log("用户地址："+this.wx_openid) //用户ID
               // console.log("用户卡券：" + coupon_num) //用户ID
               // console.log("抵扣金额："+ coupon_fee) //
			    //#ifdef MP-WEIXIN
			     let orders_data={
			              goods_str : this.f_str,
			              count_price_shop :  all_price_str,
			              notice_shop : notice_str,
			              psfs_shop :  psfs_str,
			              coupon_num:coupon_num,
			              coupon_fee:coupon_fee,
			              count_all_price :  (this.pay_price),
			              address_id : this.address_sid,
			              wxapp_openid:this.$store.getters.get_wxapp_openid,
			              type:'fresh',
			      }	
				  this.$Basic._wxapp_pay(orders_data)					 
			     //#endif
			     //#ifdef H5
					 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端
						 let orders_data={
								  goods_str : this.f_str,
								  count_price_shop :  all_price_str,
								  notice_shop : notice_str,
								  psfs_shop :  psfs_str,
								  coupon_num:coupon_num,
								  coupon_fee:coupon_fee,
								  count_all_price :  (this.pay_price),
								  address_id : this.address_sid,
								  wx_openid:this.$store.getters.get_wx_user.openid,
								  type:'fresh',
						  }	
						   this.$Basic._wx_pay(jweixin,orders_data)							 
					 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						 let orders_data={
								  goods_str : this.f_str,
								  count_price_shop :  all_price_str,
								  notice_shop : notice_str,
								  psfs_shop :  psfs_str,
								  coupon_num:coupon_num,
								  coupon_fee:coupon_fee,
								  count_all_price :  (this.pay_price),
								  address_id : this.address_sid,
								  ali_openid:this.$store.getters.get_ali_user.user_id,
								  type:'fresh',
						  }	
  						  this.$Basic._ali_pay(orders_data)			
					 }					 
			     //#endif
			}, 
		   //配送选项
			radioChange(shop,e) {
			    let  dialog_title
                let  dialog_msg
                let  other_price   //其它费用，包含配送+包装
                let  packag_fee   //包装费
                let  delivery_fee  //配送费
                let  ac_type    //操作类型 0 减去 1 增加
				this.title_modal = shop.shop_name+"提示您"+this.f_ps_fs[shop.id]+"：\n";
				 if(this.f_ps_fs[shop.id]  == '0' && e == '1'){ //之前自取，现在配送 +
                     if(this.shop_mf[shop.id]  == 1) { //满额，可免配送费与包装费
                              this.dialog_content = "您已选择配送上门\n本店购物总价满"+this.f_shop_total[shop.id].toFixed(2)+"元\n本次订单免配送费与包装费"
                              other_price =  0
                              packag_fee = '0.00'
                              delivery_fee = '0.00'
                             ac_type = 1
                         }else{ //额度不足
                             this.dialog_content = "本店满"+shop.full_price+"元免配送费与包装费\n本次您需要支付配送费"+shop.delivery_fee+"元,包装费"+shop.packag_fee+"元"
                             other_price =  parseFloat(shop.delivery_fee) + parseFloat(shop.packag_fee)
                             packag_fee = parseFloat(shop.packag_fee).toFixed(2)
                              delivery_fee = parseFloat(shop.delivery_fee).toFixed(2)
                            ac_type = 1
                        }						 
                }else if(this.f_ps_fs[shop.id]  == '1' && e == '0'){ //之前配送，现在 自提 -	
                             if(this.shop_mf[shop.id]  == 1) { //满额，可免配送费与包装费
                                 other_price =  0
                                packag_fee = 0
                                delivery_fee = 0
								this.dialog_content = "1您已选择门店自取,请及时到店内取走您的商品,感谢配合"
                             }else{ //未到达免单额度
                                  other_price =  parseFloat(shop.delivery_fee) + parseFloat(shop.packag_fee)
                                 packag_fee = parseFloat(shop.packag_fee).toFixed(2)
                                delivery_fee = parseFloat(shop.delivery_fee).toFixed(2)
                                 this.dialog_content = "您在本店本次共需支付"+(parseFloat(this.f_shop_total[shop.id]) - parseFloat(other_price) ) +"元\n请及时到店内取走您的商品,感谢配合"
                                 ac_type = 0
                            }						 
                 }
 				
				this.change_psfs_data = {
					'shop' : shop,
					'other_price' : other_price,
					'packag_fee' :packag_fee,
					'delivery_fee' : delivery_fee,
					'ac_type' : ac_type,
					'ps_fs' :e , //配送方式
				}
				this.show_modal = true;	 		   
			},
			confirm_psfs(){ //配送切换确认	 
				let ac_type = this.change_psfs_data.ac_type
				let ps_fs = this.change_psfs_data.ps_fs
				let shop = this.change_psfs_data.shop
				let other_price = this.change_psfs_data.other_price
				let shop_id = this.change_psfs_data.shop.id
				let packag_fee = this.change_psfs_data.packag_fee
				let delivery_fee = this.change_psfs_data.delivery_fee
				
				if(ac_type == '0'){ // -
                    this.f_shop_total[shop_id] -= parseFloat(other_price)//单位 元  增加商铺总额
                    this.pay_price  -= parseFloat(other_price) //单位元    增加订单支付总额
                    this.delivery_fee[shop_id] = '0.00'; //配送费
                    this.packag_fee[shop_id] = '0.00'; //包装费.
                }else if(ac_type == '1'){ // +
                    this.f_shop_total[shop_id] += parseFloat(other_price) //单位 元  增加商铺总额
                    this.pay_price  += parseFloat(other_price)//单位元   增加订单支付总额
                    this.delivery_fee[shop_id] = delivery_fee; //配送费
                    this.packag_fee[shop_id] = packag_fee; //包装费
                }
                this.f_ps_fs[shop_id] = ps_fs   // 【5|0，6|1】
                this.all_price[shop_id] =  this.f_shop_total[shop_id]; //总支付费用				
			},
			open_coupon(shop_id){ //打开卡券
				this.coupons_lists2 = Object.values(this.coupon_list[shop_id])				 
				this.show_select = true
			},
			change_coupon(event){ //使用卡券部分
			  let value = event[0]['value']
			  let coupon_array = value.split('/')  //0商铺   1、抵扣额度  2、卡券号
			   let shop_id = coupon_array[0] //商铺
			   let deduct_price = coupon_array[1] //抵扣的额度
			   let coupon_num = coupon_array[2] //卡券编号
			  				
			  	 this.coupon_title[shop_id] = event[0]['label']		
                if(coupon_num != 0 && deduct_price != 0){ //卡号不为空，抵扣金额不为空				     
                       //如果是初次选择卡券
                      if(this.coupon_fee_arr[shop_id] != '' && this.coupon_fee_arr[shop_id] > 0){ //之前选择1个后重新选择卡券
					      //console.log('二次使用')
                          let acount = (parseFloat(this.all_price[shop_id]) +  parseFloat(this.coupon_fee_arr[shop_id]) ).toFixed(2) //总价先把之前减去的价格补上
                          this.pay_price  = (parseFloat(this.pay_price) + parseFloat(this.coupon_fee_arr[shop_id])).toFixed(2)//单位元
						  this.all_price[shop_id] = (parseFloat(acount) - parseFloat(deduct_price)).toFixed(2) //原始价格按照新卡券重新扣除
						  this.pay_price  =  parseFloat(parseFloat(this.pay_price) - parseFloat(deduct_price)).toFixed(2) //单位元    增加订单支付总额
                      }else{ //之前未使用，初次选择
					     //console.log('初次选择')
                          this.all_price[shop_id] -= parseFloat(deduct_price) //
                          this.pay_price  -= parseFloat(deduct_price) //单位元    增加订单支付总额
                      }
                      this.coupon_fee_arr[shop_id]  = parseFloat(deduct_price)
                     this.coupon_num_arr[shop_id] = coupon_num
                  }else{ //空--选择不使用卡券
				     //console.log('不使用卡券')
                     if(this.coupon_fee_arr[shop_id] != '' && this.coupon_fee_arr[shop_id] > 0){ //原来选择卡券，后取消使用卡券
                           this.all_price[shop_id] = (parseFloat(this.all_price[shop_id]) +  parseFloat(this.coupon_fee_arr[shop_id]) ).toFixed(2)
                           this.pay_price  =  (parseFloat(this.pay_price) +  parseFloat(this.coupon_fee_arr[shop_id]) ).toFixed(2)//单位元    增加订单支付总额
                      }else{
                          this.all_price[shop_id] +=0 //原来未使用，选择也未使用
                       }
                   this.coupon_fee_arr[shop_id]  = '0'
                   this.coupon_num_arr[shop_id] = ''
                  }		
			},
			 
			 // 选择地址回调
			 selectConfirm(e) {
			 	 this.address_str = '';		 
			 	e.map((val, index) => {
					 this.address_sid = val.value
			 		this.address_str += this.address_str == '' ? val.label : '-' + val.label;
			 	})
			 },		
			//#ifdef H5	 
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			   },
				async _wx_get_code(){ //微信获取code
				   const res_wx = await this.$AjaxRequest({
					url: '/get_config',
					method:'POST',
					data:{value_data:{}}
				   })	
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					 window.location.href = auth_get_code_url
				},			 
			 //#endif
			//获取结算列表
			async _fresh_pay_order(openid) { //获取结算列表	
 				//#ifdef MP-WEIXIN
				   let value = {type:'fresh',f_str:this.buy_str,'wxapp_openid':openid}
				  //#endif
				  //#ifdef H5
				  let value
				   if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端
				   	   value = {type:'fresh',f_str:this.buy_str,'wx_openid':openid}
				   }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				   	   value = {type:'fresh',f_str:this.buy_str,'ali_openid':openid}		 
				   }
				  
				  //#endif
				  //console.log(value)
				const res = await this.$AjaxRequest_fresh({
					url: 'fresh_pay_order',
					method:'post',
					data:{value_data:value} 
				}).then((res) => {
					//console.log(res)
					 if(res.sta == 'success'){
                        this.shop_pro_list = res.data //商品罗列
                        this.f_shop_total = res.all_pirce  //单个商铺总价--不含配送费+包装费
                        this.delivery_fee = res.delivery_fee //配送费
                        this.packag_fee = res.packag_fee //包装费
                        this.all_price = res.all_price //支付金额
                        this.shop_mf = res.shop_mf //是否免配送费
                        this.coupon_list = res.coupon_list //卡券列表
                        this.coupon_num_arr = res.coupon_num_arr //本次结算使用的卡券			 
                        this.coupon_fee_arr = res.coupon_fee_arr //本次结算使用的卡券抵扣金额
                           //支付总价计算start
                        let totalPrice = 0;
                         for (let i in this.shop_pro_list) {
                            totalPrice += this.shop_pro_list[i].retail_price * this.shop_pro_list[i].buy_num
                        }
                        this.pay_price =   totalPrice  //元
                        //支付总价计算end
                     }
				}) 	 
			},	
			//获取地址列表  
			async _user_address_list (openid){ //获取地址列表	
				//#ifdef MP-WEIXIN
				   let value = {'wxapp_openid':openid}
				  //#endif
				  //#ifdef H5
				  let value
				  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端
				  	 value  = {'wx_openid':openid}
				  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				  	 value = {'ali_openid':openid} 			 
				  }
				  
				  //#endif
				const res = await this.$AjaxRequest({
					url: 'address_select',
					method:'post',
					data:{value_data:value} 
				}).then((res) => {					 
					if(res.sta =='success'){
                        this.address_list = res.data
                        this.address_default_arr = res.default_arr
						this.address_str =  res.default_arr.text
						this.address_sid = res.default_arr.id						
                    }else{
						    this.$refs.uToast.show({
						    title: '请添加一个默认地址!',
							url: '/pages/users/address_add'
						})	                     
                    }
				}) 	 
			},			
			home(){
				uni.switchTab({
				   url: '/pages/index/index'
				})
			},
		},
		 filters: {            
           showPrice: function(price){
                   let priceStr = new Number(price).toFixed(2)
                   return "￥" + priceStr
                }
         },
		
		 
		 
	}
</script>

<style  lang="scss" scoped>
.testyle{line-height:60rpx;}
.slot-wrap {display: flex;align-items: right;text-align: right;flex: 1;}	
.axleft{margin-left:90%;}
.items{padding-bottom: 150rpx;}
.add_box{width: 98%;margin:0 auto;}
.vtext{color:#333;font-size: 24rpx;}
.select_type{background: white;border:2rpx #f5f5f5 solid;height: 60rpx;line-height: 60rpx;color:#666;}
.ps_fs{width: 98%;height: 70rpx;margin:0 auto;border-bottom: 2rpx #f5f5f5 solid;background: white;font-size: 26rpx;}
  .ps_left{width: 25%;height: 70rpx;float: left;line-height: 70rpx;}
  .ps_right{width: 75%;height: 50rpx;float: right;padding-top:4rpx;}

    .notice_box{width: 98%;height: 70rpx;margin:0 auto; line-height: 70rpx;background: white;font-size: 26rpx;}
    .notice_left{width: 25%;height: 70rpx;float: left;}
    .notice_right{ width: 75%;height:70rpx;float: right;padding-top: 10rpx;}
    .van-cell{padding: 0px;margin: 0;height: 70rpx;background: #f7f7f7;line-height: 70rpx;background: white;}


    .price_box{width: 98%;height: auto;margin: 0 auto;border-top: 2px #f5f5f5 solid;padding-top: 20rpx;background: white;}
     .price_box  li{width: 40%;height: 60rpx;float: left;color:#666;font-size: 26rpx;margin-left: 5%;line-height: 60rpx;}
      .price_box   i{top:4rpx;}
      .price_sty{color:#666;font-size: 26rpx;font-weight: 650;padding-right: 2%;}

   .htop{width: 98%;height: auto;margin:0 auto;background: white;}
    .ht_shop{width: 100%;height: 80rpx;font-size:28rpx;line-height: 80rpx;border-bottom: 2rpx #f3f3f3 solid;background: white;text-overflow: -o-ellipsis-lastline;
  overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 1; line-clamp: 1; -webkit-box-orient: vertical;margin-top:20rpx;}
      .ht_shop i{top:2px;}
    .ht_pro{width: 100%;height: 160rpx;background: white;padding-bottom: 10rpx;}

    .pro_left{width: 30%;height: 160rpx;float: left; overflow: hidden;}
    .pro_left img{width: 90%;height: 90%;margin-top: 5%;}
    .pro_right{width: 70%;height: 160rpx;float: right; }
   .pro_title{width: 98%;height: 80rpx;line-height: 40rpx;font-size: 26rpx;color:#666; text-overflow: -o-ellipsis-lastline;
  overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
 .pro_price{width: 96%;height: 60rpx;line-height: 60rpx;font-size: 26rpx;}
 .price_font{color:#666;}
 .fright{float: right;font-weight: 650;color:#9bd439;}
 .fnum{color:#666;}
 .navigation {
     	display: flex;
     	border: solid 2rpx #f2f2f2;
     	background-color: #ffffff;
     	padding: 12rpx 0;
 		position: fixed;bottom: 0;	
 		 width: 100%;
		height: 100rpx;
     	.left {
     		display: flex;
     		font-size: 20rpx;
     		.item_bar {
      			margin: 0 36rpx;
     			&.car {
     				text-align: center;
     				position: relative;		
 				    color:#9bd439;					 
 					margin-top: 10rpx;
 					font-size: 28rpx;
     				.car-num {
     					position: absolute;
     					top: -10rpx;
     					right: -10rpx;
     				}
     			}
     		}
     	}
     	.right {
     		display: flex;
     		font-size: 28rpx;
     		align-items: right;			 
     		.btn {
     			line-height: 66rpx;
     			padding: 0 30rpx;
     			border-radius: 36rpx;
     			color: #ffffff;
 				position: absolute;
 				right: 10rpx;
     		}
     		.cart {
     			background-color: #9bd439;
     			margin-right: 10rpx;				
     		}
     		 
     	}
     } 
</style>
