<template>
	<view>
		<view>				
			 <u-navbar :is-back="false"   >
				<view class="slot-wrap">
					<view class="ico_left">
						<u-icon name="home" size="30" @click="home()"></u-icon>
					</view>
					 <view class="ico_center"> 购物车 </view>
					<view class="ico_right">
						<u-icon name="trash" size="30"  @click="clear_cart()"></u-icon>
					</view>
					<view class="clear"></view>
				</view>		
			 </u-navbar>
		</view>		
		<view class="content">
		
		 <!-- -->			 
		<u-checkbox-group @change="checkboxGroupChange">
			  <view  class="cbox">
				<view v-if="fresh_cart_list == '' ">
					<view class="centre">
						<image src="https://cdn.uviewui.com/uview/template/taobao-order.png" mode=""></image>
						<view class="explain">
							您的菜篮子空空如也！
							<view class="tips">可以去看看有那些想买的</view>
						</view>
						<view class="btn">随便逛逛</view>
					</view>
				</view>  
				  
				  
			  <u-swipe-action :show="item.show" :index="index" v-if="fresh_cart_list != '' " v-for="(item, index) in fresh_cart_list" :key="item.id" @click="click(index,item.id)" @open="open"  :options="options">
						<view class="item u-border-bottom">							
			  				<view>
							   <view class="checkbox">  
								   <u-checkbox  @change="checkboxChange" :name="item.id" v-model="item.checked"></u-checkbox>
								</view> 
							 <image mode="aspectFill" :src="item.thum" />
							 </view>
			  				<view class="title-wrap">
								<view class="pro_item">
								    <view class="pro_title">{{item.product_name}}</view>
								    <view class="pro_other">
								    <view class="pro_price">￥{{item.retail_price}}</view> 
								          <view class="pro_num">   
											  <u-number-box  v-model="item.buy_num" :long-press="false" :min="1"  :max="10" :step="1"  @change="valChange(item.id,$event)" ></u-number-box>											   
								         </view>
								        <view class="clear"></view>
								    </view>
								</view>		  					 
			  				</view>
			  			</view>						
			 </u-swipe-action>
			 </view>
		   </u-checkbox-group>
			  <!---->
		</view>
		
		<!---->
		<view class="navigation">			 
		 	<view class="left">		    		
		 		<view class="item_bar">
						<u-button @click="checkedAll" class="qx_btn" size="mini" :type="qx_sta" shape="circle" v-text="qx_title">全选</u-button>
		 		</view>
		 		<view class="item_bar car">
		 			 <text class="vtext">合计：</text>  {{all_price|fixed_price}}
		 		</view>
		 	</view>
		 	<view class="right">
		 		<view class="cart btn u-line-1" @click="pay_order">立即结算</view>
		 	</view>
			</view>
		<!---->
		<u-toast ref="uToast" />
	</view>
</template>

<script> 	
	export default {		 
		data(){
			 return {				 
 				wx_user_info:'',
				fresh_cart_list:'',  //购物车列表
				disabled: false,
				btnWidth: 180,
				show: false,				 
				qx_sta:'default', //全选状态
				qx_title:'全选',
				result: [],  //存储复选框的值， 数组格式
			    checkeds:false,
				all_price:0.00, //总价
				options: [				
					{
						text: '删除',
						style: {
							backgroundColor: '#fa3534'
						}
					}
				]
			 }
		 },
		 created() {			  
			
		 },
		 onShow(){
			 this.all_price = '0.00' 
			 //#ifdef H5
			  this._get_fresh_cart_list() //获取购物车列表商品
			  //#endif
			  //#ifdef MP-WEIXIN
			  if(this.$store.state.fresh_cart.Shop_cart != ""){
				   this._get_fresh_cart_list() //获取购物车列表商品
			  }else{
				  this.fresh_cart_list = ""
			  }			 
			 //#endif
			 
			 this.qx_sta = 'default'
			 this.qx_title = '全选'
		 },		 
		 onLoad(options) {
			 uni.hideTabBar()	 	
			 //this.$store.commit('get_shop_num',this.$store.getters.fresh_nums)
			
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }				 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}				 
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	 		
			//#endif
			 
		   this._get_fresh_cart_list() //获取购物车列表商品
  		 },
		 methods:{
			 home(){
 				uni.switchTab({
				   url: '/pages/index/index'
				}) 
			 },
			 //#ifdef H5	
			 async  _ali_get_code(){ //支付宝授权 获取code
			     const res =  await this.$AjaxRequest_ali({
			     	url: '/get_appid',
			     	method:'POST',
			     	data:{value_data:{'a':'0'}}
			     }).then((res) => { 			
			 			let urls= window.location.href
			 			let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
			 			window.location.href = auth_get_code_url						
			      })				  
			  },
			 async _wx_get_code(){ //微信获取code
			 	   const res_wx = await this.$AjaxRequest({
			 		url: '/get_config',
			 		method:'POST',
			 		data:{value_data:{}}
			 	   })	
			 		let urls= window.location.href
			 		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
			 		 window.location.href = auth_get_code_url
			 	},	
			//#endif		
 			 async _get_fresh_cart_list () { //获取购物车列表信息
				 if(this.$store.state.fresh_cart.fresh_cart != ""){
					 let reg=/,$/gi;
					  let arr = this.$store.state.fresh_cart.fresh_cart.replace(reg,"").split(',')							 
					  let cstr="";
					  for(let i=0;i<arr.length;i++){
						   let arr_item = arr[i].split('|')
						   cstr += arr_item[1]+'|'+arr_item[2]+','  //保留商品ID | 商品数量,
					  }
					 cstr = cstr.replace(reg,"");//去除逗号  5|10,6|8
					 console.log(this.$store.state.fresh_cart.fresh_cart )
					 console.log(cstr)
					const res = await this.$AjaxRequest_fresh({
							url: 'fresh_cart',
								method:'post',
								data:{value_data:{type:'fresh',pro_str:cstr}}  //
						}).then((res) => {  
							this.fresh_cart_list =  res.data 					 
						}) 
				 } 	
			
			 },	
			 valChange(id,e) { //编辑数量 
				  let reg_pat = new RegExp(String.raw`(\d{1,}\|${id}\|)(\d{1,})(\|\d{1,}\|)([\.|\d]{1,})`); //取数量
				  let result_t = this.$store.state.fresh_cart.fresh_cart.match(reg_pat); //匹配原始数量判断是增是减
				  //判断是否在选中状态 [10,50,15]
				  if(this.result.includes(id)) { //存在   
					if(result_t != null){					
                        if(e.value > result_t[2]){  //增加2  3 +
                           this.all_price  += parseFloat(result_t[4])  //单位  元
                        }else if(e.value < result_t[2]){ //减少
                          this.all_price  -= parseFloat( result_t[4])  //单位  元
                        }						
                    }	
					this.$refs.uToast.show({
					    title: '编辑成功！',			
					})						  
				  } 
				  this.$store.commit('store_fresh_cart_edit',{'id':id,'num':e.value})
				  //this.$store.commit('get_shop_num',this.$store.getters.Shop_nums)	
				  
			  },
			 click(index) { //删除操作
			     console.log(index)				 
				  //计算价格部分  [10,50,15]
                  if(this.result.includes(this.fresh_cart_list[index]['id'])) { //存在
                        let this_all_price = parseFloat(this.fresh_cart_list[index]['buy_num']) *  parseFloat(this.fresh_cart_list[index]['retail_price'])   //单位元
                        this.all_price  -=   this_all_price  //元
                        //将该ID从result选框结果中删除                   
                  }				  
                 ///
		 
               this.$store.commit('store_fresh_cart_del',{'shop_id':this.fresh_cart_list[index]['shop_id'],'id':this.fresh_cart_list[index]['id'],'buy_num':this.fresh_cart_list[index]['buy_num'],'index':index})
			  // this.$store.commit('get_shop_num',this.$store.getters.Shop_nums) 
				 
				this.fresh_cart_list.splice(index, 1);
				this.$u.toast(`已移除商品`);  
			 },
			 // 如果打开一个的时候，不需要关闭其他，则无需实现本方法
			 open(index) {
 				this.fresh_cart_list[index].show = true;
 					 this.fresh_cart_list.map((val, idx) => {
 					 if(index != idx) this.fresh_cart_list[idx].show = false;
 				 })	
			 }, 			 
			 clear_cart(){ //清空购物车			    
			    this.$store.commit('store_fresh_cart_clear',"")
				//this.$store.commit('get_shop_num',0)
				this.$refs.uToast.show({
				    title: '已清空购物车!',
					type: 'success',
					isTab:true,
					url: '/pages/index/index'
				})
			},			
			checkboxChange(e) { // 选中某个复选框时，由checkbox时触发
  				if(e.value == true){ //选中	     
 					console.log("选中："+e.name +'---'+ e.value)
				}else{ //取消
 					console.log("取消"+e.name +'---'+ e.value)					
				}					
					
			},			
			checkboxGroupChange(e) { // 选中任一checkbox时，由checkbox-group触发 -- 组合选中项目	
				 if(e.length == this.fresh_cart_list.length){ //全选
					 this.qx_sta = 'primary'
					 this.qx_title = '取消'
				 }else{
					 this.qx_sta = 'default'
					 this.qx_title = '全选'
				 }
				 this.result = e
				 //计算总价
				 let  new_all_price = 0;
                 for(let i=0;i<this.result.length;i++){   // [10,50,15]
                        let reg_pat = new RegExp(String.raw`(\d{1,}\|${this.result[i]}\|)(\d{1,})(\|\d{1,}\|)([\.|\d]{1,}\,)`);
                        let result_t = this.$store.state.fresh_cart.fresh_cart.match(reg_pat);
                        if(result_t != null) { //匹配成功，更新为最新数量
                             new_all_price += (parseInt(result_t[2] ) *  parseFloat(result_t[4]))
                        }
                 }
				 this.all_price =  new_all_price //元
			},
			checkedAll(e) {	// 全选	
  
				if(this.$store.getters.fresh_nums == 0){
					this.$u.toast(`购物车空空如也！`); 
				}else{
					if(this.qx_sta == 'default'){ //全选
									   this.qx_sta = 'primary'
									   this.qx_title = '取消'
									   this.fresh_cart_list.map(val => {
									   		val.checked = true;
									   })
									   let totalPrice = 0;
									   for (let i in this.fresh_cart_list) {
									        totalPrice += this.fresh_cart_list[i].retail_price * this.fresh_cart_list[i]['buy_num']
											this.result.push(this.fresh_cart_list[i]['id'])
									   }				   
									 this.all_price =   totalPrice //元				  
					}else if(this.qx_sta == 'primary'){ //取消全选
									   this.qx_sta = 'default'
									   this.qx_title = '全选'
									   this.fresh_cart_list.map(val => {
									   		 val.checked = false;
									   })
									   this.all_price =  0.00
									   this.result = []
					}	
				}
			  		  
			},
			pay_order(){ //提交订单
				if(this.result == ""){
 					this.$u.toast(`请至少选择一件商品支付`); 
				}else{
  					uni.navigateTo({
					   url: '/pages/shop_cart/fresh_order?id_str='+this.result.join("|")+'&type=fresh'
					})
				    
				 }
			},	 	
		 },
		filters: {
			fixed_price (value) {
				let avalue = parseFloat(value).toFixed(2)
			    return avalue
			}
		}, 
	}
</script>

<style lang="scss" scoped>
.slot-wrap {display: flex;align-items: right;text-align: right;flex: 1;}	
.ico_left{width: 30%;height: auto;float: left;text-align:left;padding-left: 3.333%;}
.ico_center{width: 53.333%;height: auto;float: left;text-align:center;font-size:32rpx;}
.ico_right{width: 10.333%;height: auto;float: right;}

.axleft{margin-left:90%;}
.item {display: flex;padding: 20rpx;}	
image {width: 160rpx;flex: 0 0 120rpx;height: 160rpx;margin-right: 20rpx;border-radius: 12rpx;}	
.title {text-align: left;font-size: 28rpx;color: $u-content-color;margin-top: 20rpx;}
.pro_item{width: 100%;height:auto;color:#666;float: right;}
.pro_title{width: 98%;height:auto;text-overflow: -o-ellipsis-lastline;
  overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;line-height:44rpx;}
.checkbox{position:absolute;width: 10rpx;height: 10rpx;z-index: 999;}
.content{padding-bottom: 120rpx;}
.cbox{width:750rpx;}
.qx_btn{margin-top: 10rpx;}
.vtext{color:#333;font-size: 24rpx;}
 .navigation {
     	display: flex;
     	margin-top: 200rpx;
     	border: solid 2rpx #f2f2f2;
     	background-color: #ffffff;
     	padding: 12rpx 0;
		position: fixed;bottom: 0;	
		 width: 100%;
		 height: 90rpx;
     	.left {
     		display: flex;
     		font-size: 20rpx;
     		.item_bar {
      			margin: 0 36rpx;
     			&.car {
     				text-align: center;
     				position: relative;		
				    color:#9bd439;					 
					margin-top: 10rpx;
					font-size: 28rpx;
     				.car-num {
     					position: absolute;
     					top: -10rpx;
     					right: -10rpx;
     				}
     			}
     		}
     	}
     	.right {
     		display: flex;
     		font-size: 28rpx;
     		align-items: right;			 
     		.btn {
     			line-height: 66rpx;
     			padding: 0 30rpx;
     			border-radius: 36rpx;
     			color: #ffffff;
				position: absolute;
				right: 10rpx;
     		}
     		.cart {
     			background-color: #9bd439;
     			margin-right: 10rpx;				
     		}
     		 
     	}
     } 
	 .centre {
	 	text-align: center;
	 	margin: 200rpx auto;
	 	font-size: 32rpx;
	 	image {
	 		width: 164rpx;
	 		height: 164rpx;
	 		border-radius: 50%;
	 		margin-bottom: 20rpx;
	 	}
	 	.tips {
	 		font-size: 24rpx;
	 		color: #999999;
	 		margin-top: 20rpx;
	 	}
	 	.btn {
	 		margin: 80rpx auto;
	 		width: 200rpx;
	 		border-radius: 32rpx;
	 		line-height: 64rpx;
	 		color: #ffffff;
	 		font-size: 26rpx;
	 		background: linear-gradient(270deg, rgba(249, 116, 90, 1) 0%, rgba(255, 158, 1, 1) 100%);
	 	}
	 }
	 .wrap {
	 	display: flex;
	 	flex-direction: column;
	 	height: calc(100vh - var(--window-top));
	 	width: 100%;
	 	padding-bottom:60rpx;
	  }
	 .swiper-box {
	 	flex: 1;
	 }
	 .swiper-item {
	 	height: 100%;
	 }
</style>
