<template>
	<view>
		<u-navbar back-text="返回" >
			<view class="slot-wrap">
				<u-search placeholder="输入商品名称"  v-model="keyword" @search="search"></u-search>
			 </view>
		</u-navbar>
		<view class="content">
			<u-sticky>
			 <view class="cate_b_item">
				 <u-tabs  :list="list" :bold="false" :font-size='28' bg-color="#f5f5f5" active-color="#66CCFF" inactive-color='#303133'  :duration="0.2" :is-scroll="false" :current="current_cate" @change="cate_change"></u-tabs>
			 </view>
			 </u-sticky>
			 <view class="pro_box">
				 <ul v-if="pro_pull_list != ''">
				    <li v-for="(item,index) in pro_pull_list" :key="index" >
				        <view class="prolist_left" @click="show_produt(item)">
							<u-image width="96%"  mode="widthFix" height="180rpx" :src="item.thum"></u-image>
						</view>
				        <view class="prolist_right">
				        <view class="prolist_r_title" @click="show_produt(item)">{{item.product_name | ellipsis}}</view>
				               <view class="prolist_r_tit">				  
				 					销量:{{item.sales_num}}   收藏:{{item.fav_num}}
				                </view>
				               <view class="prolist_r_end">
				                  ¥ {{item.retail_price}}  <span class="rec_cosprice">¥{{item.cost_price}} </span>
				                 <view class='buy_ico'>									 
									 <u-icon name="shopping-cart" @click="buy_cart(item)" color="#909399" size="36"></u-icon>
									 
								 </view>
				               </view>
				           </view>
				         <view class="clear"></view>
				    </li>					
				</ul>	
				 <view v-else="">
					 <u-empty :margin-top='400' text="列表记录为空" mode="list"></u-empty>
				  </view>
							 
		 			<view class="cbox">
						<u-divider  v-if="ajax_finished == true "  color="#909399">--没有更多记录了--</u-divider>
					</view>	
				 

			 </view>
					
			 
		</view>
		<u-toast ref="uToast" />
		<u-back-top :scroll-top="scrollTop"></u-back-top>
		<foot_bar  v-if="hackReset"></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	export default {
		components: {
			foot_bar
		 },
		 data(){
			 return {
				hackReset :true,
				keyword:'',				 
				current_cate: 0,
				list:[
					{
						name: '销量高'
					}, 					
					{
						name: '价格低'
					}, 
					{
						name: '人气高'
					}
				],
				pages:1,
				limit: 10,
				ajax_finished: false,
				s_data:'',
				query_String:'',//参数部分
				cate_menu:[],//滚动分类
				pro_pull_list:[], //商品列表
				scrollTop: 0,
			 }
		 },
		 filters: {
		 	ellipsis (value) {
		 		if (!value) return ''
		 		   if (value.length > 30) {
		 		     return value.slice(0,30) + '...'
		 		}
		 	    return value
		 	}
		 },
		 onLoad(options) {
			 this.query_String = options	
			    let s_data
			    if(this.query_String.id != undefined){ //小类
			    	  s_data = {'type':'nor','cid':this.query_String.id,limit:this.limit,pages:this.pages}		 		 
			    }else if(this.query_String.pid != undefined){ //大类
			    	s_data = {'type':'nor','aid':this.query_String.pid,limit:this.limit,pages:this.pages}
			    }else if(this.query_String.key != undefined){  //搜索
			    	s_data ={'type':'nor','key':this.query_String.key,limit:this.limit,pages:this.pages}
			    }else{
			       s_data = {'type':'nor',limit:this.limit,pages:this.pages} 			
			    }				 			
			  this._get_product_list(s_data) //商品列表		 
		 },
		 onPageScroll(e) {
		 	this.scrollTop = e.scrollTop;
		 },
		 onReachBottom () { //滚动条触底
		 		  let s_data
 		 		  if(this.query_String.id != undefined){ //小类		 		  
		 		  	  s_data = {'type':'nor','cid':this.query_String.id,limit:this.limit,pages:this.pages}		 		 
		  		  }else if(this.query_String.pid != undefined){ //大类
					   s_data = {'type':'nor','aid':this.query_String.pid,limit:this.limit,pages:this.pages}
				  }else if(this.query_String.key != undefined){  //搜索
		 			 s_data ={'type':'nor','key':this.query_String.key,limit:this.limit,pages:this.pages}
		  		  }else{
		 		     s_data = {'type':'nor',limit:this.limit,pages:this.pages} 			
		 		  }
		 		   this._get_product_list(s_data) //商品列表
		  },
		 methods:{
			 cate_change(index){
				 //console.log("分类菜单"+index)
				 this.current_cate = index
				 if(index == 0){ //销量高
				 	this.pro_pull_list =   this.pro_pull_list.sort(this._sortBy('sales_num',false))  //false 降序   true   升序
				 }else if(index == 1){ //价格低
				 	this.pro_pull_list = this.pro_pull_list.sort(this._sortBy('retail_price',true))  //false 降序   true   升序
				 }else if(index == 2){ //收藏高
				 	this.pro_pull_list =   this.pro_pull_list.sort(this._sortBy('fav_num',false))  //false 降序   true   升序
				}
				uni.pageScrollTo({
				 	scrollTop: 0,
				}); 
			 },
			 async _get_product_list(s_data){ //获取商品列表
			 	if(this.ajax_finished == false){
			 		 const res = await this.$AjaxRequest_product({
			 				url: 'product_select',
			 				method:'post',
			 				data:{'value_data':s_data}  //
			 		})
					this.pro_pull_list = this.pro_pull_list.concat(res.data);//追加数据 
			 			if(res.data.length < this.limit){
			 				this.ajax_finished = true
			 			}else{
			 				this.pages +=1
			 				this.ajax_finished = false
			 		}
			 	}					 				
		    },	 
			async _get_cate_menu () { //幻灯上滑动分类
				const res = await this.$AjaxRequest_product({
					url: 'category',
					method:'post',
					data:{value_data:{'is_index':1}}  //
				})
				this.cate_menu = res.data
			},
			buy_cart(item){   //加入购物车
				this.$store.commit('store_shop_cart_add',item)
				this.$store.commit('get_shop_num',this.$store.getters.Shop_nums)
				this.$refs.uToast.show({
					title: '加入成功！',
					type: 'success',
				})
				this.hackReset = false; //销毁
				this.$nextTick(() => { //执行完再渲染
					this.hackReset = true; 						 
				})
			},
			_sortBy(attr,rev){
					//第二个参数没有传递 默认升序排列
					if(rev ==  undefined){
						rev = 1;
					}else{  rev = (rev) ? 1 : -1;    }
						return function(a,b){
					 a = parseInt(a[attr]);
						b = parseInt(b[attr]);
			 			if(a < b){  return rev * -1;         }
						if(a > b){     return rev * 1;        }
						 return 0;
					}
			},						
			search(value) {	 
				if(value != ''){
					uni.navigateTo({
					   url: '/pages/product/product?key='+value
					})
				}else{
					this.$u.toast('请输入关键词后提交')
				} 				
			},
			show_produt(item){ //商品详情
				uni.navigateTo({
				   url: '/pages/product/product_show?id='+item.id+'&shop_id='+item.shop_id
				})
			},
									
						
						
			 
		 },
	}
</script>

<style scoped>
  .slot-wrap {display: flex;align-items: center;flex: 1;padding: 0 30rpx;}
  .cate_b_item{width: 100%;height: auto;}
  .pro_box{width: 98%;height: auto;margin:0 auto;}
  .cbox{height: 60rpx;line-height: 60rpx;margin-top:20rpx;}
  
   	.pro_box  li{width: 100%;height:210rpx;border-bottom: 2rpx #f5f5f5 solid;margin-top:6rpx;background: white;padding-top: 10rpx;}
   .clear{clear: both;}
   .pro_box  li  .prolist_left{ width: 25%;height: 210rpx; float: left;padding-left:1%;padding-right:1%;text-align: center;}
   .pro_box li  .prolist_left  img{width: 100%;height: auto;margin-top:10rpx;}
   .pro_box li  .prolist_right{ width: 69%;height: 210rpx;float: right;padding-right: 2%;padding-left: 1%; }
   .pro_box  li  .prolist_right  .prolist_r_title{width: 100%;height: 80rpx;line-height: 40rpx;font-size: 28rpx;color:#333;text-overflow: -o-ellipsis-lastline;
     overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
   	.pro_box  li  .prolist_right   .prolist_r_tit{width: 100%;height: 60rpx;line-height: 60rpx;color:#999;font-size:24rpx;}
   .pro_box  li  .prolist_right    .prolist_r_end{font-size:40rpx;width: 100%;height: 70rpx;color:#ff0000;font-weight: 700;}
   .rec_cosprice{font-size: 24rpx;color:#9e9e9e;text-decoration:line-through;font-weight: normal;margin-left: 20rpx;}
     
   .buy_ico{width:46rpx;height: 46rpx;text-align: center;float: right;}
</style>
