<template>
	  <view>		  
		  <u-navbar back-text="返回" title="商品详情"></u-navbar>
		  
		  <view class="content">
			 <view class="head_slide">
				 <view class="share_box" @click="share_wx(product_info)"><u-icon name="share" size="30" color="#FFFFFF"></u-icon></view>
			 	<u-swiper :list="product_info.slide" name="item" height="560" bg-color="#ffffff" img-mode="aspectFit" mode="dot" ></u-swiper>
			    <view class="wx_kf"><img :src="product_info.wx_qrcode"></view>			  
			  </view>
			 
			   <view class="pro_price">
			   		<view class="pro_real_price" v-if="product_info.retail_price != undefined ">￥ {{product_info.retail_price}}<span class="col_price">￥ {{product_info.cost_price}}</span></view>
			   		<view class="pro_fav_box">
			   		<view class="fav_ico">							
			   		         <u-icon name="heart"  v-if="product_info.is_fava_sta == '0'" @click="cfav(product_info.is_fava_sta,product_info.id,product_info.fav_num)" color="#ff0000"></u-icon>
							 <u-icon name="heart-fill" v-else="product_info.is_fava_sta == '1'" @click="cfav(product_info.is_fava_sta,product_info.id,product_info.fav_num)" color="#ff0000"></u-icon>
			   		        </view>
			   		        <view class="fav_num">关注</view>
			   		</view>
			   		<view class="clear"></view>
			   	 </view>
			   	 <!---->
			   	   <view class="pro_title" v-if="product_info.product_name != undefined ">{{product_info.product_name}}</view>
			   	 <!---->
			   	  <view class="pro_description" v-if="product_info.notice != undefined ">{{product_info.notice}}</view>
			   	<!---->
				
			<view class="box2">
				<view class="box2_a">
					<view class="box2_a_left">
						  <view class="logo_pic" v-if="shop_info.shop_pic != undefined "><img  :src="shop_info.shop_pic"></view>
					</view>
					<view class="box2_a_right" v-if="shop_info.shop_name != undefined ">
								   <ul>
									   <li><i class="iconfont icon-store"/> {{shop_info.shop_name}}</li>
									   <li><i class="iconfont icon-map"/> {{shop_info.address}}</li>
									   <li><i class="iconfont icon-mobile-phone"/> {{shop_info.contact_tel}}</li>
								   </ul>
					</view>
					<view class="clear"></view>
				</view>
				<view class="box2_b">
								 <ul>
									 <li>商品总数<br>{{shop_info.product_total}}</li>
									 <li>订单总数<br>{{shop_info.order_total}}</li>
									 <li>收藏本店<br>{{shop_info.fav_num}}</li>
								  </ul>
								<view class="clear"></view>
						   </view>
						   <view class="box2_c">
							    <view class="box2_c_left" v-if="product_info.is_fava_shop_sta == 0"  @click="shop_fav(0,shop_info.id,shop_info.fav_num)" ><u-icon name="grid"></u-icon>收藏本店</view>
								<view class="box2_c_left2" v-else-if="product_info.is_fava_shop_sta == 1"  @click="shop_fav(1,shop_info.id,shop_info.fav_num)" ><u-icon name="grid"></u-icon>收藏本店</view>
								<view class="box2_c_right" @click="shop_url(shop_info.id)"><u-icon name="shopping-cart"></u-icon>逛逛本店</view>
							   <view class="clear"></view>
						   </view>
					</view>
					<!---->
					<view v-if="shop_coupons != '' ">
									<u-section title="店铺卡券" :right="false"></u-section>
									<view  class="coupon_box">
										<ul>
										 <li v-for="(item,index) in shop_coupons"  :key="index" >
										  <view class="coupon_item"   v-if="item.is_ok == 0  && item.is_rec == 0 "   @click="show_actions()">
												<u-icon name="coupon"></u-icon> {{item.title}}  <span class="r_crl"></span><view class="clear"></view>
										  </view>
											<view class="coupon_item"  v-else-if="item.is_ok == 0  && item.is_rec == 1 "  title="已抢完了" style="background:#ddd;">
												 <van-icon name="coupon-o" /> {{item.title}}  <span class="r_crl"></span><view class="clear"></view>
										  </view>
											 <view  class="coupon_item"  v-else-if="item.is_ok == 1 "  title="已领取了" style="background:#ddd;" >
												 <van-icon name="coupon-o" /> {{item.title}}  <span class="r_crl"></span><view class="clear"></view>
										  </view>
									  </li>
										 </ul>
					</view>
					<u-popup v-model="show" mode="bottom">
						   <view class="coupon_list_box">
										<ul>
											<li  v-for="(item,index) in shop_coupons"  :key="index">
											   <view class="cou_left">
												  <view class="c_price"><span class="c_price_tag">￥</span>{{item.deduct_price}}</view>
												  <view class="c_tag">满{{item.quota_price}}可用</view>
											   </view>
											   <view class="cou_mid">
												   <view class="coup_mid_time">开始：{{item.start_time}}</view>
												   <view class="coup_mid_time">结束： {{item.end_time}}</view>
											   </view>
											   <view class="cou_line"></view>
											   <view class="cou_right">
												  <view class="lq_btn" v-if="item.is_ok == 0  && item.is_rec == 0 " @click="coupon_regs(item.id,item.shop_id)" >领取</view>
												   <view class="lq_btn" v-else-if="item.is_ok == 0  && item.is_rec == 1 "  style="background: #dddddd;">已抢完</view>
												   <view class="lq_btn"  v-else-if="item.is_ok == 1"  style="background: #dddddd;">已领取</view>
											   </view>
											   <view class="clear"></view>
											</li>
										</ul>
									 </view>
									</u-popup>	
										
									</view>
					<!---->
					<view class="box3">
						<view class="box3_title">
 							<u-section title="推荐商品"  sub-title="" :arrow="false" :right="false"></u-section>
						 </view>
								   <view class="box3_con">
									   <ul>
										   <li v-for="(item,index) in shop_product" :key="index" @click="show_produt(item)">
											   <view class="box3_con_pic"><img :src="item.thum"></view>
											   <view class="box3_con_title">{{item.product_name}}</view>
											   <view class="box3_con_price">￥ {{item.retail_price}}  </view>
										   </li>
					
										   <view class="clear"></view>
									   </ul>
								   </view>
							   </view>
							   <!---->
				<view class="box4">
					<view class="box4_title">
						<u-section title="商品详情" sub-title="" :arrow="false" :right="false"></u-section>
					 </view>
					<view class="content_box" >
						<!-- <view  v-for="(item2,index2) in product_info.content_pic" :key="index2">
 							 <u-image :src="item2" mode="widthFix"></u-image>
						</view> -->
						<u-parse :html="product_info.content"></u-parse>
						
					</view>
				</view>
				
		  </view>
		   <!---->
		    <view class="navigation">
		    	<view class="left">		    		
		    		<view class="item" @click="home">
		    			<u-icon name="home" :size="40" :color="$u.color['contentColor']"></u-icon>
		    			<view class="text u-line-1">首页</view>
		    		</view>
					<view class="item">
 						<u-icon name="kefu-ermai" :size="40" :color="$u.color['contentColor']" ></u-icon>
						<view class="text u-line-1">客服</view>
					</view>
		    		<view class="item car" @click="shop_cart()">
		    			<u-badge class="car-num" :count="count" type="error" :offset="[-3, -6]"></u-badge>
		    			<u-icon name="shopping-cart" :size="40" :color="$u.color['contentColor']"></u-icon>
		    			<view class="text u-line-1">购物车</view>
		    		</view>
		    	</view>
		    	<view class="right">
		    		<view class="cart btn u-line-1" @click="buy_cart(product_info)">加入购物车</view>
		    		<view class="buy btn u-line-1" @click="buy_now(product_info)">立即购买</view>
		    	</view>
		   				</view>	
		   <!---->
		   
		    <u-toast ref="uToast" />
			<u-modal v-model="show_model" :show-title="false" :content="content" @confirm="confirm"></u-modal>
			<u-mask :show="show_share" @click="share_close()" :duration="100" >
					<view class="warp">
						<view class="close_box"><u-icon name="close" color="#ffffff" size="30"></u-icon></view>
						<view class="rect" @tap.stop><img src="@/static/share01.png"></view>
					</view>
			</u-mask>
	 </view>
</template>

<script>
	//#ifdef H5
	 let jweixin = require('jweixin-module');
	//#endif
	//#ifdef MP-WEIXIN
	import {shareMixins} from '@/util/mp_share'
	//#endif
	export default {
		//#ifdef MP-WEIXIN
		mixins: [shareMixins],
		//#endif		
		data(){
			return {
				product_info:'',
				query_String : '',
				count:0 || this.$store.getters.Shop_nums,
				shop_info:'',
				shop_product:'',
				wx_user_info:'',
				product_content:[],
				active_shop_style:'active_1',
				wxapp_openid : '',
				shop_coupons :'',
				show: false,
				show_model:false,
				content:'',			 
				shareData:{},
				show_share:false,
  			}
		},
		created() {		 
		  let _that = this
		  //#ifdef H5		
		  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
		  	 let url_s = window.location.href.split("#")[0];  //当前url去掉#及后面所有
		  	 const res_wx = _that.$AjaxRequest({
		  	 	url: 'get_jssdk',
		  	 	method:'post',
		  	    data:{value_data:{'url':url_s}}
		  	 }).then((res_wx) => {
		  	 	 jweixin.config({
		  	 	    debug: false, // 开启调试模式,
		  	 	    appId: res_wx.data.appId, // 必填，企业号的唯一标识，此处填写企业号corpid
		  	 	     timestamp: res_wx.data.timestamp, // 必填，生成签名的时间戳
		  	 	    nonceStr: res_wx.data.nonceStr, // 必填，生成签名的随机串
		  	 	     signature: res_wx.data.signature,// 必填，签名，见附录1
		  	 	     jsApiList: [   // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
		  	 	        'chooseWXPay',
		  	 	        'getLocation',
		  	 	        'getNetworkType',
		  	 	        'openLocation',
		  	 	        'showOptionMenu',
						'updateAppMessageShareData',
						'updateTimelineShareData',
		  	 	        'closeWindow',
		  	 	        'scanQRCode',
		  	 	       ]
		  	 	  });		  	 	 				
		  	  }) 
			_that.jweixin = jweixin
		  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
		  	//alert('支付宝端');	
		  	 
		  }			
		  //#endif   
		},
		onLoad(options) {
			this.query_String = options	
		 
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }
				 this._get_product(this.$store.getters.get_wx_user.openid) //获取当前单品
				 this._get_shop_coupon(this.query_String.shop_id,this.$store.getters.get_wx_user.openid) //获取卡券	
				 ////////////////
				 
				 /////////////////
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				this._get_product(this.$store.getters.get_ali_user.user_id) //获取当前单品
				this._get_shop_coupon(this.query_String.shop_id,this.$store.getters.get_ali_user.user_id) //获取卡券		 
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}		 
			this._get_product(this.$store.getters.get_wxapp_openid) //获取当前单品
			this._get_shop_coupon(this.query_String.shop_id,this.$store.getters.get_wxapp_openid) //获取卡券
			//#endif		
		
		   this._get_product_select() //获取推荐商品 
		},
		methods:{
			async _get_shop_coupon (shop_id,openid) { //获取本店卡券		
 			    //#ifdef MP-WEIXIN
			      let value = {'shop_id':shop_id,'wxapp_openid':openid}
			      //#endif
			      //#ifdef H5
				  let value
				  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端
				  	   value = {'shop_id':shop_id,'wx_openid':openid}
				  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				  	  value = {'shop_id':shop_id,'ali_openid':openid}			 
				  }			     
			      //#endif
				const res = await this.$AjaxRequest({
					url: 'get_coupon',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {
 					 if(res.sta == 'success'){
						 this.shop_coupons =  res.data 						 
					 }
  					 
 				}) 
			},	
			buy_cart(item){ //加入购物车
			    this.$store.commit('store_shop_cart_add',item)
			   	this.$store.commit('get_shop_num',this.$store.getters.Shop_nums)
			   	this.$refs.uToast.show({
			   		title: '加入成功！',
			   		type: 'success',
			   	})
				this.count = this.$store.getters.Shop_nums
			},
			buy_now(item){//立即购买
				let  buy_str =  item.shop_id+'|'+item.id+'|1|0| '+item.retail_price
				uni.navigateTo({
				    url: '/pages/shop_cart/buy?type=nor&buy_str='+buy_str
				})
			},
			home(){//跳转首页
				uni.switchTab({
				    url: '/pages/index/index'
				})
			},
			change(e) { //焦点图片切换
				this.current = e.detail.current;
			},
			//#ifdef H5		 
			  async  _ali_get_code(){ //支付宝授权 获取code
			      const res =  await this.$AjaxRequest_ali({
			      	url: '/get_appid',
			      	method:'POST',
			      	data:{value_data:{'a':'0'}}
			      }).then((res) => { 			
			  			let urls= window.location.href
			  			let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
			  			window.location.href = auth_get_code_url						
			       })				  
			   },
				async _wx_get_code(){ //微信获取code
				   const res_wx = await this.$AjaxRequest({
					url: '/get_config',
					method:'POST',
					data:{value_data:{}}
				   })	
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					 window.location.href = auth_get_code_url
				},				
			//#endif
			async _get_product (openid) { //获取单品信息
			   //#ifdef MP-WEIXIN
			     let value = {'type':'nor','shop_id':this.query_String.shop_id,'id':this.query_String.id,'wxapp_openid':openid}
			     //#endif
			     //#ifdef H5
				    let value 
					 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端
						value = {'type':'nor','shop_id':this.query_String.shop_id,'id':this.query_String.id,'wx_openid':openid}
					 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						 value = {'type':'nor','shop_id':this.query_String.shop_id,'id':this.query_String.id,'ali_openid':openid}
					 }			     
			     //#endif
				let res2 = await this.$AjaxRequest_product({
					url: 'product_find',
					method:'post',
					data:{value_data:value}  //
				}) 	
			     this.product_info = res2.data				
			     this.active_style = res2.data.is_fava_sta
			     this.product_content = res2.data.content_pic
			     this.shop_info =  res2.data.shop_info	
 			},
			 		
			async _get_product_select(){ //获取推荐商品
				 const res = await this.$AjaxRequest_product({
					url: 'product_select',
					method:'post',
					data:{value_data:{'type':'nor','shop_id':this.query_String.shop_id,limit:6}}  //
				})
				this.shop_product = res.data
			},
			onClick (e) {
			   uni.showToast({
			     title: `点击${e.content.text}`,
			     icon: 'none'
			    })
			},
			buttonClick (e) {			  
			  this.options[2].info++
		    },
			//展开卡券面板
			show_actions(){
			      this.show  = true
 			},
			//领取卡券
			coupon_regs(coupon_id,shop_id){				 
				//#ifdef MP-WEIXIN				  
				  let value = {'shop_id':shop_id,'coupon_id':coupon_id,'wxapp_openid':this.$store.getters.get_wxapp_openid}
				//#endif
				//#ifdef H5	
				   let value
					if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
					  value = {'shop_id':shop_id,'coupon_id':coupon_id,'wx_openid':this.$store.getters.get_wx_user.openid}			 
					}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
					  value = {'shop_id':shop_id,'coupon_id':coupon_id,'ali_openid':this.$store.getters.get_wx_user.openid}				 			 
					}	
				   
				//#endif
				
				const res =  this.$AjaxRequest({
					url: 'reg_coupon',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {	
					  
					if(res.sta == 'success'){						 
				       this.content = "卡券领取成功"
				       this.show_model = true;                          
					}else{
				       this.content = "卡券领取失败"
				       this.show_model = true;                 
					}
				})				 	
			},
			confirm(){
				this.content = ""
				this.show_model = false
				this.show = false
				let page = getCurrentPages().pop(); //跳转页面成功之后
 				uni.navigateTo({
				    url: page.$page.fullPath
				})				 
			},
			//跳转商品详情
			show_produt(item){
				uni.navigateTo({
				    url: '/pages/category/product_show?id='+item.id+'&shop_id='+item.shop_id
				})
			},
			//跳转购物车
			shop_cart(){
				uni.switchTab({
				    url: '/pages/shop_cart/shop_cart'
				})
			},
			shop_fav(active_shop_style,shop_id){ //店铺收藏
				if(active_shop_style == 'no'){
                    this.active_shop_style = 'active_2';
                }else{
                    this.active_shop_style = 'active_1';
                }
				//#ifdef MP-WEIXIN
				  let value = {'shop_id':shop_id,'wxapp_openid':this.$store.getters.get_wxapp_openid}
				//#endif
				//#ifdef H5	
					 let value
					 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端
						  value = {'shop_id':shop_id,'wx_openid':this.$store.getters.get_wx_user.openid}	    
						}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						  value = {'shop_id':shop_id,'ali_openid':this.$store.getters.get_ali_user.user_id}	    			 
					 }					
				//#endif
				const res =  this.$AjaxRequest({
					url: 'shop_fav',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {			
					console.log(res)
					if(res.sta == 'success'){	
						if(res.act == '1'){
                            this.content = "商铺添加收藏成功"
                            this.show_model = true;                    
                         }else{
                            this.content = "商铺取消收藏成功"
                            this.show_model = true;   
                          }
					} 
				})				
				
			},
			cfav(is_fava_sta,product_id){ //商品关注			
				//#ifdef MP-WEIXIN
				  let value = {'product_id':product_id,'wxapp_openid':this.$store.getters.get_wxapp_openid}
				//#endif
				//#ifdef H5	
				   let value 
					if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端
						 value = {'product_id':product_id,'wx_openid':this.$store.getters.get_wx_user.openid}	    
					}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						 value = {'product_id':product_id,'ali_openid':this.$store.getters.get_ali_user.user_id}	    			 
					}				   
				//#endif
			    
				const res =  this.$AjaxRequest_product({
					url: 'product_fav',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {	
					  console.log(res)
					 if(res.sta == 'success'){	
						if(res.act == '1'){
				            this.content = "商品关注成功"
				            this.show_model = true;                    
				         }else{
				            this.content = "商品取消关注成功"
				            this.show_model = true;   
				          }
					}
				})				
			},
			
			_html_decode(values){
			    let  str = values
			    str = str.replace(/&amp;/g, "&");
			    str = str.replace(/&lt;/g, "<");
			    str = str.replace(/&gt;/g, ">");
			    str = str.replace(/&nbsp;/g, " ");
			    str = str.replace(/&#39;/g, "\'");
			    str = str.replace(/&quot;/g, "\"");
			    str = str.replace(/<br\/>/g, "\n");
			    return  str
			},
			show_produt(item){ //商品详情
				uni.navigateTo({
				   url: '/pages/product/product_show?id='+item.id+'&shop_id='+item.shop_id
				})
			},
			
			shop_url(shop_id){ //商家首页跳转
				uni.navigateTo({
				   url: '/pages/shop/shop?shop_id='+shop_id
				})
				
			},
			share_wx(item){	
				this.show_share = true
				     //#ifdef H5	
					 jweixin.ready(function () {   //需在用户可能点击分享按钮前就先调用
                        jweixin.updateAppMessageShareData({
                            title: item.product_name, // 分享标题
                            desc:  item.notice, // 分享描述
                            link: window.location.href, // 分享链接
                            imgUrl: item.thum, // 分享图标
                            success: function () {
                            // 设置成功
                             //Toast.success('分享内容已生成,请通过右上角菜单分享');
                            },
							fail:function(res){
								console.log(res)
							}
                        }),
                        jweixin.updateTimelineShareData({
                            title: item.product_name, // 分享标题
                            desc:  item.notice, // 分享描述
                            link: window.location.href, // 分享链接
                            imgUrl: item.thum, // 分享图标
                            success: function () {
                             //Toast.success('分享内容已生成,请通过右上角菜单分享');
                            },
							fail:function(res){
								console.log(res)
							}
                        })
                    }) 
				//#endif
				//#ifdef MP-WEIXIN
					let _that = this
					_that.shareData.title = item.product_name
					_that.shareData.path = '/pages/index/index'
					_that.shareData.imageUrl = item.thum
					_that.shareData.desc = item.notice
					_that.shareData.content = item.notice 				 
				//#endif				 
            },		
			share_close(){
				this.show_share = false
			},
		},		
	}	
</script>

<style  lang="scss" scoped>
	
	.wx_kf{width: 120rpx;height: 120rpx;position: absolute;right:10rpx;top:550rpx;z-index: 9999;}
	
	.close_box{width: 50rpx;height: 50rpx;position:absolute;left:30rpx;top:180rpx;border:1px #F5F5F5 solid;text-align: center;border-radius: 180rpx;line-height: 50rpx;;}
	.rect img{width: 100%;height:90%;;}
	.rect{width: 700rpx;height: 90vh;margin-top: 10vh;padding-right:50rpx;}
	
	/* #ifdef MP-WEIXIN */
	.share_box{width: 60rpx;height: 60rpx;position:absolute;right:20rpx;top:180rpx;line-height: 60rpx;border-radius: 180rpx;color:#FFFFFF; text-align: center;; background-color:rgba(0,0,0,0.35);z-index: 999;}
	/* #endif */
	/* #ifdef H5 */
	.share_box{width: 60rpx;height: 60rpx;position:absolute;right:20rpx;top:120rpx;line-height: 60rpx;border-radius: 180rpx;color:#FFFFFF; text-align: center;; background-color:rgba(0,0,0,0.35);z-index: 999;}
	/* #endif */
	.slot-wrap {display: flex;align-items: right;text-align: right;flex: 1;}	
	.axleft{margin-left:90%;float: right;width: 50rpx;}
	.head_slide{width: 100%;height: 600rpx;background: #FFFFFF;}
	.head_slide  img{width: 100%;height:100%;}
	.pro_price{width: 100%;height: 100rpx;background: white;}
	.pro_real_price{ width:55%;font-size: 50rpx;color:#ff0000;float: left;padding-left: 5%;font-weight:600;line-height: 100rpx;}
	.col_price{ font-weight: normal;font-size: 28rpx;color:#ccc;text-decoration: line-through;}
	.pro_fav_box{width: 20%;height: 100rpx;float: right;text-align: right;padding-right:3%;}
	.fav_ico{width: 100%;text-align: right;height: 60rpx;}
	.fav_ico i{top:10rpx;}
	.fav_num{width: 100%;height: 40rpx;font-size: 24rpx;}  
	.pro_description{width:98%;color:#999;height: 70rpx;font-size:26rpx;line-height:48rpx;overflow:hidden;padding-right: 3%;padding-left: 3%;background: white;text-overflow: -o-ellipsis-lastline;
		   overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;border-bottom-left-radius: 20rpx;border-bottom-right-radius: 20rpx;padding-bottom:40rpx;padding-top:10rpx;}
		 
	.pro_title{width:98%;margin:0 auto;pading-left:3%;padding-right: 3%;  height: 110rpx;line-height:52rpx;background: white;font-size: 32rpx;font-weight: bold;text-align: left;text-overflow: -o-ellipsis-lastline;
		   overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
	.box2{width:100%;height: auto;background: white;border-radius: 30rpx;margin:0 auto;margin-top:20rpx;}
	.box2_a{ width: 100%;height: 160rpx;}
	 .box2_a_left{ width:290rpx;height: 160rpx;float: left;}
	.logo_pic{width: 95%;height: 98%;margin:0 auto;overflow: hidden;border-radius: 20rpx;text-align: center;}
	 .logo_pic img{width: 96%;height: 96%;border-radius: 20rpx;}
	 .box2_a_right{width: 450rpx;height: 160rpx;float: right;}
	 .box2_a_right li{width: 100%;height: 50rpx;overflow: hidden;text-overflow:ellipsis;white-space: nowrap;font-size:30rpx;color:#666;}
	    
	    .box2_b{ width:100%;height: 80rpx;color:#666;font-weight: 600;font-size: 20rpx;margin-top:20rpx;}
	    .box2_b  li{width: 30%;height: 80rpx;float: left;margin-left:1.5%;margin-right: 1.5%;text-align: center;line-height:40rpx;font-size: 28rpx; }
	    .box2_b  li:nth-child(2){border-left:2rpx #f5f5f5 solid;border-right:2rpx #f5f5f5 solid;}
	    .box2_c{width: 100%;height: 100rpx;margin-top:40rpx;color:#333}
	    .box2_c  i{top:4rpx;margin-right:4rpx;}    
	    
		.box2_c_left2{width: 30%;height: 70rpx;float: left; text-align: center;line-height:70rpx;margin-left:15%;border:2rpx #ffa31a solid;color:#FFFFFF;background-color: #ffa31a; border-radius: 360rpx;}
	    .box2_c_left{width: 30%;height: 70rpx;float: left; text-align: center;line-height:70rpx;margin-left:15%;border:2rpx #ffa31a solid;color:#ffa31a;border-radius: 360rpx;}
	    .box2_c_right{ width: 30%;height: 70rpx;float: right; text-align: center;line-height:70rpx;margin-right:15%;border:2rpx #fd5332 solid;color:#fd5332;border-radius: 360rpx}
	  
	   .pop_us{width: 100%;min-height: 60%;background: none;background-color:transparent}
	   .pop_us img{width: 100%;height: 60%;}
 
	    .coupon_box{width: 100%;height: 80rpx;background:white;margin-top:20rpx;border-radius: 10rpx;}
	    .coupon_box ul{position: absolute;left: 20rpx;width: calc(98% - 40rpx);height: 80rpx; vertical-align:top;white-space: nowrap;
	         overflow-x:scroll; overflow-y:hidden;-webkit-overflow-scrolling : touch;list-style-type: none;}
	    .coupon_item{height:60rpx;color: white; background: #FF0033;background-image: linear-gradient(to bottom,#ff416c,#ff4b2b,#ff416c); padding-left: 10rpx;padding-left: 10rpx;border-radius:10rpx;}
	    .coupon_box li{font-size:26rpx;margin-right: 20rpx;margin-left:20rpx;margin-top:10rpx;display: inline-block;line-height:60rpx;text-align: center;}
	   .r_crl{width: 8px;height: 16rpx;float: right;margin-left: 10rpx;margin-top:4rpx;border-radius: 360rpx;background:white;margin-right:4rpx;}
	   
	   .coupon_list_box{width: 96%;height: auto;background:white;margin: 0 auto;padding: 20rpx;}
	   .coupon_list_box li{width:750rpx;height:160rpx;border:2rpx #FFCC99 solid;box-shadow: 2rpx 2rpx 2rpx #FF9966;border-radius:6rpx;margin-top:20rpx;}
	   	 .cou_left{width:47%;height:160rpx;float:left;}
	   	 .c_price{width:100%;height:100rpx;line-height:120rpx;text-align:center;font-size:36rpx;color:#FF6666;}
	   	 .c_price_tag{font-size:20rpx;}
	   	 .c_tag{width:100%;height:40rpx;text-align:center;font-size:20rpx;color:#666;}
	   
	   	 .cou_mid{width:30%;height:100rpx;float:left;padding-top: 40rpx;}
	   	 .coup_mid_title{width:90%;height:auto;font-size:60rpx;line-height:120rpx;padding-top: 10%;}
	   	 .coup_mid_time{width:100%;font-size:24rpx;color:#666;margin-left:20rpx;line-height: 50rpx;}
	   	 .cou_line:before{content:"";display:block;width:100%;height:20rpx;background:white;position:relative;top:-10rpx;border-bottom-left-radius:360rpx;border-bottom-right-radius:306rpx;}
	   	 .cou_line{width:3%;height:168rpx;float:left;overflow:hidden;background-image:linear-gradient(to right,#FF9966,#FF6666);;position:relative;top:-2rpx;bottom:-2rpx;}
	   	 .cou_line:after{content:"";display:block;width:100%;height:20rpx;position:relative;top:82%;		background:white;
	   		 border-top-left-radius:360rpx;border-top-right-radius:360rpx;
	          }
	   
	   	 .cou_right{width:20%;height:160rpx;float:right;}
	    	 .lq_btn{width:80%;height:40rpx;background:#FF0033;margin:0 auto;font-size:24rpx;text-align:center;margin-top:40%;border-radius:360rpx;line-height:40rpx;color:#fff;}
	   
	      .yes{color:#ff0000;}
	      .no{color:#999999;}
	   
	    .box4{width:98%;height: auto;background: white;border-radius:30rpx;margin: 0 auto;margin-top:20rpx;margin-bottom:80rpx;}
	      .box4  img{width: 100%;height: auto;}
	      .box4_title{width: 100%;height:auto;line-height: auto;text-align: left;border-bottom:4rpx #f5f5f5 solid;}
	      .box4_title i{top:4rpx;color:#ff0000;margin-right: 10rpx;}
		  .content_box img{width: 98%;height:450rpx;margin: 0 auto;}
	      .content_box{width: 100%;height: auto;min-height: 600rpx;; margin-top:20rpx;padding-bottom: 20rpx;}
	   
	      .box3{width:98%;height: auto;background: white;border-radius: 30rpx;margin: 0 auto;margin-top:20rpx;}
	      .box3_title{width: 100%;height: auto;line-height: auto;border-bottom:4rpx #f5f5f5 solid;}
	       .box3_title i{top:4rpx;color:#ff0000;}
	       .box3_con{width: 100%;height: auto;}
	        .box3_con  li{width: 31.333%;height: 380rpx;float: left;margin-left:1%;margin-right: 1%;}
	        .box3_con_pic{width: 100%;height: 240rpx;text-align: center;}
	         .box3_con_pic  img{width: 90%;height: 90%;margin-top:5%;}
	        .box3_con_title{width: 100%;height: 75rpx;font-size:28rpx;color:#666;overflow: hidden;text-overflow: -o-ellipsis-lastline;
	     overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
	        .box3_con_price{width: 100%;height: 60rpx; color:#ff0000;font-weight:600;font-size: 28rpx;}


     .navigation {
     	display: flex;
     	margin-top: 100rpx;
     	border: solid 2rpx #f2f2f2;
     	background-color: #ffffff;
     	padding: 12rpx 0;
		position: fixed;bottom: 0;	
			width: 100%;
     	.left {
     		display: flex;
     		font-size: 20rpx;
     		.item {
     			margin: 0 36rpx;
     			&.car {
     				text-align: center;
     				position: relative;					
     				.car-num {
     					position: absolute;
     					top: -10rpx;
     					right: -10rpx;
     				}
     			}
     		}
     	}
     	.right {
     		display: flex;
     		font-size: 28rpx;
     		align-items: center;
     		.btn {
     			line-height: 66rpx;
     			padding: 0 30rpx;
     			border-radius: 36rpx;
     			color: #ffffff;
     		}
     		.cart {
     			background-color: #ed3f14;
     			margin-right: 20rpx;
     		}
     		.buy {
     			background-color: #ff7900;		
     		}
     	}
     }
	 
	 .coupon_list_box{width: 100%;height: auto;background:white;}
	      .coupon_list_box li{width:100%;height:80px;border:1px #FFCC99 solid;box-shadow: 1px 1px 1px #FF9966;border-radius:3px;margin-top:10px;}
	 	 .cou_left{width:27%;height:80px;float:left;}
	 	 .c_price{width:100%;height:50px;line-height:70px;text-align:center;font-size:28px;color:#FF6666;}
	 	 .c_price_tag{font-size:12px;}
	 	 .c_tag{width:100%;height:20px;text-align:center;font-size:11px;color:#666;}
	 
	 	 .cou_mid{width:50%;height:85px;float:left;}
	 	 .coup_mid_title{width:100%;height:50px;font-size:14px;line-height:60px;}
	 	 .coup_mid_time{width:100%;font-size:12px;color:#666;}
	 	 .cou_line:before{content:"";display:block;width:100%;height:10px;background:white;position:relative;top:-5px;border-bottom-left-radius:180px;border-bottom-right-radius:180px;}
	 	 .cou_line{width:3%;height:84px;float:left;overflow:hidden;background-image:linear-gradient(to right,#FF9966,#FF6666);;position:relative;top:-1px;bottom:-1px;}
	 	 .cou_line:after{content:"";display:block;width:100%;height:10px;position:relative;top:82%;		background:white;
	 		 border-top-left-radius:180px;border-top-right-radius:180px;
	        }
	 
	 	 .cou_right{width:20%;height:80px;float:right;}
	  	 .lq_btn{width:80%;height:20px;background:#FF0033;margin:0 auto;font-size:12px;text-align:center;margin-top:40%;border-radius:180px;line-height:20px;color:#fff;}
		 
</style>
