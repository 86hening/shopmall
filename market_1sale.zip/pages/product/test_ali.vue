<template>
	<view>
		<view class="opx">
		<form @submit="onNick" class="pass_form">  
		　　<input name="text" class="uni-input" type="text"  @input="c_value1"  :value="value1" placeholder="请输入自己喜欢的昵称"/>  
		    <input name="text" class="uni-input" type="text" @input="c_value2"  :value="value2" placeholder="请输入自己喜欢的昵称"/> 
		   <button form-type="submit"  class="person_submit">确定</button>  
		</form>
		 </view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				value1:'',
				value2:'',
			}
		},
		methods: {
		    onNick(e){	
				uni.request({
				   header: {
				    	'Content-Type': 'application/x-www-form-urlencoded'  
				    }, 
				   url: 'https://www.1sale.cn/aa.php',  
				    method: 'POST',
				    data:{'valu1':this.value1,'value2':this.value2},
				    dataType:'json',
				    success: (res) => {
				    	 
				    		console.log(res)
				        } 
				    });
				 
				   
			},
			//获取input的数据
			c_value1(e) {			 
			    this.value1 = e.detail.value
			},
			c_value2(e) {
			 
			this.value2 = e.detail.value
			},
		}
	}
</script>

<style  scoped>
  .opx{padding-top:300rpx;}
</style>
