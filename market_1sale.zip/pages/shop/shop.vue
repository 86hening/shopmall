<template>
	<view>
		<u-navbar back-text="返回" :title="shop.shop_name" :background="background"></u-navbar>
		<view class="content">
			 <view :style="{backgroundImage: 'url('+(shop.banner)+')',backgroundSize:'cover',backgroundRepeat:'no-repeat',backgroundPosition:'center'}" class="bg_header" >
				   <view class="top_body">				  
					   
				   </view>
			 </view>
			 <u-sticky>
			 <view class="tab_item">				 
				  <u-tabs  :list="cate_list" :bold="false" :font-size='26' bg-color="#a0cfff" active-color="#ffffff" inactive-color='#ffffff'  :duration="0.2" :is-scroll="false" :current="current_cate" @change="cate_change"></u-tabs>
			 </view>
			 </u-sticky>
			<view class="pro_box">
							 <ul v-if="pro_pull_list != ''">
							    <li v-for="(item,index) in pro_pull_list" :key="index" >									 
 							        <view class="prolist_left" @click="show_produt(item)">
										<u-image width="96%"  mode="widthFix" height="180rpx" :src="item.thum"></u-image>
									</view>
							        <view class="prolist_right">
							        <view class="prolist_r_title" @click="show_produt(item)">{{item.product_name}}</view>
							               <view class="prolist_r_tit">				  
							 					销量:{{item.sales_num}}   收藏:{{item.fav_num}}
							                </view>
							               <view class="prolist_r_end">
							                  ¥ {{item.retail_price}}  <span class="rec_cosprice">¥{{item.cost_price}} </span>
							                 <view class='buy_ico'>									 
												 <u-icon name="shopping-cart"  color="#909399" size="36"></u-icon>
												 
											 </view>
							               </view>
							           </view>
							         <view class="clear"></view>
							    </li>					
							</ul>	
							 <view v-else="">
								 <u-empty :margin-top='400' text="列表记录为空" mode="list"></u-empty>
							  </view>
										 
					 			<view class="cbox">
									<u-divider  v-if="ajax_finished == true "  color="#909399">--没有更多记录了--</u-divider>
								</view>							 
			
			</view>
		</view>	
		<u-back-top :scroll-top="scrollTop"></u-back-top>
		<foot_bar></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	export default {
		components: {
			foot_bar
		 },
		data() {
			return {
				background: {
					 backgroundColor: '#FFFFFF',
				},
				shop:'',				 
				cate_list:[
					{name:'综合'},
					{name:'销量'},
					{name:'价格'},
					{name:'收藏'},
				],		
				current_cate:0,
				pro_pull_list: [],			   			
				scrollTop: 0,
				query_String:'',//参数部分
				pages:1,
				limit: 10,
				ajax_finished: false,
			}
		},
		onPageScroll(e) {
			this.scrollTop = e.scrollTop;
		},
		filters: {
			ellipsis (value) {
				if (!value) return ''
				   if (value.length > 30) {
				     return value.slice(0,30) + '...'
				}
			    return value
			}
		},
		onLoad(options) {
			this.query_String = options
		 
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }				 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}			  
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	 		
			//#endif
			 
			this._get_shop() //获取店铺信息
		    this._get_product_list() //商品列表	
		},
		methods: {
			//#ifdef H5
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },
			 async _wx_get_code(){ //微信获取code
			 	   const res_wx = await this.$AjaxRequest({
			 		url: '/get_config',
			 		method:'POST',
			 		data:{value_data:{}}
			 	   })	
			 		let urls= window.location.href
			 		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
			 		 window.location.href = auth_get_code_url
			 	},	
			//#endif
			async _get_shop () { //获取店铺信息
				const res = await this.$AjaxRequest({
					url: 'shop_find',
					method:'post',
					data:{value_data:{id: this.query_String.shop_id}}  //
				}).then((res) => {
					this.shop =  res.data 
 				}) 	 
			},
			async _get_product_list(){ //获取商品列表
			 	if(this.ajax_finished == false){
			 		 const res = await this.$AjaxRequest_product({
			 				url: 'product_select',
			 				method:'post',    
			 				data:{'value_data':{'type':'nor','shop_id':this.query_String.shop_id,'limit':this.limit,'pages':this.pages}}  //
			 		})
 					this.pro_pull_list = this.pro_pull_list.concat(res.data);//追加数据 
			 			if(res.data.length < this.limit){
			 				this.ajax_finished = true
			 			}else{
			 				this.pages +=1
			 				this.ajax_finished = false
			 		}
			 	}					 				
			},	
			cate_change(index){ //Tab切换
				this.current_cate = index
 				 if(index == 0){ //销量高
				 	this.pro_pull_list =   this.pro_pull_list
				 }else if(index == 1){ //价格低
				 	this.pro_pull_list = this.pro_pull_list.sort(this._sortBy('sales_num',true))  //false 降序   true   升序
				 }else if(index == 2){ //收藏高
				 	this.pro_pull_list =   this.pro_pull_list.sort(this._sortBy('retail_price',false))  //false 降序   true   升序
				 }else if(index == 3){ //收藏高
				 	this.pro_pull_list =   this.pro_pull_list.sort(this._sortBy('fav_num',false))  //false 降序   true   升序
				 }
				uni.pageScrollTo({
				 	scrollTop: 0,
				}); 
			},
			_sortBy(attr,rev){
					//第二个参数没有传递 默认升序排列
					if(rev ==  undefined){
						rev = 1;
					}else{  rev = (rev) ? 1 : -1;    }
						return function(a,b){
					 a = parseInt(a[attr]);
						b = parseInt(b[attr]);
			 			if(a < b){  return rev * -1;         }
						if(a > b){     return rev * 1;        }
						 return 0;
					}
			},	
			show_produt(item){ //商品详情
				uni.navigateTo({
				   url: '/pages/product/product_show?id='+item.id+'&shop_id='+item.shop_id
				})
			},
			
			
			
		}
	}
</script>

<style>
  .bg_header{width:100%;height: 360rpx;position: relative;color:#FFFFFF;}
  .bg_header::before{content: "";position: absolute;left: 0;right: 0;bottom: 0;top: 0;background-color: rgba(0, 0, 0,0);}
  .top_body{position:absolute;z-index: 999;width: 100%;}
  /* .shop_pic{width: 30%;height: 360rpx;float: left;background-color: #007AFF;}    
  .shop_item{width: 70%;height: 360rpx;float: right;background-color: #19BE6B;} */
  
  .tab_item{width: 100%;height: auto;border: #19BE6B;}
  
  .pro_box{background-color: #f4f4f5;}
  .pro_box  li{width: 100%;height:210rpx;border-bottom: 2rpx #f5f5f5 solid;margin-top:6rpx;background: white;padding-top: 10rpx;}
  .clear{clear: both;}
  .pro_box  li  .prolist_left{ width: 25%;height: 210rpx; float: left;padding-left:1%;padding-right:1%;text-align: center;}
  .pro_box li  .prolist_left  img{width: 100%;height: auto;margin-top:10rpx;}
  .pro_box li  .prolist_right{ width: 69%;height: 210rpx;float: right;padding-right: 2%;padding-left: 1%; }
  .pro_box  li  .prolist_right  .prolist_r_title{width: 100%;height: 80rpx;line-height: 40rpx;font-size: 28rpx;color:#333;text-overflow: -o-ellipsis-lastline;
    overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
  	.pro_box  li  .prolist_right   .prolist_r_tit{width: 100%;height: 60rpx;line-height: 60rpx;color:#999;font-size:24rpx;}
  .pro_box  li  .prolist_right    .prolist_r_end{font-size:40rpx;width: 100%;height: 70rpx;color:#ff0000;font-weight: 700;}
  .rec_cosprice{font-size: 24rpx;color:#9e9e9e;text-decoration:line-through;font-weight: normal;margin-left: 20rpx;}
    
  .buy_ico{width:46rpx;height: 46rpx;text-align: center;float: right;}
 </style>
