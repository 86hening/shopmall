<template>
	<view>
		<u-navbar back-text="返回" :is-back="false" :title="shop_info.shop_name"></u-navbar>
			
        <view class="cbox"><img :src="shop_info.shop_pic"></view>
		<view class="ctitle">{{staff_info.real_name}}</view>
        <view class="ctip"><u-icon name="kefu-ermai" size="26"></u-icon> 有问题请及时联系管理员咨询！</view>


        <view class="cbtn" @click="bind_hex()"><u-icon name="checkmark-circle" size="26"></u-icon>立即绑定</view>
 		
		<u-toast ref="uToast" />
	</view>
</template>

<script>
	export default {
		data() {
			return {
				shop_info:'',
				staff_info:'',
 			}
		},
		onLoad(options){
			console.log(options.ids)
			//微信公众号
			
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     } 				 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    } 	 		 
			 }			  
			//#endif
		 
			
			this._get_shop(options.shop_id);
			this._get_staff(options.ids);
		},
		methods: {
			//#ifdef H5
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },
			 async _wx_get_code(){ //微信公众号获取code
					const res_wx = await this.$AjaxRequest({
						url: '/get_config',
						method:'POST',
						data:{value_data:{}}
					})			 
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					window.location.href = auth_get_code_url
			},		     	  
			//#endif     
			async _get_shop(shop_id){ //获取商铺
				const res = await this.$AjaxRequest_product({
					url: 'get_shop',
					method:'post',
					data:{value_data:{'id':shop_id}}  //
				}).then((res) => {
					if(res.sta == 'success'){						
						this.shop_info = res.data
					}else{
						this.$refs.uToast.show({
						    title: '店铺获取异常！',	
							isTab:true,						
 							url: '/pages/index/index',							 
						})
					}
				}) 				
			}, 
			async _get_staff(staff_id){ //获取专员信息
				const res = await this.$AjaxRequest_product({
					url: 'get_staff',
					method:'post',
					data:{value_data:{'id':staff_id}}  //
				}).then((res) => {
					if(res.sta == 'success'){						
						this.staff_info = res.data
					}else{
						this.$refs.uToast.show({
						    title: '核销信息获取异常！',	
							isTab:true,						
							url: '/pages/index/index',							 
						})
					}
				}) 				
			},
			bind_hex(){ //绑定操作	
 				//#ifdef H5
				let value
				if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
					value = {'service_id':this.staff_info.id,'wx_openid':this.$store.getters.get_wx_user.openid,'avatar':this.$store.getters.get_wx_user.headimgurl,'nickname':this.$store.getters.get_wx_user.nickname}		 
				}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
					 value = {'service_id':this.staff_info.id,'ali_openid':this.$store.getters.get_ali_user.user_id,'avatar':this.$store.getters.get_ali_user.avatar,'nickname':this.$store.getters.get_ali_user.nick_name}					 			 
				}				 
				const res =  this.$AjaxRequest({
					url: 'service_bind',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {
					if(res.sta == 'success'){						
						this.$refs.uToast.show({
						    title: '绑定成功！',	
							isTab:true,						
							url: '/pages/index/index',							 
						})
					}else{
						this.$refs.uToast.show({
						    title: '绑定失败！',	
							//isTab:true,						
							//url: '/pages/index/index',							 
						})
					}
				}) 		
				 
				//#endif
				  
			},
		}
	}
</script>

<style  scoped>
.body{background: white;width:100%;height: 100%;position: absolute;bottom:0;}
    .cbox{width: 100%;height: 30%;text-align:center;padding-top:100rpx;}

    .cbox img{ width:180rpx;height: 180rpx;}
    .ctitle{width: 100%;height: 70rpx;line-height: 70rpx;text-align: center;font-weight: 700;font-size: 50rpx;color:#333;}

       .cctn{width: 45%;height: 35px;color:#fff;background: #FFCC00;text-align: center;line-height: 70rpx;margin:0 auto;border-radius: 360rpx;margin-top:20rpx;font-size: 28rpx;}
      .cctn  i{top:4rpx;margin-right: 10rpx;}

    .cbtn{width: 45%;height:70rpx;color:#fff;background: #99CCFF;text-align: center;line-height: 70rpx;margin:0 auto;border-radius: 360rpx;margin-top:100rpx;font-size:28rpx;}
   .cbtn  i{top:4rpx;margin-right:10rpx;}

    .ctip{width: 100%;height:60rpx;text-align: center;color:#999;line-height: 60rpx;font-size: 24rpx;margin-top: 60rpx;}
   .ctip i{top:4rpx;}
</style>
