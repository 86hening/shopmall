<template>
	<view>
		<view class="content">
			<!-- <u-sticky> -->
			<!-- #ifdef MP-WEIXIN -->
			<view class="header_top">
				<u-navbar back-icon-name="map" back-icon-color="#ffffff" :border-bottom="false" :back-text="loaction_address" :back-text-style="back_text_style" :background="backgroundColor" ></u-navbar>
			</view>
			<!-- #endif -->
			<!-- #ifdef H5 -->
			<u-navbar back-icon-name="map" back-icon-color="#ffffff" :border-bottom="false" :back-text="loaction_address" :background="backgroundColor2"  :back-text-style="back_text_style2" >
						<view class="slot-wrap">
							<view class="axleft">			
							</view>
						</view>
			</u-navbar>			
			<!-- #endif -->
						 
			 <view class="search_boxs">		
				 <view class="search_body">
				 <view class="search_content">
					  <u-search class="search_input" :show-action="true"  action-text="搜索" :animation="true" @custom="custom" placeholder="请输入商品关键词" v-model="keyword" @search="search"></u-search>
				 </view>
				 <view class="search_tag">
					   <u-tag text="热门搜索" shape="circle" type="info" size="mini"  mode="plain" class="s_tag" />
					   <u-tag v-if="search_key != null  &&  search_key != 'null'"  v-for="(item,index) in  search_key" :key="index" :text="item" shape="circle" type="info" @click="search_tag(item)" size="mini" :closeable='true' mode="plain" class="s_tag" />
					   <!-- <u-tag text="支付宝清空"shape="circle" type="primary" size="mini" mode="plain" class="s_tag"  @click="cccccc()" /> -->
					   <!-- <u-tag text="商家"shape="circle" type="primary" size="mini" mode="plain" class="s_tag"  @click="service_center()" /> -->
					   <!-- <u-tag text="注册"shape="circle" type="primary" size="mini" mode="plain" class="s_tag"  @click="reg()" />
					   <u-tag text="登陆"shape="circle" type="primary" size="mini" mode="plain" class="s_tag"  @click="login()" />
					   <u-tag text="密码"shape="circle" type="primary" size="mini" mode="plain" class="s_tag"  @click="forgot()" /> -->
					   <!-- <u-tag text="111"shape="circle" type="primary" size="mini" mode="plain" class="s_tag"  @click="tttt()" /> -->
					    
					   
				 </view>
				 </view>
				 <view class="clear"></view>
			</view>	 			
				<view class="menu_cate_li">	 
					<u-tabs name="tname" :list="cate_menu" active-color="#66CCFF"  :gutter="10" :duration="0.2" :is-scroll="true" :current="current" @change="change"></u-tabs>
				</view>
			<!-- </u-sticky> -->
			<view class="slide_box" >
				<u-swiper :list="slide" name="pic" height="320"  mode="round" ></u-swiper>
			</view>
			<view class="cate_img_box">
					<u-grid :col="5" :border="false">					     
							<u-grid-item v-for="(item,index) in cate_list" :key="index" >
								<u-image @click="product_list(item)" width="100rpx" height="100rpx" shape="circle" :src="item.cate_pic"></u-image>
								<view class="grid-text">{{item.tname}}</view>
							</u-grid-item>		 		
					</u-grid>
					<view class="clear"></view>
			</view>
		    
 		 
			<view class="g_thbox">
				<view class="g_thbox_left"><img   @click="fresh_url()"  :src="adv_list.left_pic"></view>
				<view class="g_thbox_right">
					<view class="g_thbox_right_top"><img @click="ys_url()" :src="adv_list.right_top_pic"></view>
					<view class="g_thbox_right_end"><img @click="act_url()" :src="adv_list.right_end_pic"></view>
				</view>
				<view class="clear"></view>
			</view>
				 
			<view class="clear"></view>			 
			<view class="pro_box">
				<view class="item_pro" v-for="(item,index) in proindex_list" :key="index">
					<u-section :title="item.tname" color="#66CCFF" @click="product_list({pid:item.id})" sub-title="更多"></u-section>
					<u-line color="#e4e7ed" margin="12rpx 0"></u-line>	
					<view class="wrap">
							<u-row gutter="16">
								 <u-col text-align="center" span="4" v-for="(item_child,index_child)  in item.prolist" :key="index_child">
									<view class="demo-layout bg-purple">
										<view class="thum_pic">
											<u-image width="96%" @click="show_produt(item_child)" mode="widthFix" height="180rpx" :src="item_child.thum"></u-image>
										</view>
										<view class="pro_title">
											{{item_child.product_name}}
										</view>	
										<view class="pro_other">
											<view class="pro_price">
												<text class="rmb_tag">￥</text>{{item_child.retail_price}}
											</view>	 
											<view class="pro_buy">
												<u-icon name="shopping-cart" @click="buy_cart(item_child)" color="#909399" size="36"></u-icon>
											</view>	
											<view class="clear"></view>
										</view>										
									</view>
								</u-col> 								 
							</u-row>							 
						</view>
				</view>
			</view>					
		   </view>		  
		  
		   <u-toast ref="uToast" />
		   <u-back-top :scroll-top="scrollTop"></u-back-top>
		   <foot_bar v-if="hackReset"></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	 //#ifdef H5
	  let jweixin = require('jweixin-module');
    //#endif	 
	export default {
		components: {
			foot_bar,
		
		 },
		data() {
			return {
 			   keyword: '',
			   cate_menu:[],//滚动分类			   
			   current: 0,
			   slide: [], //幻灯图片
			   cate_list:'',//图片分类
			   proindex_list:'',//商品列表	
			   adv_list: [], //推广位
 			   scrollTop: 0,
			   hackReset :true,
			   wx_jssdk:'',
			   wx_user_info:'',
			   loaction_address:'',
			   search_key:this.$store.getters.get_search_key,
			   backgroundColor: {background: '#66CCFF' },
			   back_text_style: {color: '#FFFFFF' },  
			   backgroundColor2 :{background: '#66CCFF' },
			   back_text_style2: {color: '#FFFFFF' },  
			   getWxapp_openid:'', //
			  
			}
		},
		onShow(){
 		     this.hackReset = false; //销毁
		      this.$nextTick(() => { //执行完再渲染
		          this.hackReset = true; 						 
		      })
			this.$store.commit('get_shop_num',this.$store.getters.Shop_nums)  
	  
 		},
		onReady() {			 
		    //this.$refs.uForm.setRules(this.rules);
		},
		onPageScroll(e) {
			this.scrollTop = e.scrollTop;
		},
		 onLoad(options) {		 
		 
 			  //微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }				 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}
			    }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				this._uni_get_location()  //支付宝使用默认uni 定位部分			 
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	 		
			//#endif
				
				
			this._get_cate_menu() //幻灯上滑动分类
			this._get_slide() //幻灯图片
			this._get_adv() //推广位
 			this._get_cate_list() //图片分类
			this._get_product_list() //循环图片列表
		 
		 },
		created() {	
 			let _that = this			
 			//#ifdef H5		
			if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				 let url_s = window.location.href.split("#")[0];  //当前url去掉#及后面所有
				 const res_wx = _that.$AjaxRequest({
				 	url: 'get_jssdk',
				 	method:'post',
				    data:{value_data:{'url':url_s}}
				 }).then((res_wx) => {
				 	 jweixin.config({
				 	    debug: false, // 开启调试模式,
				 	    appId: res_wx.data.appId, // 必填，企业号的唯一标识，此处填写企业号corpid
				 	     timestamp: res_wx.data.timestamp, // 必填，生成签名的时间戳
				 	    nonceStr: res_wx.data.nonceStr, // 必填，生成签名的随机串
				 	     signature: res_wx.data.signature,// 必填，签名，见附录1
				 	     jsApiList: [   // 必填，需要使用的JS接口列表，所有JS接口列表见附录2
				 	        'chooseWXPay',
				 	        'getLocation',
				 	        'getNetworkType',
				 	        'openLocation',
				 	        'showOptionMenu',
				 	        'closeWindow',
				 	        'scanQRCode',
				 	       ]
				 	  });
				 	   jweixin.ready(function(){
				 	     jweixin.getLocation({ //定位
				 	        type: 'wgs84', // 默认为wgs84的gps坐标，如果要返回直接给openLocation用的火星坐标，可传入'gcj02'
				 	        success: function (res_wx) {
				 				    _that._get_locations({latitude : res_wx.latitude, longitude : res_wx.longitude })			   					 				  
				 	              }
				 	          });
				 	 })					
				  }) 
			}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				//alert('支付宝端');	
				 
			}			
			//#endif   
			 //#ifdef MP-WEIXIN
			  uni.authorize({
			      scope: 'scope.userLocation',
			      success() {
			          uni.getLocation({
						  type: 'wgs84',
						      success: function (res) {			        
								  _that._get_locations({latitude : res.latitude, longitude : res.longitude })	
						      },
						      fail:function(res){  //接口调用失败的回调函数								 
								  _that.loaction_address = "地址获取失败"
							  },
							  complete:function(){
								  //console.log('调用成功')
							  },
					  })
			      } 
			   }) 
			 //#endif	
		},
		 
		mounted () {			 
			if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				 
			}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				 			 
			}
		 
 		},
		methods: { 		
			cccccc(){
				alert('清空');		 
				uni.removeStorageSync('ali_user')
			},	
			fresh_url(){
				uni.navigateTo({
				   url :'/pages3/fresh/index',
				}) 
			},			
			ys_url(){
				uni.navigateTo({
				   url :'/pages3/ys/index',
				}) 
			},
			act_url(){
				uni.navigateTo({
				   url :'/pages3/act/index',
				}) 
			},
			////////////////////////////////////////////			 			 
		     //#ifdef H5
			 async  _ali_get_code(){ //支付宝授权 获取code
			     const res =  await this.$AjaxRequest_ali({
			     	url: '/get_appid',
			     	method:'POST',
			     	data:{value_data:{'a':'0'}}
			     }).then((res) => { 			
			 			let urls= window.location.href
			 			let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
			 			window.location.href = auth_get_code_url						
			      })				  
			  },
		      async _wx_get_code(){ //微信公众号获取code
		     		const res_wx = await this.$AjaxRequest({
		     			url: '/get_config',
		     			method:'POST',
		     			data:{value_data:{}}
		     		})			 
		     		let urls= window.location.href
		     		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
		     		window.location.href = auth_get_code_url
		     },		     	  
		     //#endif     
			  /////////////////////////////////////////////
		    _uni_get_location(){
				let _that = this
		        uni.getLocation({
						type: 'wgs84',
						geocode:true,//设置该参数为true可直接获取经纬度及城市信息
						success: function (res) {	
 							const res_str =  _that.$AjaxRequest({
								url: 'get_locations',
								method:'post',
								data:{value_data:{latitude : res.latitude, longitude : res.longitude }}  //
							}).then((res_str) => {					
								if(res_str.sta == 'success'){
								     _that.loaction_address = res_str.data
								}else{
								     _that.loaction_address = '定位异常'
								}
							}) 	
 						},
						fail: function () {
							uni.showToast({
								title: '获取地址失败',
								icon:'none'
							});
						}
					});
			},
			
			act_url(){
				uni.navigateTo({
				   url: '/pages3/act/index'
				})
			},
			tg_url(){
				uni.navigateTo({
				   url: '/pages3/tg/index'
				})
			},
			ys_url(){
				uni.navigateTo({
				   url: '/pages3/ys/index'
				})
			},
			
			//跳转商品列表页面
			product_list(item=''){
				if(item != ''){
					if(item.id != undefined && item.pid != undefined){
						uni.navigateTo({
						   url: '/pages/product/product?id='+item.id+'&pid='+item.pid
						})
					}else if(item.pid != undefined){
						uni.navigateTo({
						   url: '/pages/product/product?pid='+item.pid
						})
					}else if(item.id != undefined){
						uni.navigateTo({
						   url: '/pages/product/product?id='+item.id
						})
					}
					
				}else{
					uni.navigateTo({
					    url: '/pages/product/product'
					})
				}				
			},		 
			show_produt(item){ //商品详情
 				uni.navigateTo({
				   url: '/pages/product/product_show?id='+item.id+'&shop_id='+item.shop_id
				})
			},
			search_tag(val) {//搜索标签跳转			   
			    uni.navigateTo({
			      url: '/pages/product/product?key='+val
			    })
			 },
			address(){ //跳转地址列表
				uni.navigateTo({
				   url: '/pages/users/address'
				})
			},
			reg(){ //用户注册
				uni.navigateTo({
				   url: '/pages/users/user_reg'
				})
			},
			login(){ //登陆
				uni.navigateTo({
				   url: '/pages/users/user_login'
				})
			},
			forgot(){ //找回密码
				uni.navigateTo({
				   url: '/pages/users/user_forgot'
				})
			},
			 //取货码
             qrcode_user(){
				 uni.navigateTo({
				    url: '/pages/users/qrcode_user'
				 })
             },
			 service_center(){ //商家中心 
				 uni.navigateTo({
				    url: '/pages2/service/index'
				 })
			 },
		  async _get_locations (location_Data) { //坐标位置转换位置		    
		  	const res = await this.$AjaxRequest({
		  		url: 'get_locations',
				method:'post',
				data:{value_data:location_Data}  //
		  	}).then((res) => {
				if(res.sta == 'success'){
				     this.loaction_address = res.data
				}else{
				     this.loaction_address = '定位异常'
				}
  		  	}) 	 
		  },	
		
			  _get_product_list () { //商品列表	 
				const res2 =   this.$AjaxRequest_product({
					url: 'index_loop_product',
					method:'post',
					data:{value_data:{}}  //
 				}).then((res2) => { 
 					this.proindex_list = res2.data
				})
				
			},
			async _get_cate_list () { //图片分类
				const res = await this.$AjaxRequest_product({
					url: 'category',
					method:'post',
					data:{value_data:{'is_index':1,'limit':10}}  //
				})
 				this.cate_list = res.data
			},
			async _get_cate_menu () { //幻灯上滑动分类
				const res = await this.$AjaxRequest_product({
					url: 'category',
					method:'post',
					data:{value_data:{'is_index':1}}  //
				})
				this.cate_menu = res.data
			},
			async _get_slide () { //幻灯
				const res = await this.$AjaxRequest({
					url: 'get_adv',
					method:'post',
					data:{value_data:{'c_type':0,'limit':5}}  //
				})
				this.slide = res.data
			},
			 
			async _get_adv () { //推广位
				const res = await this.$AjaxRequest({
					url: 'get_adv',
					method:'post',
					data:{value_data:{'type':'grid'}}  //
				})
				this.adv_list = res
 			},
			
			change(index) { //横向菜单
				this.current = index;		
				uni.navigateTo({
				   url: '/pages/product/product?id='+this.cate_menu[index].id+'&pid='+this.cate_menu[index].pid
				})		
			},
			buy_cart(item){   //加入购物车
			        this.$store.commit('store_shop_cart_add',item)
					this.$store.commit('get_shop_num',this.$store.getters.Shop_nums)
					this.$refs.uToast.show({
					    title: '加入成功！',
 					})		 
					this.hackReset = false; //销毁
					this.$nextTick(() => { //执行完再渲染
					     this.hackReset = true; 						 
					})
			 },
			custom(value) { //搜索
  				if(value != ''){
					 this.$store.commit('save_search_key',value)
					uni.navigateTo({
					   url: '/pages/product/product?key='+value
					})
				}else{
					this.$u.toast('请输入关键词后提交')
				}
				
			},
			search(value) {//搜索
 				if(value != ''){
					 this.$store.commit('save_search_key',value)
					uni.navigateTo({
					   url: '/pages/product/product?key='+value
					})
				}else{
					this.$u.toast('请输入关键词后提交')
				} 				 
			},	
			
			
		}
	}
</script>

<style lang="scss" scoped>
	.g_thbox_right_end img{width: 100%;height: 100%;;}
	.g_thbox_right_end{width: 370rpx;height: 240rpx;margin-top:20rpx;;}
	
	.g_thbox_right_top img{width: 100%;height: 100%;;}
	.g_thbox_right_top{width: 370rpx;height: 240rpx;}
	.g_thbox_right{width: 370rpx;height: 500rpx;float: right;margin-right: 4rpx;}
	
	.g_thbox_left img{width: 100%;height: 100%;;}
	.g_thbox_left{width: 370rpx;height: 500rpx;float:left;margin-left: 4rpx;}
	.g_thbox{width: 750rpx;height: 500rpx;margin-top:20rpx;margin-bottom: 20rpx;;}
	
	.v_banner img{width: 100%;height: auto;}
	.v_banner{width: 748rpx;height: 160rpx;background-color: red;margin:0 auto;}
	
	 .slot-wrap {display: flex;align-items: center;flex: 1;padding: 0 30rpx;}
	 .axleft{width:380rpx;}
	/* #ifndef H5 */
	.header_top_h5{width: 100%;height: 120rpx;background: #66CCFF;padding-top:60rpx;}
	.header_top_left{width: 57%;height: 60rpx;float: left;color:#fff;line-height: 60rpx;padding-left: 3%;background: #66CCFF;}
	.header_top_right{width: 37%;height: 60rpx;line-height: 60rpx;float: right;text-align: right;background: #66CCFF;}
	.account_style{margin-right: 10rpx;}
	/* #endif */
	/* #ifdef MP-WEIXIN */
	.header_top{width: 100%;height: auto;background: #66CCFF;}
   	/* #endif */
		
    .search_boxs{width: 100%;height:auto;background-color:#66CCFF;}
	.search_body{width:100%;height: auto;background: #FFFFFF;border-top-left-radius:30rpx;border-top-right-radius:30rpx;padding-top:20rpx;}
    .search_content{width: 700rpx;height: 80rpx;margin-left:25rpx;}
    .search_tag{width:700rpx;height: auto;margin-left:25rpx;padding-bottom: 16rpx;}
	.s_tag{margin-right: 10rpx;}
	.menu_cate_li{width: 96%;height: 60rpx;margin:0 auto;}
    .slide_box{width: 96%;height: 320rpx;margin: 0 auto;margin-top: 28rpx;margin-bottom:16rpx;border-radius:30rpx;overflow: hidden;}
	.cate_img_box{width: 96%;height: auto;margin: 0 auto;}
	.v_box{width: 100%;height: 120rpx;margin: 0 auto;}
	.v_box dt{width: 31.333%;height: 120rpx;float: left;margin-left: 1%;margin-right: 1%;}
	.pro_box{width: 96%;height: auto;margin: 0 auto;padding-top:10rpx;}
	.item_pro{width: 100%;height: auto;margin-bottom:30rpx;border-bottom: 10rpx #f4f4f5 solid;border-bottom-left-radius: 20rpx;border-bottom-right-radius: 20rpx;}
	.thum_pic{width: 96%;height: 180rpx;margin:0 auto;overflow: hidden;}
	.pro_title{width: 96%;height:80rpx;font-size: 26rpx;line-height: 40rpx;  color:#333333;text-overflow: -o-ellipsis-lastline;
	   overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
	.pro_other{width: 96%;height: 70rpx;margin: 0 auto;}
	.pro_price{width: 70%;height: 70rpx;font-size: 28rpx; line-height: 70rpx;font-weight: 650;color:#fa3534;float: left;}
	.rmb_tag{font-weight: normal;font-size: 24rpx;}
	
	.pro_buy{width:46rpx;height: 46rpx;float: right;border-radius: 180px;padding-top: 6rpx; text-align: center;border: 1px #909399 solid;margin-top:10rpx;}
	
	.slot-content {font-size: 28rpx;color: $u-content-color;padding-left: 30rpx;}
	.input_code{float: left;}
	.input_code_send{float: left;}
	.clear{clear: both;}
</style>
