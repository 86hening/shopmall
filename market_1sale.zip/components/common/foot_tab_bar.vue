<template>
	 <view>
		
         <u-tabbar v-model="current_tab"  active-color="#2979ff" inactive-color="#606266" :list="list" :mid-button="false"  @change="tabar_nav"></u-tabbar>		 
     </view>
</template>

<script>
	export default {
		data(){
			return {
 				list:this.$store.getters.tabr_list,
				current_tab:0,			
			}
		},	
		created() {
			//console.log(this.$store.getters.Shop_nums)
		},
		methods:{
			tabar_nav(index){ //底部导航				
				 return true				 
			},
			 
		},
	}
</script>

<style>
</style>
