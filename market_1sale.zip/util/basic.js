import Vue from 'vue'
import store from '@/store/index.js'; 
 
import { AjaxRequest } from '@/util/api.js'
import { AjaxRequest_product } from '@/util/product.js'
import { AjaxRequest_ali } from '@/util/ali.js'
let $AjaxRequest = AjaxRequest
let $AjaxRequest_product = AjaxRequest_product
let $AjaxRequest_ali = AjaxRequest_ali

 
 async function _check_reg_user(type,cate,openid){ //检测用户是否注册
	let value
	let reg_url
	 if(type == 'wx'){
		value = {'wx_openid':openid}
		reg_url = '/pages4/users/user_reg?wx_openid=' + openid
	 }else if(type == 'wxapp'){
		value = {'wxapp_openid':openid}
		reg_url = '/pages4/users/user_reg?wxapp_openid=' + openid
	 }else if(type == 'ali'){
		value = {'ali_openid':openid}
		reg_url = '/pages4/users/user_reg?ali_openid=' + openid
	 }	
	 let ajax_url
	 if(cate == 'reg'){
		ajax_url = 'check_reg_user'
	 }else if(cate == 'mobile'){
		ajax_url = 'check_user_mobile'
	 }
	 let res2 =  await $AjaxRequest({
		url: ajax_url,
		method:'post',
		data:{value_data:value}  //
	 }).then((res2) => { 
		 if(res2.sta == 'success'){ //存在用户手机注册
		 //console.log('存在用户')
		 }else{ //不存在 -- 跳转注册
			 uni.navigateTo({
			 url: reg_url
			 })
		 }
	 })
}
function _get_Wxapp_openid(){ //小程序获取用户openid
	uni.login({ //小程序登陆
	  provider: 'weixin',
	  success: function (loginRes) { //{errMsg: "login:ok", code: "041soHFa1rvhGz0pDgIa1zSrWG2soHFe"}
		if(loginRes.code != ''){
			let code = loginRes.code							 
			//获取openid				 
			 let res2 =  $AjaxRequest({
			   url: 'get_Wxapp_openid',
			   method:'post',
			   data:{value_data:{'code':code}}  //
			 }).then((res2) => { 
			    if(res2.sta == 'success'){
			     	  store.commit('save_wxapp_openid',res2.data.openid)
			     	 if(res2.is_reg_mobile == 1){ //需要手机注册
			     		 _check_reg_user('wxapp','reg',res2.data.openid); //检测用户是否注册 
			     	 }
			     	}else{
			     		console.log('openid 获取失败')
			     	}  					 
			    }) 					   
		}else{
			console.log('code为空')
		 }
	   }
	});
}
async function _get_ali_user(auth_code){ //支付宝获取用户信息
	let res =  await  $AjaxRequest_ali({
		url: '/get_userinfo',
		method:'POST',
		data:{value_data:{'auth_code':auth_code}}
	}).then((res) => {
		console.log(res)
		 if(res.sta =='success'){
			store.commit('set_ali_user',res.data) //保存vuex
			if(res.is_reg_mobile == 1){
				//需要跳转至手机注册
				 _check_reg_user('ali','reg',res.data.user_id); //检测用户是否注册 							 
			}
		 }else{
			 console.log('获取异常')
		 }						  
	}) 
}
async function _get_wx_user(codes) { //微信获取用户信息
	let res = await $AjaxRequest({
		url: 'user_login',
		method:'POST',
		data:{value_data:{'code':codes}}
	 }).then((res) => { 
		 if(res.sta == 'success'){
		      store.commit('set_wx_user',res.data) //保存vuex
		     this.wx_user_info = res.data
		       if(res.is_reg_mobile == 1){ //需要跳转注册
		     	 _check_reg_user('wx','reg',res.data.openid); //检测用户是否注册 
		       } 
		 }else{
		     console.log('用户信息获取失败')
		 }					  		 
	}) 	 
}
async function _get_wxapp_user(wxapp_openid){ //微信小程序登陆获取用户信息 
	 wx.getUserInfo({
		 success: function(res) {
			 let userInfo = res.userInfo
			  console.log(userInfo)														  
 			 store.commit('save_wxapp_user',{'wxapp_openid':wxapp_openid,'wxapp_nickname':userInfo.nickName,'wxapp_avatar':userInfo.avatarUrl})
			 //保存本地
			const res3 = $AjaxRequest({
				 url: 'update_wxapp_user',
				 method:'post',
				 data:{value_data:{'wxapp_openid':wxapp_openid,'wxapp_nickname':userInfo.nickName,'wxapp_avatar':userInfo.avatarUrl}}  //
			}).then((res3) => { 
				 console.log('保存本地成功')					  		  
			})															 									
		 },
		 fail:res=>{
			console.log(res)		 
			// 获取失败的去引导用户授权 
		 }
	 }) 
	
}
async function _ali_pay(orders_data) { //创建新订单 - 支付宝支付
  let save_res = await $AjaxRequest({
  	url: 'save_order',
  	method:'post',
  	data:{value_data:orders_data}  //
  }).then((save_res) => {
  	let  goods_strs = save_res.goods_strs	
	let  order_type = save_res.order_type	
  	if(save_res.sta == 'success'){
          /////////////////////////
		    save_res.data.return_url = 'pages/shop_cart/pay_success?goods_str='+goods_strs+'&order_type='+order_type  //pages前面无"/"
			let ali_res =  $AjaxRequest_ali({
				url: 'ali_pay',
				method:'post',
				data:{value_data:save_res.data}  //
			}).then((ali_res) => {
 				 const div = document.createElement('divform');
				 div.innerHTML= ali_res.form_str;//这个data是后端返回的form表单								
				 document.body.appendChild(div);								
				 document.forms['alipaysubmit'].submit()					 
			});		
         ////////////////////////
     }
  })
}
 function _wxapp_pay(orders_data) { //创建新订单 - 小程序支付  
  let save_res =  $AjaxRequest({
  	url: 'save_order',
  	method:'post',
  	data:{value_data:orders_data}  //
  }).then((save_res) => {
  	let  goods_strs = save_res.goods_strs
	let order_type = save_res.order_type	
  	if(save_res.sta == 'success'){				 
             /////////////////////////              
			  uni.requestPayment({
                 provider: 'wxpay',
                 timeStamp: save_res.data.timeStamp,
                 nonceStr: save_res.data.nonceStr,
                 package: save_res.data.package,
                 signType: 'MD5',
                 paySign: save_res.data.paySign,
                 success: function (res) {
             		if (res.errMsg == 'requestPayment:ok'){             		     				
							uni.navigateTo({
							   url :'/pages/shop_cart/pay_success?goods_str='+goods_strs+'&order_type='+order_type,
							})             			
             		}
                 },
                 fail: function (err) {
                     console.log('支付失败:' + err.errMsg);
                 }
             }); 			
             ////////////////////////
          } 
  }) 
}
async function _wx_pay(jweixin,orders_data) { //创建新订单 - 公众号支付
   let save_res = await $AjaxRequest({
   	url: 'save_order',
   	method:'post',
   	data:{value_data:orders_data}  //
   }).then((save_res) => {
   	let  goods_strs = save_res.goods_strs
	let order_type = save_res.order_type
   	if(save_res.sta == 'success'){		 
        /////////////////////////
       jweixin.ready(function(){
            jweixin.chooseWXPay({
                appId:save_res.data.appId,
                timestamp: save_res.data.timeStamp, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
                nonceStr: save_res.data.nonceStr, // 支付签名随机串，不长于 32
                package: save_res.data.package, // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=\*\*\*）
                signType: 'MD5', // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
                paySign: save_res.data.paySign, // 支付签名
                success: function (res) {   				 				 
					uni.navigateTo({
						url :'/pages/shop_cart/pay_success?goods_str='+goods_strs+'&order_type='+order_type,					 
					})   					 
                 },
                 cancel: function (res) {//提示引用的是mint-UI里toast
                       alert('已取消支付');
                 },
                 fail: function (res) {
                        alert('支付失败，请重试');
                   }
            })
        })
		/////////////////////
     }
   }) 
}

//预售支付尾款 -- 公众号支付
async function _final_wx_pay(jweixin,vdatas) {  
    let save_res =  await $AjaxRequest({
	 url: 'pay_other_order',
	 method:'post',
	 data:{value_data:vdatas}  //
	 }).then((save_res) => {	 
		if(save_res.sta == 'success'){
			/////////////////////////
			jweixin.ready(function(){
			    jweixin.chooseWXPay({
			        appId:save_res.data.appId,
			        timestamp: save_res.data.timeStamp, // 支付签名时间戳，注意微信jssdk中的所有使用timestamp字段均为小写。但最新版的支付后台生成签名使用的timeStamp字段名需大写其中的S字符
			        nonceStr: save_res.data.nonceStr, // 支付签名随机串，不长于 32
			        package: save_res.data.package, // 统一支付接口返回的prepay_id参数值，提交格式如：prepay_id=\*\*\*）
			        signType: 'MD5', // 签名方式，默认为'SHA1'，使用新版支付需传入'MD5'
			        paySign: save_res.data.paySign, // 支付签名
			        success: function (save_res) {
						uni.navigateTo({
							url :'/pages/shop_cart/pay_success',					 
						})						 
			        },
			        cancel: function (res) {//提示引用的是mint-UI里toast
			            alert('已取消支付');
			        },
			        fail: function (res) {
			            alert('支付失败，请重试');
			        }
			   })
			})
			////////////////////////
		}
	})	
}
//预售支付尾款 -- 支付宝支付
async function _final_ali_pay(vdatas) {  
	let save_res = await $AjaxRequest({
		url: 'pay_other_order',
		method:'post',
		data:{value_data:vdatas}  //
	}).then((save_res) => {
 		if(save_res.sta == 'success'){
	       /////////////////////////
			    save_res.data.return_url = 'pages/shop_cart/pay_success'  //pages前面无"/"
				let ali_res =  $AjaxRequest_ali({
					url: 'ali_pay',
					method:'post',
					data:{value_data:save_res.data}  //
				}).then((ali_res) => {				 
					 const div = document.createElement('divform');
					 div.innerHTML= ali_res.form_str;//这个data是后端返回的form表单								
					 document.body.appendChild(div);								
					 document.forms['alipaysubmit'].submit()					 
				});		
	       ////////////////////////
	   }
	})
}
//预售支付尾款 -- 小程序支付
async function _final_wxapp_pay(vdatas) {  
	let save_res = $AjaxRequest({
		url: 'pay_other_order',
		method:'post',
	    data:{value_data:vdatas}  //
	}).then((save_res) => {
 		if(save_res.sta == 'success'){
	           /////////////////////////
	           uni.requestPayment({
	               provider: 'wxpay',
	               timeStamp: save_res.data.timeStamp,
	               nonceStr: save_res.data.nonceStr,
	               package: save_res.data.package,
	               signType: 'MD5',
	               paySign: save_res.data.paySign,
	               success: function (res) {
	           		if (save_res.errMsg == 'requestPayment:ok'){
	           			uni.navigateTo({
	           				url :'/pages/shop_cart/pay_success',					 
	           			})
	           		}
	               },
	               fail: function (err) {
	                   console.log('支付失败:' + err.errMsg);
	               }
	           });    	   
	           ////////////////////////
	        }
	})
}


export {_check_reg_user,_get_Wxapp_openid,_get_ali_user,_get_wx_user,_wxapp_pay,_wx_pay,_get_wxapp_user,_ali_pay,_final_wx_pay,_final_ali_pay,_final_wxapp_pay}