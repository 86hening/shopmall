import Qs from 'qs'
const BASE_URL = 'https://m.1sale.cn/addons/markets/Apiali/'
export const AjaxRequest_ali = (options)=>{
	return new Promise((resolve,reject)=>{
		uni.request({
			url:BASE_URL+options.url,
			method: options.method || 'GET',
			header:{
				'Content-Type':'application/x-www-form-urlencoded;charset=UTF-8'
			},
			data: Qs.stringify(options.data) || {},
			success: (res)=>{    				
				 /* if(res.data.sta !== 'success') {
					return uni.showToast({
						//title: '获取数据为空'
					})
				} */ 
 				resolve(res.data)
			},
			fail: (err)=>{
				uni.showToast({
					 title: '请求接口失败'
				})
				reject(err)
			}
		})
	})
}