<template>
	<view>
		<u-navbar :is-back="true" back-text="返回" title="编辑地址">
			<view class="slot-wrap">
				<!-- <text @click="address_list" class="axleft" >管理地址</text> -->
			</view>
		</u-navbar>	
		<view class="content">
			 <view class="wrap">			   
			 	<view class="top">
			 		<view class="item">
			 			<view class="left">联系姓名</view>
			 			<input type="text" v-model="username" placeholder-class="line" placeholder="请填写收货人姓名" />
			 		</view>
			 		<view class="item">
			 			<view class="left">手机号码</view>
			 			<input type="text" v-model="mobile" placeholder-class="line" placeholder="请填写收货人手机号" />						 
			 		</view>
			 		<view class="item" @tap="showRegionPicker">
			 			<view class="left">所在地区</view>
			 			<input disabled type="text" v-model="area_str" placeholder-class="line" value="{area_str}"   placeholder="省市区县、乡镇等" />
						
			 		</view>
			 		<view class="item address">
			 			<view class="left">详细地址</view>
			 			<textarea type="text" v-model="address" placeholder-class="line" placeholder="街道、楼牌等" />
			 		</view>
			 		<!-- <view class="site-clipboard">
			 			<textarea placeholder-class="line" value="" placeholder="粘贴文本,可自动识别姓名和地址等" />
			 			<view class="clipboard">
			 				地址粘贴板
			 				<u-icon name="arrow-down" class="icon" :size="20"></u-icon>
			 			</view>
			 		</view> -->
			 	</view>
			 	<view class="bottom">			 		 
			 		<view class="default">
			 			<view class="left">
			 				<view class="set">设置默认地址</view>
			 				<view class="tips">提醒：每次下单会默认推荐该地址</view>
			 			</view>
			 			<view class="right"><switch color="#2979ff"  v-model="isDefault" @change="setDefault" /></view>
			 		</view>
			 	</view><!-- ["14", "1403", "140322"]  :area-code="{area_code}"-->
			 	<u-picker mode="region" ref="uPicker" v-model="show" :defaultRegion="defaultRegion"  @confirm="confirm" @cancel="cancel"/>
	
			 </view> 
			 <view >
				 <u-button class="btn" type="primary" @click="submit">立即提交</u-button>
			 </view>
			 <u-modal v-model="show_model" :show-title="false" :title-style="{color: '#606266'}" @confirm="confirm_model">
			 	<view class="slot-content">
			 		<rich-text :nodes="content" class="rich-text-style"></rich-text>
			 	</view>
			</u-modal>
		</view>
			
	</view>
</template>>

<script>
	export default {
		data() {
			return {
				wx_user_info:'', //用户信息
				addressInfo:[],//地址信息
				query_String : '',
				area_code:[],
				defaultRegion: ['广东省', '深圳市', '宝安区'],
 				show: false,
				wx_openid:'',
				wxapp_openid:'',
				id:'',
				isDefault: false,	
				area_str:'',
				username:'',
				province:'',
				city:'',
				county:'',
				area_code_str:'',
 				arr:'',
				mobile:'',
				address:'',
				areaCode:'',
				show_model:false, //弹窗确认
				content:'系统提示',
			}
		},
		onLoad(options) {
			this.query_String = options			 
			//#ifdef H5
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }	
				 this._get_address(this.$store.getters.get_wx_user.openid,this.query_String.id) //获取用户地址 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}					 
			    }else{ //登陆后检测手机状态				
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				this._get_address(this.$store.getters.get_ali_user.user_id,this.query_String.id) //获取用户地址列表 
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	
			 this._get_address(this.$store.getters.get_wxapp_openid,this.query_String.id) //获取用户地址列表
			//#endif   
		 
		},
		methods: {
			//#ifdef H5
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },
				async _wx_get_code(){ //获取code
				   const res_wx = await this.$AjaxRequest({
					url: '/get_config',
					method:'POST',
					data:{value_data:{}}
				   })	
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					 window.location.href = auth_get_code_url
				},			
			//#endif
			async _get_address (openid,id) { //获取当前地址
				//#ifdef H5
				   let value
				   if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				   		value = {'id':id,'wx_openid':openid}		 
				   	}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				   		 value = {'id':id,'ali_openid':openid}		 			 
				   }				   
				  //#endif
				//#ifdef MP-WEIXIN
				  let value = {'id':id,'wxapp_openid':openid}
				 //#endif				 				 
				const res = await this.$AjaxRequest({
					url: 'address_find',
					method:'post',
					data:{value_data:value}	
				}).then((res) => {							
				    this.addressInfo =  res.data
					this.isDefault = res.data.isDefault
					this.username = res.data.username
					this.mobile = res.data.mobile
					this.areaCode = res.data.areaCode
					this.area_str = res.data.provstr					
					this.area_code_str = res.data.area_code_str					
					this.address = res.data.address	
					this.id = res.data.id					 
					let abc = res.data.pro_city_str.split(',')	 
					 this.defaultRegion =   [abc[0],abc[1],abc[2]] 
					 this.province = abc[0]
					 this.city = abc[1]
					 this.county = abc[2]		            
				}) 	 
				
			},	
			setDefault(status) { //默认地址设置
				this.isDefault = status.detail.value 				 
			},
			showRegionPicker() {//展示选择器
				this.show = true;
			},
			confirm(e){ //选择器确认
				this.province = e.province.label
				this.city = e.city.label
				this.county = e.area.label
				this.areaCode = e.area.value
				this.area_str = e.province.label+e.city.label+e.area.label
				this.area_code_str =  e.province.value+','+e.city.value+','+e.area.value	
					 
			    console.log(this.area_code_str)	 
			},
			cancel(e){ //选择器取消
				console.log('取消操作')
				console.log(e)
			},
			submit(){ //表单提交		
				//#ifdef H5	
				    let content
					if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
						 content = {
							'id': this.id,
							'wx_openid':this.$store.getters.get_wx_user.openid, 
							'isDefault':this.isDefault, 
							'username':this.username, 
							'tel': this.mobile, 
							'areaCode':this.areaCode, 
							'area_code_str':this.area_code_str, 
							'province': this.province, 
							'city': this.city, 
							'county':this.county, 
							'addressDetail':this.address, 				
						}				 
					}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						 content = {
							'id': this.id,
							'ali_openid':this.$store.getters.get_ali_user.user_id, 
							'isDefault':this.isDefault, 
							'username':this.username, 
							'tel': this.mobile, 
							'areaCode':this.areaCode, 
							'area_code_str':this.area_code_str, 
							'province': this.province, 
							'city': this.city, 
							'county':this.county, 
							'addressDetail':this.address, 				
						}				 			 
					}		   
				  //#endif
				//#ifdef MP-WEIXIN
				  let content = {
				  	'id': this.id,
				  	'wxapp_openid':this.$store.getters.get_wxapp_openid, 
				  	'isDefault':this.isDefault, 
				  	'username':this.username, 
				  	'tel': this.mobile, 
				  	'areaCode':this.areaCode, 
				  	'area_code_str':this.area_code_str, 
				  	'province': this.province, 
				  	'city': this.city, 
				  	'county':this.county, 
				  	'addressDetail':this.address, 				
				  }			
				 //#endif	 
					
			   let res = this._save_address(content);  				
			},
			
			_save_address(content) { //保存地址	
				//#ifdef H5
				   let value 
				   if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				   		  value = {'id':content.id,'wx_openid':content.wx_openid,'isDefault':content.isDefault,'username':content.username,'tel': content.tel,'areaCode':content.areaCode,'area_code_str':content.area_code_str,'province': content.province,'city': content.city,'county':content.county,'addressDetail':content.addressDetail}		 
				   	}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				   		  value = {'id':content.id,'ali_openid':content.ali_openid,'isDefault':content.isDefault,'username':content.username,'tel': content.tel,'areaCode':content.areaCode,'area_code_str':content.area_code_str,'province': content.province,'city': content.city,'county':content.county,'addressDetail':content.addressDetail}		 			 
				   }				   
				  //#endif
				//#ifdef MP-WEIXIN
				  let value = {'id':content.id,'wxapp_openid':content.wxapp_openid,'isDefault':content.isDefault,'username':content.username,'tel': content.tel,'areaCode':content.areaCode,'area_code_str':content.area_code_str,'province': content.province,'city': content.city,'county':content.county,'addressDetail':content.addressDetail}
				 //#endif		
				const res = this.$AjaxRequest({
					url: 'address_update',
					method:'post',
					data:{value_data:value}  //
				}) .then((res) => { 				 
					if(res.sta=='success'){
					    this.content = '地址编辑成功！'
					}else{
					   this.content = '地址编辑失败！'
					}
					this.show_model = true;
									 
				}) 	 			   
			  
			},
			confirm_model(){ //弹窗确认后
				uni.navigateTo({
				    url: '/pages4/users/address'
				});
			},
			
			address_list(){ //跳转管理地址列表
				uni.navigateTo({
				    url: '/pages4/users/address'
				});
			},
			
		}
	}
</script>

<style lang="scss" scoped>
/deep/ .line {
	color: $u-light-color;
	font-size: 28rpx;
}
.rich-text-style{text-align: center;line-height: 160rpx;}
.btn{width: 90%;text-align: center;}
.slot-wrap {display: flex;align-items: right;text-align: right;flex: 1;}
 .axleft{margin-left:78%;}
.wrap {
	background-color: #f2f2f2;
	.top {
		background-color: #ffffff;
		border-top: solid 2rpx $u-border-color;
		padding: 22rpx;
		.item {
			display: flex;
			font-size: 32rpx;
			line-height: 100rpx;
			align-items: center;
			border-bottom: solid 2rpx $u-border-color;
			.left {
				width: 180rpx;
			}
			input {
				text-align: left;
			}
		}
		
		.address {
			padding: 20rpx 0;
			textarea {
				// width: 100%;
				height: 150rpx;
				background-color: #f7f7f7;
				line-height: 60rpx;
				margin: 40rpx auto;
				padding: 20rpx;
			}
		}
		.site-clipboard {
			padding-right: 40rpx;
			textarea {
				// width: 100%;
				height: 150rpx;
				background-color: #f7f7f7;
				line-height: 60rpx;
				margin: 40rpx auto;
				padding: 20rpx;
			}
			.clipboard {
				display: flex;
				justify-content: center;
				align-items: center;
				font-size: 26rpx;
				color: $u-tips-color;
				height: 80rpx;
				.icon {
					margin-top: 6rpx;
					margin-left: 10rpx;
				}
			}
		}
	}
	.bottom {
		margin-top: 20rpx;
		padding: 40rpx;
		padding-right: 0;
		background-color: #ffffff;
		font-size: 28rpx;
		.tag {
			display: flex;
			.left {
				width: 160rpx;
			}
			.right {
				display: flex;
				flex-wrap: wrap;
				.tags {
					width: 140rpx;
					padding: 16rpx 8rpx;
					border: solid 2rpx $u-border-color;
					text-align: center;
					border-radius: 50rpx;
					margin: 0 10rpx 20rpx;
					display: flex;
					font-size: 28rpx;
					align-items: center;
					justify-content: center;
					color: $u-content-color;
					line-height: 1;
				}
				.plus {
					//padding: 10rpx 0;
				}
			}
		}
		.default {
			margin-top: 50rpx;
			display: flex;
			justify-content: space-between;
			border-bottom: solid 2rpx $u-border-color;
			line-height: 64rpx;
			.tips {
				font-size: 24rpx;
			}
			.right {
			}
		}
	}
}
</style>
