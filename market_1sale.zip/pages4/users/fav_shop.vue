<template>
	<view>
		<u-navbar :is-back="true" back-text="返回" title="商铺收藏"></u-navbar>
		<view class="content">
			<markSlideList :list="shop_list" :button="buttonList" :border="true" @click="clickMethod" @change="changeMethod"></markSlideList>
			
		</view>
		<u-modal v-model="show_model" :show-title="false" :content="content" @confirm="confirm"></u-modal>
		<foot_bar></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	import markSlideList from '@/components/slide-list/shop_list.vue'
	export default {
		components: {
			foot_bar,
			markSlideList
		 },
		data() {
			return {				
				shop_list:"",
				buttonList: [
                   /* {
                        title: '分享',
                        background: '#c4c7cd'
                    }, */
                    {
                        title: '删除',
                        background: '#ff3b32'
                    }
                ],
				wx_user_info:'',
				show: false,
				show_model:false,
				content:'',
			}
		},
		created() {
		 
		},
		onLoad(options) {
			//let _that = this
			this.$store.commit('get_shop_num',this.$store.getters.Shop_nums)		 	 
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }	
				 this._get_user_fav_shop(this.$store.getters.get_wx_user.openid) //获取用户地址列表	  
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}					 
			    }else{ //登陆后检测手机状态				
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				this._get_user_fav_shop(this.$store.getters.get_ali_user.user_id) //获取用户地址列表 
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}				 
			 this._get_user_fav_shop(this.$store.getters.get_wxapp_openid) //获取用户地址列表
			//#endif			 
						 
						 
		},
		methods: {			 
			//#ifdef H5
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },
			 async _wx_get_code(){ //获取code
			 	   const res_wx = await this.$AjaxRequest({
			 		url: '/get_config',
			 		method:'POST',
			 		data:{value_data:{}}
			 	   })	
			 		let urls= window.location.href
			 		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
			 		 window.location.href = auth_get_code_url
			 	},	
			//#endif	
				
			_get_user_fav_shop(openid){ //获取商铺收藏列表
			     let _that = this
			    //#ifdef MP-WEIXIN
			       let value = {'wxapp_openid':openid}	 
			    //#endif
			    //#ifdef H5	
				   let value
					if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
						value = {'wx_openid':openid}			 
					}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						 value = {'ali_openid':openid}			 			 
					}				
				//#endif			 
				  								 
				 let res2 = _that.$AjaxRequest({
					url: 'get_user_fav_shop',
					method:'post',
					data:{value_data:value}  
				}).then((res2) => { 					 
  					 _that.shop_list = res2.data
 				}) 
				
				
				
			},
			
			confirm(){
				this.content = ""
				this.show_model = false
				this.show = false
				let page = getCurrentPages().pop(); //跳转页面成功之后
				console.log(page.$page)
				uni.navigateTo({
				    url: page.$page.fullPath
				})				 
			},
			 changeMethod(data, button, index){              			
				//#ifdef MP-WEIXIN
				  let value = {'shop_id':data.id,'wxapp_openid':this.$store.getters.get_wxapp_openid}
				//#endif
				//#ifdef H5
					let value
					if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
						 value = {'shop_id':data.id,'wx_openid':this.$store.getters.get_wx_user.openid}					 
					 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						 value = {'shop_id':data.id,'ali_openid':this.$store.getters.get_ali_user.user_id}					 			 
					}	
				//#endif
				const res =  this.$AjaxRequest({
					url: 'shop_fav',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {	
					if(res.sta == 'success'){	
						if(res.act == '1'){
				            this.content = "商铺添加收藏成功"
				            this.show_model = true;                    
				         }else{
				            this.content = "商铺取消收藏成功"
				            this.show_model = true;   
				          }
					} 
				 })				
            },
            clickMethod(data){
                //console.log('点击行回调', data)
				
            }
		}
	}
</script>

<style  scoped>

</style>
