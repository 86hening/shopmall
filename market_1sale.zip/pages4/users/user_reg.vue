<template>
	<view class="register">
		<view class="content">
	
			<!-- 头部logo -->
			<view class="header"> 
				<u-image width="170rpx" height="170rpx" shape="circle" mode="aspectFit" :src="logoImage"></u-image>
			</view>
	
			<!-- 注册input主体 -->
			<view class="main">  <!-- @blur="check_mobile()" -->
				<wInput v-model="phoneData" type="number" maxlength="11"  placeholder="请输入手机号"></wInput>			 
				<view class="codeView">
					<wInput v-model="verCode" @input="change_vercode" type="text" maxlength="4" placeholder="请输入右边验证码"></wInput>
					<view class="canvas-img-code" @click="refresh()">
						<canvas :style="{width:width+'px',height:height+'px'}" canvas-id="imgcanvas" @error="canvasIdErrorCallback"></canvas>
					</view>
				</view>
				<view class="codeView">
					<wInput  type="text" maxlength="6"  @input="change_mobile_code"   placeholder="请输入手机验证码"></wInput>
					<view class="canvas-img-code">
						<u-button size="mini" :type="code_btn_type" @click="get_codes" :disabled='code_btn_disable'  v-text="code_btn" shape="circle">点击获取验证码</u-button>
					</view>
				</view>
			</view>
			<u-toast ref="uToast" />
			<!-- 注册按钮 -->
			<!-- <wButton text="注 册" :rotate="isRotate" ></wButton> -->
 			 <view class="reg_btn"><u-button type="primary" shape="circle" @click="startReg_ac">注 册</u-button></view>
		</view>
	</view>
</template>

<script>
	let _this;
	import wInput from '@/components/common/watch-input.vue'
	import wButton from '@/components/common/watch-button.vue'
	export default {
			data() {
				return {
					logoImage: '',//logo图
					phoneData: '', // 手机号
					passData: '', //密码
					verCode: "", //验证码
					passDataAgain: "", //确认密码
					//isRotate: false, //注册按钮是否加载旋转特效
					width: 120,
					height: 40,
					mobile_Code:'',
					code_btn:'获取验证码',
					check_code_sta:false,
					second:30, //计时秒数
					code_btn_type:'default',
					code_btn_disable:true,
					config:'',//系统配置
					wx_openid:'',
					wxapp_openid:'',
					ali_openid:'',
					 
				}
			},
			components: {
				wInput,
				wButton,
			},
			created() {
				
			},
			onLoad(options) {
				//console.log(options)  
				if(options.wx_openid != undefined){
					this.wx_openid = options.wx_openid
				}else if(options.wxapp_openid != undefined){
					this.wxapp_openid = options.wxapp_openid
				}else if(options.ali_openid != undefined){
					this.ali_openid = options.ali_openid
				}		 
				this._get_config();
			},
			onShow() {
				_this = this;
				setTimeout(function() {
					_this.init();
				}, 1000)
			},
			methods: {
				async _get_config(){ //获取配置信息
					const res = await this.$AjaxRequest({
						url: 'get_config',
						method:'post',
						data:{value_data:{}}  //
					})
					this.config = res.data
					this.logoImage = res.data.logo 				
 				},
				get_codes(){ //获取验证码
					this._create_code() //创建验证码	
						console.log(uni.getStorageSync('mobile_code'))
					 this._send_mobile_code(uni.getStorageSync('mobile_code')) //发送验证码
					let  interval = setInterval(() => {
						this.code_btn_type = 'default'
						this.code_btn_disable = true
					    --this.second
						this.code_btn =  this.second+"S后获取"   
					}, 1000)
					    setTimeout(() => {
					    clearInterval(interval)  
						this.code_btn_type = 'primary'
						this.code_btn_disable = false
						this.code_btn = "获取验证码" 
						this.second = 30 //秒
						uni.removeStorageSync('mobile_code') //超时销毁验证码					
					  },this.second*1000)
					 
				},
				_send_mobile_code (mobile_code) { //执行发送短信操作
 				 	if(mobile_code != ''){						
						const res =  this.$AjaxRequest({
							url: 'send_user_mobile_code',
							method:'post',
							data:{value_data:{'mobile':this.phoneData,'codes':mobile_code}}		
						}).then((res) => {
							console.log(res)
							if(res.sta == 'success'){
								uni.showToast({
									icon: 'none',
									position: 'bottom',
									title: '验证码已发送'
								});		
							}else{
								uni.showToast({
									icon: 'none',
									position: 'bottom',
									title: '验证码发送失败'
								});		
							} 	 		 		 
						})
					}else{
						 uni.showToast({
							icon: 'none',
						    position: 'bottom',
							title: '验证码创建异常'
						});	
					} 				 
				},		
				// 初始化验证码
				_create_code() {
					var pool = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
					str = '';
					for (var i = 0; i < 6; i++) {
						var c = pool[this._math_code(0, pool.length - 1)];	
						str +=c
				     } 
					 uni.setStorageSync('mobile_code',str) //创建storage
				},
				_math_code(max, min) { //math
					return parseInt(Math.random() * (max - min)) + min;
				},
				change_vercode(e){ //监控图形验证码
				   if (this.phoneData.length != 11) { //检测手机
 				   	uni.showToast({
				   		icon: 'none',
				   		position: 'bottom',
				   		title: '手机号不正确'
				   	});
				   	return false;
				   }else{
						if(e.length == 4){ //用户输入到4位触发
							if (e.toLowerCase() != uni.getStorageSync('imgcode').toLowerCase()) {
								uni.showToast({
								 	icon: 'none',
								 	position: 'bottom',
								 	title: '验证码不正确'
								});
								this.code_btn_disable = true //关闭验证码
								this.code_btn_type = "default"
								return false;
							}else{ //验证码正确
								this.code_btn_disable = false //开启验证码
								this.code_btn_type = "primary"								
							}
						}			 
				   }					
				},	 
				 //收验证码验证
				 change_mobile_code(e){
					 if(e.length == 6){
						if(uni.getStorageSync('mobile_code') == e){ //匹配
							//console.log('自动匹配')							 
							 this.code_btn_disable = true //关闭验证码
							 this.code_btn_type = "default"
							 this.check_code_sta = true
							_this.startReg()
							
						}else{ //不匹配
						    //this.check_code_sta = false
							//console.log('不匹配')
						}
						
						uni.removeStorageSync('mobile_code') //使用过一次 销毁验证码		 
					 }
				 },
				 startReg_ac(){
 					 if(this.check_code_sta ==  true){
						 this.code_btn_disable = true //关闭验证码
						  this.code_btn_type = "default"
						 this.startReg()						
					 }else{
						 this.check_code_sta = false						
					 }		
				 },
				startReg() {	 	
					 let value = "";
					if(this.wx_openid != ''){
						let store_user = this.$store.getters.get_wx_user				 
						value = {'wx_openid':this.wx_openid,'nickname':store_user.nickname,'headimgurl':store_user.headimgurl,'mobile':this.phoneData}
					}else if(this.wxapp_openid != ''){						 
						value = {'wxapp_openid':this.wxapp_openid,'mobile':this.phoneData}
					}else if(this.ali_openid != ''){						 
						let store_user = this.$store.getters.get_ali_user
						value = {'ali_openid':this.ali_openid,'ali_nickname':store_user.nick_name,'ali_avatar':store_user.avatar,'mobile':this.phoneData}
					}	
					 const res2 =   this.$AjaxRequest({
					 	url: 'user_reg',
					 	method:'post',
					 	data:{value_data:value}  //
					 }).then((res2) => { 
					 	if(res2.sta === 'success'){ //成功					 		
							// 注册成功
							setTimeout(function() {		
								uni.showToast({
									icon: 'none',
									position: 'bottom',
									title: '注册成功'
								}); 
								//_this.isRotate = false
								uni.switchTab({
								    url: '/pages/index/index'
								})		
							}, 2000)
					 	}else{  
					 		uni.showToast({
					 			icon: 'none',
					 			position: 'bottom',
					 			title: '注册失败'
					 		}); 
					 	}
					 }) 
					 this.check_code_sta = false
				},				 
				// 初始化验证码
				init() {
					var context = uni.createCanvasContext('imgcanvas', this),
						w = this.width,
						h = this.height;
					context.setFillStyle("white");
					context.setLineWidth(5);
					context.fillRect(0, 0, w, h);
					var pool = ["A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "I", "M", "N", "O", "P", "Q", "R", "S",
							"T", "U", "V", "W", "S", "Y", "Z", "1", "2", "3", "4", "5", "6", "7", "8", "9", "0"
						],
						str = '';
					for (var i = 0; i < 4; i++) {
						var c = pool[this.rn(0, pool.length - 1)];
						var deg = this.rn(-30, 30);
						context.setFontSize(18);
						context.setTextBaseline("top");
						context.setFillStyle(this.rc(80, 150));
						context.save();
						context.translate(30 * i + 15, parseInt(h / 1.5));
						context.rotate(deg * Math.PI / 180);
						context.fillText(c, -15 + 5, -15);
						context.restore();
						str += c;
					}
					uni.setStorage({
						key: 'imgcode',
						data: str,
					});
					for (var i = 0; i < 40; i++) {
						context.beginPath();
						context.arc(this.rn(0, w), this.rn(0, h), 1, 0, 2 * Math.PI);
						context.closePath();
						context.setFillStyle(this.rc(150, 200));
						context.fill();
					}
					context.draw(); 
				},				
				rc(min, max) {
					var r = this.rn(min, max);
					var g = this.rn(min, max);
					var b = this.rn(min, max);
					return "rgb(" + r + "," + g + "," + b + ")";
				},
				rn(max, min) {
					return parseInt(Math.random() * (max - min)) + min;
				},
				refresh() {
					this.init();
				},
				canvasIdErrorCallback(e) {
					console.error(e.detail.errMsg)
				}
			}
		}
	</script>
	
	<style>
		@import url("~@/static/css/icon.css");
		@import url("~@/static/css/main.css");
	    .reg_btn{width: 70%;height: auto;margin:0 auto;margin-top:80rpx;}
		.codeView {
			display: flex;
			flex-direction: row;
			align-items: center;
			justify-content: center;
		}
	
		.canvas-img-code {
			display: inline-block;
		}
	</style>
	
