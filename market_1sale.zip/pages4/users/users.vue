<template>
	<view>
		<u-navbar :is-back="false" title="　" :border-bottom="false">
			<view class="u-flex u-row-right" style="width: 100%;">
				<view class="camera u-flex u-row-center">
					<u-icon name="camera-fill" color="#000000" size="48"></u-icon>
				</view>
			</view>
		</u-navbar>
		<view class="u-flex user-box u-p-l-30 u-p-r-20 u-p-b-30">
			<view class="u-m-r-10">
				<!-- #ifdef H5 -->
				<u-avatar v-if="this.$store.getters.get_wx_user != ''  " :src="wx_user_info.headimgurl" size="140"></u-avatar>
				<u-avatar v-else-if="this.$store.getters.get_ali_user != ''  " :src="wx_user_info.avatar" size="140"></u-avatar>
				<!-- #endif -->
				<!-- #ifdef MP-WEIXIN -->
				<u-avatar v-if="wxapp_user_info != '' || wxapp_user_info !=undefined " :src="wxapp_user_info.wxapp_avatar" size="140"></u-avatar>
				<!-- #endif -->
			</view>
			<view class="u-flex-1">
				<!-- #ifdef H5 -->
				<view v-if="this.$store.getters.get_wx_user != ''  " class="u-font-18 u-p-b-20">{{wx_user_info.nickname}}</view>
				<view v-if="this.$store.getters.get_ali_user != ''  " class="u-font-18 u-p-b-20">{{wx_user_info.nick_name}}</view>
				 <!-- view class="u-font-12 u-tips-color">{{wx_user_info.mobile}}</view> -->
				<!-- #endif -->
				<!-- #ifdef MP-WEIXIN -->
				<u-button size="mini" v-if="this.$store.getters.get_wxapp_user == '' ||  this.$store.getters.get_wxapp_user == 'undefined' "   @getuserinfo="wxapp_login" open-type="getUserInfo" type="primary" shape="circle">立即登陆</u-button>
				<view v-if="wxapp_user_info.wxapp_nickname != '' " class="u-font-18 u-p-b-20">{{wxapp_user_info.wxapp_nickname}}</view>
				<!-- #endif -->
			</view>
			<view class="u-m-l-10 u-p-10">
				<u-icon name="scan" color="#969799" size="28"></u-icon>
			</view>
			<view class="u-m-l-10 u-p-10">
				<u-icon name="arrow-right" color="#969799" size="28"></u-icon>
			</view>
		</view>
		
		<view class="u-m-t-20">
			<u-cell-group>
				<!-- #ifdef H5 -->
				<u-cell-item icon="account-fill" title="我的取货码"  @click="qrcode_user()"></u-cell-item>
				<!-- #endif -->
				<u-cell-item icon="rmb-circle" title="我的订单"  @click="my_order()"></u-cell-item>
			</u-cell-group>
		</view>
		
		<view class="u-m-t-20">
			<u-cell-group>
				<u-cell-item icon="map" title="地址管理"  @click="user_address()"></u-cell-item>
				<u-cell-item icon="star" title="收藏商铺" @click="fav_shop()"></u-cell-item>
				<u-cell-item icon="heart" title="关注商品"@click="fav_goods()"></u-cell-item>
				<!-- <u-cell-item icon="photo" title="相册"></u-cell-item> -->
				<u-cell-item icon="coupon" title="我的卡券" @click="user_coupon()"></u-cell-item>
				
			</u-cell-group>
		</view>
		
		<view v-if="is_service == true " class="u-m-t-20">
			<u-cell-group>
				<u-cell-item icon="setting" title="核销中心" @click="service_center()"></u-cell-item>
			</u-cell-group>
		</view>
		
		<view class="u-m-t-20">
			<u-cell-group>
				<!-- <u-cell-item icon="setting" title="我的资料" @click="user_info()"></u-cell-item> -->
			</u-cell-group>
		</view>
		<u-toast ref="uToast" />
		<foot_bar></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	export default {
		components: {
			foot_bar
		 },
		 data(){
			 return {
 				 show:true,
				 wx_user_info:'',
				 wxapp_user_info:'',
				 is_service:false,
			 }
		 },
		 onLoad(options) {
			 //微信公众号
			  //#ifdef H5 
			  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			 	 if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			 		if(options.code == null || options.code === ''){			     		 
			 				 this._wx_get_code()  //本页面方法 	 
			 		}else{
			 			this.$Basic._get_wx_user(options.code)  //获取用户信息
			 		}
			 	 }else{ //登陆后检测手机状态					
			 		this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
			 	 }	
			 	 
			  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			 	if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			 		if(options.auth_code == null || options.auth_code === ''){			     
			 				 this._ali_get_code() //本页面方法 	 
			 		}else{
			 			this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			 		}					 
			 	}else{ //登陆后检测手机状态				
			 		this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
			 	}	
			 	 
			  }			  
			 //#endif
			 //#ifdef MP-WEIXIN
			 //检测小程序是否有openid缓存
			 if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
			 	 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			 }else{ //登陆后检测手机状态					
			 	this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			 }			 
			 //#endif
			 //头像与昵称展示
			 //#ifdef MP-WEIXIN
				if(this.$store.getters.get_wxapp_user != ""){ //
					this.wxapp_user_info = this.$store.getters.get_wxapp_user
				}
			 //#endif 
			 //#ifdef H5 
				 if(/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端	
				    this.wx_user_info  = this.$store.getters.get_wx_user	
					//当前用户是否核销员
					this._check_service() 						
				 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端		
					this.wx_user_info  = this.$store.getters.get_ali_user	
					//当前用户是否核销员
					this._check_service() 											 
				 }
			  //#endif			
		 },	
		 onShow() {
		  //#ifdef MP-WEIXIN
		  	 if(this.$store.getters.get_wxapp_user != ""){ //
		  		 this.wxapp_user_info = this.$store.getters.get_wxapp_user
		  	  }
		  //#endif 
		  //uni.removeStorageSync('redirect')
		 },
		 methods:{
			 wxapp_login(){		
				this.$Basic._get_wxapp_user(this.$store.getters.get_wxapp_openid)		 
			 },
			 async _check_service(){
				 let _that = this
				 let value
				 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				 	value = {'wx_openid':_that.$store.getters.get_wx_user.openid}			 
				 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				 	value = {'ali_openid':_that.$store.getters.get_ali_user.user_id}			 			 
				 }
				const res = await _that.$AjaxRequest({
					url: 'service_find',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {
					 if(res.sta == 'success'){
 					    _that.is_service = true
					 }else{
						_that.is_service = false
					 }	 
				}) 
			 },
			service_center(){ //商家中心
				uni.navigateTo({
					url: '/pages2/service/index'
				})
			},					  
			 my_order(){ //订单列表
				 uni.switchTab({
				     url: '/pages/orders/orders'
				 }); 
			 },
			 fav_shop(){ //商铺收藏
				uni.navigateTo({
				    url: '/pages4/users/fav_shop'
				}); 
			 },
			 //取货码
			 qrcode_user(){
			 	uni.navigateTo({
			 		url: '/pages4/users/qrcode_user'
			 	})
			 },
			 fav_goods(){ //收藏商品
				uni.navigateTo({
				    url: '/pages4/users/fav_goods'
				}); 
			 },
			 //#ifdef H5			 
			 async  _ali_get_code(){ //支付宝授权 获取code
			     const res =  await this.$AjaxRequest_ali({
			     	url: '/get_appid',
			     	method:'POST',
			     	data:{value_data:{'a':'0'}}
			     }).then((res) => { 			
			 			let urls= window.location.href
			 			let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
			 			window.location.href = auth_get_code_url						
			      })				  
			  },	
			  async _wx_get_code(){ //获取code
			  	   const res_wx = await this.$AjaxRequest({
			  		url: '/get_config',
			  		method:'POST',
			  		data:{value_data:{}}
			  	   })	
			  		let urls= window.location.href
			  		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
			  		 window.location.href = auth_get_code_url
			  	},	
			 //#endif				 
			  
			 user_info(){ //跳转用户资料页
				 uni.navigateTo({
				     url: '/pages4/users/user_info'
				 });
			 },
			 user_address(){ //跳转用户地址
				uni.navigateTo({
				    url: '/pages4/users/address'
				}); 
			 },
			 user_coupon(){ //跳转用户卡券
				 uni.navigateTo({
				     url: '/pages4/users/user_coupon'
				 });
			 },
		 },
	}
</script>

<style lang="scss">
page{
	background-color: #ededed;
}

.camera{width: 54px;height: 44px;&:active{background-color: #ededed;}}
.user-box{background-color: #fff;}
</style>
