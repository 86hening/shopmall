<template>
	    <view>
		 <u-navbar :is-back="true" back-text="返回" title="我的资料"></u-navbar>
	    <view class="container_box">
			
		<view class="ui-all">
			<view class="avatar">
				<!-- #ifdef H5 -->
				<view  class="imgAvatar">
					<view class="iavatar" :style="'background: url('+avater+') no-repeat center/cover #eeeeee;'"></view>
				</view>
				<text>{{wx_user_info.nickname}}</text>	
				<!-- #endif -->
				<!-- #ifdef MP-WEIXIN -->
				<view  class="imgAvatar">
					<view class="iavatar" v-if="wxapp_user_info != '' " :style="'background: url('+wxapp_avatar+') no-repeat center/cover #eeeeee;'"></view>
				</view>
				<text v-if="wxapp_user_info != '' ">{{wxapp_user_info.wxapp_nickname}}</text>
 				<u-button size="mini" v-if="wxapp_user_info == '' " @getuserinfo="wxapp_login" open-type="getUserInfo" type="primary" shape="circle">立即登陆</u-button>
				<!-- #endif -->
			</view>
			<view class="ui-list">
				<text>姓名</text>
				<input type="text" :placeholder="value" :value="wx_user_info.real_name" @input="bindreal_name" placeholder-class="place" />
			</view>
			<view class="ui-list">
				<text>手机号</text>
				<input type="tel"  :placeholder="value" :value="wx_user_info.mobile" @blur="bindmobile"  placeholder-class="place" />
 			</view>
			<view class="ui-list">
				<text>验证码</text>
				<input type="number" :placeholder="value"  @blur="check_code" placeholder-class="place" />
				<view class="u-flex"><u-button :type="code_btn_type" size="mini" :disabled='code_btn_disable' @click="get_codes" :plain=true v-text="code_btn">获取验证码</u-button></view>
			</view>
		 
			 
			<view class="ui-list right">
				<text>生日</text>
				<picker mode="date" :value="date" @change="bindDateChange">
					<view class="picker">
						{{date}}
					</view>
				</picker>
			</view>		
			 <view class="sacbox">
 			<u-button class="save" type="primary" shape='circle'  @click="savaInfo">保 存 修 改</u-button>
			</view>		
		</view>
	  </view>
	  <u-toast ref="uToast" />
	  <foot_bar></foot_bar>
    </view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'	 
	export default {	
		components: {
			foot_bar
		 },
		data() {
			return {
				value: '请填写',			 
 				date: '请选择',
				avater: '',
 				url: '',
				real_name: '',
				mobile: '',
				headimg: '',				
				code_btn:'获取验证码',
				check_code_sta:false,
				second:60, //计时秒数
				code_btn_type:'primary',
				code_btn_disable:false,
				wx_user_info:'',
				wxapp_user_info:'',
				wxapp_avatar:'',
			}

		},
		onLoad(options) {		  
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				 if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
					if(options.code == null || options.code === ''){			     		 
							 this._wx_get_code()  //本页面方法 	 
					}else{
						this.$Basic._get_wx_user(options.code)  //获取用户信息
					}
				 }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }	
				 
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
				if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
					if(options.auth_code == null || options.auth_code === ''){			     
							 this._ali_get_code() //本页面方法 	 
					}else{
						this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
					}					 
				}else{ //登陆后检测手机状态				
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				 
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}			 
			//#endif
			
			 
				
				
				
		},
		created() {
		 
			//#ifdef MP-WEIXIN
		/* 	if(this.$store.getters.get_wxapp_user != ''){
				this.wxapp_user_info = this.$store.getters.get_wxapp_user
				this.wxapp_avatar = this.$store.getters.get_wxapp_user.wxapp_avatar	
			  
			}
			const res2 = this.$AjaxRequest({
				url: 'check_wxapp_user',
				method:'post',
				data:{value_data:{'wxapp_openid':this.$store.getters.get_wxapp_openid}}  //
			}).then((res2) => { 				 
				this.wx_user_info = res2.data	
			    this.mobile = this.wx_user_info.mobile
			}) */
			//#endif
 		},		 
		methods: {
			 //#ifdef H5		 
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },	
			 async _wx_get_code(){ //获取code
			 	   const res_wx = await this.$AjaxRequest({
			 		url: '/get_config',
			 		method:'POST',
			 		data:{value_data:{}}
			 	   })	
			 		let urls= window.location.href
			 		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
			 		 window.location.href = auth_get_code_url
			 },	
			//#endif			 
		    // 初始化验证码
		    _create_code() {
		    	var pool = ["1", "2", "3", "4", "5", "6", "7", "8", "9", "0"],
		    	str = '';
		    	for (var i = 0; i < 6; i++) {
		    		var c = pool[this._math_code(0, pool.length - 1)];	
		    		str +=c
		         } 
				 uni.setStorageSync('mobile_code',str) //创建storage
 		    },
			_math_code(max, min) { //math
				return parseInt(Math.random() * (max - min)) + min;
			},
			get_codes(){ //获取验证码
				this._create_code() //创建验证码		
				this._send_mobile_code(uni.getStorageSync('mobile_code')) //发送验证码
				let  interval = setInterval(() => {
					this.code_btn_type = 'default'
					this.code_btn_disable = true
				    --this.second
					this.code_btn =  this.second+"S后获取"   
				}, 1000)
				    setTimeout(() => {
				    clearInterval(interval)  
					this.code_btn_type = 'primary'
					this.code_btn_disable = false
					this.code_btn = "获取验证码" 
					this.second = 60 //秒
					uni.removeStorageSync('mobile_code') //超时销毁验证码					
 				  },this.second*1000)
				 
			},			 
			 _send_mobile_code (mobile_code) { //执行发送短信操作	   
 				 if(mobile_code != ''){
					 const res =  this.$AjaxRequest({
					 	url: 'send_user_mobile_code',
					 	method:'post',
					 	data:{value_data:{'mobile':this.mobile,'codes':mobile_code}}		
					 }).then((res) => {	
						 console.log(res)
					 	if(res.sta == 'success'){
					 		uni.showToast({
					 		    icon: 'none',
					 			position: 'bottom',
					 		    title: '验证码已发送'
					 		});		
					 	}else{
					 		uni.showToast({
					 		    icon: 'none',
					 			position: 'bottom',
					 		    title: '验证码发送失败'
					 		});		
					 	} 	 		 		 
					 }) 
				 }else{
					 uni.showToast({
					     icon: 'none',
					 	position: 'bottom',
					     title: '验证码创建异常'
					 });	
				 } 				 
			 },		  
			check_code(e){ //检测校验码
				if(e.detail.value.length != 6){
					uni.showToast({
						title: '验证码长度异常',
						icon: 'none',
						duration: 2000
					});
					return;
				}else{
					let codes = e.detail.value;			 
					if(codes == uni.getStorageSync('mobile_code')){					 
						this.$refs.uToast.show({
							title: '验证通过',
							type: 'default',							 
						})
						this.check_code_sta = true
						this.code_btn_disable = false
					}else{
						this.$refs.uToast.show({
							title: '验证失败！重新获取',
							type: 'default',
						})
						 
					}
					uni.removeStorageSync('mobile_code') //销毁验证码
				}
			}, 
			bindDateChange(e) {
				this.date = e.detail.value;
				
			},
			bindreal_name(e) {
				this.real_name = e.detail.value;				
			},
			bindmobile(e) {				
				if(e.detail.value.length != 11){
					uni.showToast({
						title: '手机号位数异常',
						icon: 'none',
						duration: 2000
					});
					return;
				}else{
					this.mobile = e.detail.value;
				}
				
			},	  
		 
			savaInfo() {			
				let that = this;
				let real_name = that.real_name;				 
 				let mobile = that.mobile;
 				let birthday = that.date;
 				let updata = {};
				if (!real_name) {
					uni.showToast({
						title: '请填写姓名',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				updata.real_name = real_name;				
				  //#ifdef H5
				  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				  	 updata.wx_openid = this.$store.getters.get_wx_user.openid			 
				  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				  	 updata.ali_openid = this.$store.getters.get_ali_user.user_id			 			 
				  }
				 
				  //#endif
				 //#ifdef MP-WEIXIN
				  updata.wxapp_openid = this.$store.getters.get_wxapp_openid
				 //#endif
				if (that.isPoneAvailable(mobile)) {
					updata.mobile = mobile;
				} else {
					uni.showToast({
						title: '手机号码有误，请重填',
						icon: 'none',
						duration: 2000
					});
					return;
				}
			 
				if (birthday == "0000-00-00") {
					uni.showToast({
						title: '请选择生日',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				updata.birthday = birthday;

 			   that.updata(updata);
			  
			},
			isPoneAvailable(poneInput) {
				var myreg = /^[1][3,4,5,7,8][0-9]{9}$/;
				if (!myreg.test(poneInput)) {
					return false;
				} else {
					return true;
				}
			},
			async updata(datas) {
				//传后台
				if(this.check_code_sta == true){
 					const res =  this.$AjaxRequest({
						url: 'save_user_info',
						method:'post',
						data:{value_data:datas}		
					}).then((res) => {
 						if(res.sta == "success"){				 
							this.$refs.uToast.show({
								title: '信息保存成功',
								type: 'default',
 							})	
							uni.switchTab({
							    url: '/pages4/users/users'
							  })
						}else{
							uni.showToast({
							    icon: 'none',
								position: 'bottom',
							    title: '信息保存失败',								
							});		
						} 	 		 		 
					}) 				
				}else{
					uni.showToast({
						title: '请输入手机验证码',
						icon: 'none',
						duration: 2000
					});
					return;
				}
				
			},
			 
	
		},		
		
	}
</script>

<style lang="less">
	 .sacbox{margin-top:60rpx;}
	.container_box{
		 width: 100%;
		 height: auto;
		 margin:0 auto;	 
		 
	}
	.u-flex{display: inline;}
	.ui-all {
		padding: 20rpx 40rpx;
		.avatar {
			width: 100%;
			text-align: left;
			padding: 40rpx 0;
			border-bottom: solid 1px #f2f2f2;
			position: relative;

			.imgAvatar {
				width: 140rpx;
				height: 140rpx;
				border-radius: 50%;
				display: inline-block;
				vertical-align: middle;
				overflow: hidden;

				.iavatar {
					width: 100%;
					height: 100%;
					display: block;
				}
			}

			text {
				display: inline-block;
				vertical-align: middle;
				color: #8e8e93;
				font-size: 28rpx;
				margin-left: 40rpx;
			}

			&:after {
				content: ' ';
				width: 20rpx;
				height: 20rpx;
				border-top: solid 1px #2979ff;
				border-right: solid 1px #2979ff;
				transform: rotate(45deg);
				-ms-transform: rotate(45deg);
				/* IE 9 */
				-moz-transform: rotate(45deg);
				/* Firefox */
				-webkit-transform: rotate(45deg);
				/* Safari 和 Chrome */
				-o-transform: rotate(45deg);
				position: absolute;
				top: 85rpx;
				right: 0;
			}
		}

		.ui-list {
			width: 100%;text-align: left;padding: 20rpx 0;border-bottom: solid 1px #f2f2f2;position: relative;
			text {color: #4a4a4a;font-size: 28rpx;display: inline-block;vertical-align: middle;min-width: 150rpx;}
			input {	color: #030303;font-size: 30rpx;display: inline-block;vertical-align: middle;}
			.btn_style{color: #030303;font-size: 30rpx;display: inline-block;vertical-align: middle;background: none;margin: 0;padding: 0;
				&::after{display: none;}
			}
			picker {width: 90%;color: #030303;font-size: 30rpx;display: inline-block;vertical-align: middle;position: absolute;top: 30rpx;left: 150rpx;}
			textarea {color: #030303;font-size: 30rpx;vertical-align: middle;height: 150rpx;width: 100%;margin-top: 50rpx;}
			.place {color: #999999;	font-size: 28rpx;}
		}

		.right:after {
			content: ' ';
			width: 20rpx;
			height: 20rpx;
			border-top: solid 1px #030303;
			border-right: solid 1px #030303;
			transform: rotate(45deg);
			-ms-transform: rotate(45deg);
			/* IE 9 */
			-moz-transform: rotate(45deg);
			/* Firefox */
			-webkit-transform: rotate(45deg);
			/* Safari 和 Chrome */
			-o-transform: rotate(45deg);
			position: absolute;
			top: 40rpx;
			right: 0;
		}
		
		.save {
			background: #2979ff;
			border: none;
			color: #ffffff;
			margin-top: 120rpx;
			font-size: 28rpx;
		}
	}
</style>
