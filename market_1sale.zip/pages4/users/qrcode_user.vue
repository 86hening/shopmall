<template>
	<view>
		<u-navbar back-text="首页"  back-icon-name="home" back-icon-size	="30" title="我的取货码" ></u-navbar>			
		 <view class="qr_box">
			<!-- #ifdef H5 --> 
		    <vue-qr :logoSrc="user_avatar" :text="qr_url" :size="300"></vue-qr>
			<!-- #endif -->
		 </view>
					
		<foot_bar v-if="hackReset"></foot_bar>		
	</view>
</template>

<script>	 
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	 //#ifdef H5
	import vueQr from 'vue-qr'
	//#endif
	export default {
		components: {
			foot_bar,
			 //#ifdef H5
			vueQr
			//#endif
		 },
		data() {
			return {
			  wx_user_info:'',
		      qr_url:'',	
			  hackReset :true,
			  user_avatar:'',
			}
		},
		onLoad(options){
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }				 
				this.qr_url = window.location.protocol+'//'+window.location.host+'/pages2/service/scan_user_qrcode?user_wx_openid='+this.$store.getters.get_wx_user.openid
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}					 
			    }else{ //登陆后检测手机状态				
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}
 			 }
			this.qr_url = window.location.protocol+'//'+window.location.host+'/pages2/service/scan_user_qrcode?user_ali_openid='+this.$store.getters.get_ali_user.user_id		   
			//#endif 			 
			
			//#ifdef H5
				 if(/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端	
					this.user_avatar  = this.$store.getters.get_wx_user.headimgurl														
				}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端		
					this.user_avatar  = this.$store.getters.get_ali_user.avatar		
				}
			 //#endif			
		},
		methods: {
			//#ifdef H5
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },
			 async _wx_get_code(){ //获取code
			 	   const res_wx = await this.$AjaxRequest({
			 		url: '/get_config',
			 		method:'POST',
			 		data:{value_data:{}}
			 	   })	
			 		let urls= window.location.href
			 		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
			 		 window.location.href = auth_get_code_url
			 	},	
			//#endif		
				
		}
	}
</script>

<style  scoped>
  .qr_box{width: 100%;height:auto;text-align: center;padding-top: 30%;}
</style>
