<template>
	<view>
		<u-navbar :is-back="true" back-text="返回" title="管理">
			<view class="slot-wrap">
				 <u-icon name="plus-circle-fill" @click="toAddSite" class="axleft" color="#2979ff" size="60"></u-icon>
			</view>
		</u-navbar>	
		<view class="content">
			
			<view class="mar_none10" v-if="address_list== ''"><u-empty text="当前地址为空!" mode="list"></u-empty></view>
			
		   	<view class="item" v-for="(res,index) in address_list" :key="res.id">
		   		<view class="top">
		   			<view class="name">						 
						<u-icon name="map" class="mar20" color="#2979ff" size="28"></u-icon>
						{{ res.username }}</view>
		   			<view class="phone">{{ res.mobile }}</view>
		   			<view class="tag">
						<text  v-if="res.isDefault === true " class="red">默</text>
		   				<text  v-if="res.title != '' ">{{ res.title }}</text>
		   			</view>
		   		</view>
		   		<view class="bottom">
		   			{{ res.provstr }}/{{ res.address }}
		   			<u-icon name="edit-pen" :size="40" @click="edit_address(res)"  color="#999999"></u-icon>
					<u-icon name="trash" :size="40" @click="del_address(res)" color="#999999"></u-icon>
		   		</view>
		   	</view>
			 <u-modal v-model="show_model" :show-title="false" :show-cancel-button="true" :title-style="{color: '#606266'}" @confirm="confirm_model" @cancel="cancel_model">
			  	<view class="slot-content">
			  		<rich-text :nodes="content" class="rich-text-style"></rich-text>
			  	</view>
			 </u-modal>
			 <u-toast ref="uToast" />
		</view>
		<foot_bar></foot_bar>
	</view>
</template>

<script>
	import foot_bar from '@/components/common/foot_tab_bar.vue'
	export default {
		components: {
			foot_bar
		 },
		data() {
			return {
				address_list:'', //地址列表
				wx_user_info:'', //用户信息
				show_model:false, //弹窗确认
				content:'系统提示',
				item:'',//选中的当前记录
			}
		},
		onLoad() { 
			
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }	
				 this._get_address(this.$store.getters.get_wx_user.openid) //获取用户地址列表	  
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}					 
			    }else{ //登陆后检测手机状态				
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				this._get_address(this.$store.getters.get_ali_user.user_id) //获取用户地址列表 
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	
			 this._get_address(this.$store.getters.get_wxapp_openid) //获取用户地址列表
			//#endif	 
		},
		methods: {
			//#ifdef H5
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },
				async _wx_get_code(){ //微信获取code
				   const res_wx = await this.$AjaxRequest({
					url: '/get_config',
					method:'POST',
					data:{value_data:{}}
				   })	
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					 window.location.href = auth_get_code_url
				},			
			//#endif
			 async _get_address (openid) { //获取用户地址列表
			     //#ifdef H5
				     let value
					  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
						value = {'wx_openid':openid}	 
					  }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						 value = {'ali_openid':openid}						 
					  }
			     //#endif
			     //#ifdef MP-WEIXIN
			        let value = {'wxapp_openid':openid}	
			     //#endif
			 	const res = await this.$AjaxRequest({
			 		url: 'address_select',
			 		method:'post',
			 		data:{value_data:value}							 
			 	})
			 	this.address_list = res.data
			 },
			toAddSite(){
				uni.navigateTo({
				    url: '/pages4/users/address_add'
				});
			},
				
			
			del_address(item){ //删除地址
			    this.item = item
			    this.content = '确认删除地址么！'
				this.show_model = true;					 
			},
			confirm_model(){ //删除确认
			    if(this.item.isDefault == true){
			       this.$refs.uToast.show({
			       		title: '默认地址请保留!',
			       		type: 'error',
 			       })
			   }else{				    
				     //#ifdef H5
					 let value
					  if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
					  		value = {'wx_openid':this.item.wx_openid,'id':this.item.id}		 
					  	}else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
					  	    value = {'ali_openid':this.item.ali_openid,'id':this.item.id}		 			 
					  }				      
				     //#endif
					 //#ifdef MP-WEIXIN
					   let value = {'wxapp_openid':this.item.wxapp_openid,'id':this.item.id}
					  //#endif
				   const res = this.$AjaxRequest({
				   	url: 'address_del',
				   	method:'post',
				   	data:{value_data:value}  //
				   }).then((res) => {
				   	if(res.sta=='success'){
				   	    this.$refs.uToast.show({
				   	    	title: '删除成功!',				   	    		 
							url: '/pages4/users/address'
				   	    })
				   	}else{
				   	   this.$refs.uToast.show({
				   	   		title: '删除失败!',
				   	   		type: 'error',
				   	   })
				   	}
				   	this.show_model = true;				
				   }) 		
				   
			   }				 
			},
			cancel_model(){ //取消确认
				//console.log('222')
			},
		    edit_address(item){ //跳转编辑地址			     
			      //#ifdef H5
				    if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				    	uni.navigateTo({
				    		url: '/pages4/users/address_edit?id='+item.id+'&wx_openid='+item.wx_openid
				    	});		 
				    }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
				    	uni.navigateTo({
				    		url: '/pages4/users/address_edit?id='+item.id+'&ali_openid='+item.ali_openid
				    	});		 			 
				    }					
			      //#endif
				  //#ifdef MP-WEIXIN
				     uni.navigateTo({
				         url: '/pages4/users/address_edit?id='+item.id+'&wxapp_openid='+item.wxapp_openid
				     });
				   //#endif
			},
			
			
		}
	}
</script>

<style  lang="scss" scoped>
	.mar_none10{margin-top:300rpx;}
	.rich-text-style{text-align: center;line-height: 160rpx;}
	.mar20{margin-right: 30rpx;}
	.slot-wrap {display: flex;align-items: right;text-align: right;flex: 1;}
	.axleft{margin-left:90%;}
    .item {
    	padding: 40rpx 20rpx;
    	.top {
    		display: flex;
    		font-weight: bold;
    		font-size: 34rpx;
    		.phone {
    			margin-left: 60rpx;
    		}
    		.tag {
    			display: flex;
    			font-weight: normal;
    			align-items: center;
    			text {
    				display: block;
    				width: 60rpx;
    				height: 34rpx;
    				line-height: 34rpx;
    				color: #ffffff;
    				font-size: 20rpx;
    				border-radius: 6rpx;
    				text-align: center;
    				margin-left: 30rpx;
    				background-color:rgb(49, 145, 253);
    			}
    			.red{
    				background-color:red
    			}
    		}
    	}
    	.bottom {
    		display: flex;
    		margin-top: 20rpx;
    		font-size: 28rpx;
    		justify-content: space-between;
    		color: #999999;
    	}
    }
 
</style>
