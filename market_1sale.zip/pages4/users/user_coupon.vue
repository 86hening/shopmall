<template>
	<view>
	  <u-navbar :is-back="true" back-text="返回" title="我的卡券"></u-navbar>
	<view class="u-wrap">
		 
		<!-- <view class="jingdong">
			<view class="left">
				<view class="sum">
					￥ <text class="num">100</text>
				</view>
				<view class="type">满149元可用</view>
			</view>
			<view class="right">
				<view class="top">
					<view class="title">
						<text class="tag">限品类东券</text>
						<text>仅可购买个人护理部分商品</text>
					</view>
					<view class="bottom">
						<view class="date u-line-1">2020.01.01-2020.01.31</view>
						
					</view>
				</view>
				<view class="tips">
					<view class="explain">						 
						<view class="immediate-use">立即使用</view>						 
					</view>
				</view>
			</view>
		</view> -->
		<view v-if="coupon_list == '' || coupon_list == undefined ">
			<view class="centre">
				<image src="https://cdn.uviewui.com/uview/template/taobao-order.png" mode=""></image>
				<view class="explain">
					暂无可用卡券
					<view class="tips">可以去看看有那些想买的</view>
				</view>
				<view class="btn">随便逛逛</view>
			</view>
		</view>  
		<view class="taobao" v-for="(item,index) in coupon_list" :key="index">
			<view class="title">
				<view class="left">
					<image class="buddha" :src="item.shop_pic" mode="aspectFill"></image>
					<view class="store">{{item.shop_name}}</view>
				</view>
				<view class="entrance" @click="go_shop_url(item.shop_id)">进店</view>
			</view>
			<view class="ticket">
				<view class="left">
					 
					<view class="introduce">
						<view class="top">
							￥
							<text class="big">{{item.deduct_price}}</text>
							满{{item.quota_price}}减{{item.deduct_price}}
						</view>
						<view class="type">店铺优惠券</view>
						<view class="date u-line-1">{{item.start_time2}}至{{item.end_time2}}</view>
					</view>
				</view>
				<view class="right">			
 					<view v-if="item.sta == 1" class="use immediate-use" :round="true" @click="go_shop_url(item.shop_id)">去使用</view>
					<view v-else-if="item.sta == -1 " class="use3 immediate-use" :round="true">待开始</view>
					<view v-else="item.sta == 0" class="use2 immediate-use" :round="true">已过期</view>
				</view>				
			</view>
		</view>
		
		
		
	</view>
	<foot_bar></foot_bar>
	</view>
</template>

<script>
import foot_bar from '@/components/common/foot_tab_bar.vue'
export default {
	components: {
		foot_bar
	 },	
	 data(){
		 return{
			 wx_user_info:'',
			 coupon_list:'',
		 }
	 },
	 onLoad(options) {	  
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
				 if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
					if(options.code == null || options.code === ''){			     		 
							 this._wx_get_code()  //本页面方法 	 
					}else{
						this.$Basic._get_wx_user(options.code)  //获取用户信息
					}
				 }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }	
				 this._get_coupon(this.$store.getters.get_wx_user.openid) //获取用户地址列表	  
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
				if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
					if(options.auth_code == null || options.auth_code === ''){			     
							 this._ali_get_code() //本页面方法 	 
					}else{
						this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
					}					 
				}else{ //登陆后检测手机状态				
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				this._get_coupon(this.$store.getters.get_ali_user.user_id) //获取用户地址列表 
			 }			  
			//#endif
			//#ifdef MP-WEIXIN
			//检测小程序是否有openid缓存
			if(this.$store.getters.get_wxapp_openid =="" || this.$store.getters.get_wxapp_openid == undefined){ //本地9用户信息为空，在线获取用户信息
				 this.$Basic._get_Wxapp_openid();	//小程序 获取openid
			}else{ //登陆后检测手机状态					
				this.$Basic._check_reg_user('wxapp','mobile',this.$store.getters.get_wxapp_openid)  //获取用户信息
			}	
			 this._get_coupon(this.$store.getters.get_wxapp_openid) //获取用户地址列表
			//#endif				
				
	 },	
	 created() {
		 
	 },	
	 methods:{
		 go_shop_url(shop_id){
			uni.navigateTo({
			   url: '/pages/shop/shop?shop_id='+shop_id
			}) 
		 },
		  //#ifdef H5
		  async  _ali_get_code(){ //支付宝授权 获取code
		      const res =  await this.$AjaxRequest_ali({
		      	url: '/get_appid',
		      	method:'POST',
		      	data:{value_data:{'a':'0'}}
		      }).then((res) => { 			
		  			let urls= window.location.href
		  			let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
		  			window.location.href = auth_get_code_url						
		       })				  
		   },	
		   async _wx_get_code(){ //获取code
		   	   const res_wx = await this.$AjaxRequest({
		   		url: '/get_config',
		   		method:'POST',
		   		data:{value_data:{}}
		   	   })	
		   		let urls= window.location.href
		   		let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
		   		 window.location.href = auth_get_code_url
		   	},	
		  //#endif		
		 async _get_coupon (openid) { //获取卡券列表
		    //#ifdef MP-WEIXIN
		      let value= {'wxapp_openid':openid}
		     //#endif
		     //#ifdef H5
			    let value 
			    if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			    	value =  {'wx_openid':openid}			 
			     }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
			    	value = {'ali_openid':openid}			 			 
			    }		     
		     //#endif
		 	const res = await this.$AjaxRequest({
		 		url: 'get_coupon_list',
				method:'post',
				data:{value_data:value}		
		 	}).then((res) => {
				console.log(res.data)
		 		this.coupon_list =  res.data 	 		 		 
		 	}) 	 
		 },
		 
	 },
};
</script>

<style lang="scss" scoped>
page {
	height: 100%;
	background-color: rgb(244, 244, 244);
}
.u-wrap {
	padding: 24rpx;
}

 
.jingdong {
	margin-top: 10rpx;
	width: 700rpx;
	height: auto;
	background-color: #ffffff;
	display: flex;
	.left {
		padding: 0 30rpx;
		background-color: rgb(95, 148, 224); //rgb(94, 152, 225);
		text-align: center;
		font-size: 28rpx;
		color: #ffffff;
		.sum {
			margin-top: 50rpx;
			font-weight: bold;
			font-size: 32rpx;
			.num {
				font-size: 80rpx;
			}
		}
		.type {
			margin-bottom: 50rpx;
			font-size: 24rpx;
		}
	}
	.right {
		padding: 20rpx 20rpx 0;
		font-size: 28rpx;
		.top {
			border-bottom: 2rpx dashed $u-border-color;
			.title {
				margin-right: 60rpx;
				line-height: 40rpx;
				.tag {
					padding: 4rpx 20rpx;
					background-color: rgb(73, 154, 201);
					border-radius: 20rpx;
					color: #ffffff;
					font-weight: bold;
					font-size: 24rpx;
					margin-right: 10rpx;
				}
			}
			.bottom {
				display: flex;
				margin-top: 20rpx;
				align-items: center;
				justify-content: space-between;
				margin-bottom: 10rpx;
				.date {
					font-size: 20rpx;
					flex: 1;
				}
				.immediate-use {
					height: auto;
					padding: 0 20rpx;
					font-size: 24rpx;
					border-radius: 40rpx;
					line-height: 40rpx;		 
					color: rgb(117, 142, 165);
					border: 2rpx solid rgb(117, 142, 165);					 
				}
			}
		}
		.tips {
			width: 100%;
			line-height: 50rpx;
			display: flex;
			align-items: center;
			justify-content: space-between;
			font-size: 24rpx;
			.transpond {
				margin-right: 10rpx;
			}
			.explain {
				display: flex;
				align-items: center;
			}
			.particulars {
				width: 30rpx;
				height: 30rpx;
				box-sizing: border-box;
				padding-top: 8rpx;
				border-radius: 50%;
				background-color: $u-type-info-disabled;
				text-align: center;
			}
		}
	}
}

.taobao {
	margin-top: 20rpx;
	width: 700rpx;
	background-color: white;
	padding: 30rpx 20rpx 20rpx;
	border-radius: 20rpx;
	.title {
		display: flex;
		align-items: center;
		justify-content: space-between;
		margin-bottom: 20rpx;
		font-size: 30rpx;
		.left {
			display: flex;
			align-items: center;
		}
		.store {
			font-weight: 500;
		}
		.buddha {
			width: 70rpx;
			height: 70rpx;
			border-radius: 10rpx;
			margin-right: 10rpx;
			background-color: red;
		}
		.entrance {
			color: $u-type-info;
			border: solid 2rpx $u-type-info;
			line-height: 48rpx;
			padding: 0 30rpx;
			background: none;
			border-radius: 15px;
		}
	}
	.ticket {
		display: flex;
		.left {
			width: 70%;
			padding: 30rpx 20rpx;
			background-color: rgb(255, 245, 244);
			border-radius: 20rpx;
			border-right: dashed 2rpx rgb(224, 215, 211);
			display: flex;
			.picture {
				width: 172rpx;
				border-radius: 20rpx;
			}
			.introduce {
				margin-left: 10rpx;
				.top{
					color:$u-type-warning;
					font-size: 28rpx;
					.big{
						font-size: 60rpx;
						font-weight: bold;
						margin-right: 10rpx;
					}
				}
				.type{
					font-size: 28rpx;
					color: $u-type-info-dark;
				}
				.date{
					margin-top: 10rpx;
					font-size: 20rpx;
					color: $u-type-info-dark;
				}
			}
		}
		.right {
			width: 30%;
			padding: 40rpx 20rpx;
			background-color: rgb(255, 245, 244);
			border-radius: 20rpx;
			display: flex;
			align-items: center;
			.use{
				height: auto;
				padding: 0 20rpx;
				font-size: 24rpx;
				border-radius: 40rpx;
				color: #ffffff!important;
				background-color: $u-type-warning!important;
				line-height: 40rpx;
				color: rgb(117, 142, 165);
				margin-left: 20rpx;
			}
			.use2{
				height: auto;
				padding: 0 20rpx;
				font-size: 24rpx;
				border-radius: 40rpx;
				color: #ffffff!important;
				background-color: $u-type-info!important;
				line-height: 40rpx;
				color: rgb(117, 142, 165);
				margin-left: 20rpx;
			}
			.use3{
				height: auto;
				padding: 0 20rpx;
				font-size: 24rpx;
				border-radius: 40rpx;
				color: #ffffff!important;
				background-color: $u-type-success!important;
				line-height: 40rpx;
				color: rgb(117, 142, 165);
				margin-left: 20rpx;
			}
		}
	}
}
 .centre {
	 	text-align: center;
	 	margin: 200rpx auto;
	 	font-size: 32rpx;
	 	image {
	 		width: 164rpx;
	 		height: 164rpx;
	 		border-radius: 50%;
	 		margin-bottom: 20rpx;
	 	}
	 	.tips {
	 		font-size: 24rpx;
	 		color: #999999;
	 		margin-top: 20rpx;
	 	}
	 	.btn {
	 		margin: 80rpx auto;
	 		width: 200rpx;
	 		border-radius: 32rpx;
	 		line-height: 64rpx;
	 		color: #ffffff;
	 		font-size: 26rpx;
	 		background: linear-gradient(270deg, rgba(249, 116, 90, 1) 0%, rgba(255, 158, 1, 1) 100%);
	 	}
	 }
	 .wrap {
	 	display: flex;
	 	flex-direction: column;
	 	height: calc(100vh - var(--window-top));
	 	width: 100%;
	 	padding-bottom:60rpx;
	  }
	 .swiper-box {
	 	flex: 1;
	 }
	 .swiper-item {
	 	height: 100%;
	 }
</style>
