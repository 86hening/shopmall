<template>
	<view>		 
		 <view class="content">
		     <u-subsection :list="list" :current="1" :height='100' @change="sectionChange"></u-subsection>
			 <view v-if="current == 0 "> <!--商铺订单-->
				 <view v-if="shop_order_list != '' "   class="shop_order_box">
                        <ul>
                            <li v-for="(item,index) in shop_order_list">
                                <view class="t1">
                                    <view class="t1_left"><u-icon name="grid"></u-icon> {{item.shop.shop_name}}</view>
                                    <view class="t1_right"><u-icon name="info-circle"></u-icon> 待配送</view>
                                    <view class="clear"></view>
                                </view>
                                <view class="t2">
                                      <dl>
										  <dt v-if="item.source_id== 0"><u-icon name="list"></u-icon> 订单来源：公众号订单</dt>
										  <dt v-else-if="item.source_id== 1"><u-icon name="list"></u-icon> 订单来源：小程序订单</dt>
										  <dt v-else-if="item.source_id== 2"><u-icon name="list"></u-icon> 订单来源：支付宝订单</dt>
                                          <dt><u-icon name="attach"></u-icon>订单类型：
                                              <span  v-if="item.order_type == 'nor'">常规订单</span>
                                              <span  v-else-if="item.order_type == 'act'">活动订单</span>
                                              <span  v-else-if="item.order_type == 'tg'">团购订单</span>
                                              <span  v-else-if="item.order_type == 'ys'">预售订单</span>
                                          </dt>
                                          <dt><u-icon name="clock"></u-icon> 订单时间：{{item.addtime}}</dt>                              
                                          <dt><u-icon name="map"></u-icon> 配送地址：{{item.address.address}}</dt>
                                          <dt><u-icon name="more-circle"></u-icon> 标识编码：<span class="b1">{{item.tp_code}}</span></dt>
                                       </dl>
                                </view>
                                <view class="t3">
                                    <view class="t3_btn" @click="bind_ps(item.id,item.order_type,serice_id)">
										<u-icon name="download"></u-icon> 我来配送</view>
                                    <view class="clear"></view>
                                </view>
                            </li>
                        </ul>
                  </view>
				  <u-empty v-else="" text="暂无记录" margin-top="200" mode="list"></u-empty>

			 </view>
			 <view v-else-if="current == 1 "> <!--配送订单-->
			 		<div v-if="service_order_list != '' "  class="shop_order_box">
                      <ul>
                            <li v-for="(item,index) in service_order_list">
                                <div class="t1">
                                    <div class="t1_left"><u-icon name="grid"></u-icon> {{item.shop.shop_name}}</div>
                                    <div class="t1_right"><u-icon name="info-circle"></u-icon>配送中</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="t2">
                                      <dl>
										  <dt v-if="item.source_id== 0"><u-icon name="list"></u-icon> 订单来源：公众号订单</dt>
										  <dt v-else-if="item.source_id== 1"><u-icon name="list"></u-icon> 订单来源：小程序订单</dt>
										  <dt v-else-if="item.source_id== 2"><u-icon name="list"></u-icon> 订单来源：支付宝订单</dt>
                                           <dt><u-icon name="pushpin"></u-icon>订单类型：
                                              <span  v-if="item.order_type == 'nor'">常规订单</span>
                                              <span  v-else-if="item.order_type == 'act'">活动订单</span>
                                              <span  v-else-if="item.order_type == 'tg'">团购订单</span>
                                              <span  v-else-if="item.order_type == 'ys'">预售订单</span>
                                          </dt>
                                          <dt><u-icon name="clock"></u-icon>订单时间：{{item.addtime}}</dt>                             
                                          <dt><u-icon name="man-add"></u-icon> 联系姓名：<span class="b1">{{item.address.username}}</span></dt>
                                          <dt><u-icon name="phone"></u-icon> 联系电话：<span class="b1">{{item.address.mobile}}</span></dt>
                                          <dt><u-icon name="map"></u-icon>配送地址：<span class="b1">{{item.address.address}}</span></dt>
                                          <dt v-if="item.notice === 'null'" ><u-icon name="chat"></u-icon> 备注信息：无</dt>
                                         <dt v-else ><u-icon name="chat"></u-icon> 备注信息：{{item.notice}}</dt>
                                          <dt><u-icon name="more-circle"></u-icon>标识编码：<span class="b1">{{item.tp_code}}</span></dt>
                                       </dl>
                                </div>
                                <div class="t3">
                                    <div class="t3_btn_left" @click="change_order(item.id,item.order_type,item.confirm_user)"><u-icon name="checkbox-mark"></u-icon> 确认配送</div>
                                    <div class="t3_btn_right" @click="show_order(item.order_type,item.id,item.confirm_user)"><u-icon name="file-text"></u-icon> 查看订单</div>
                                    <div class="clear"></div>
                                </div>
                            </li>
                         </ul>
                  </div>	
				  <u-empty v-else="" text="暂无记录" margin-top="200" mode="list"></u-empty>	   
			 </view>
			 <view v-else-if="current == 2 "> <!--完成订单-->
			 	 <div v-if="servoce_forder_list != ''" class="shop_order_box">
                         <ul>
                            <li v-for="(item,index) in servoce_forder_list">
                                <div class="t1">
                                    <div class="t1_left"><u-icon name="grid"></u-icon> {{item.shop.shop_name}}</div>
                                    <div class="t1_right" v-if="item.sta == 3"><u-icon name="info-circle"/> 已取消</div>
                                    <div class="t1_right" v-else><u-icon name="info-circle"></u-icon> 已完成</div>
                                    <div class="clear"></div>
                                </div>
                                <div class="t2">
                                      <dl>
                                           <dt><u-icon name="pushpin"></u-icon>订单类型：
                                              <span  v-if="item.order_type == 'nor'">常规订单</span>
                                              <span  v-else-if="item.order_type == 'act'">活动订单</span>
                                              <span  v-else-if="item.order_type == 'tg'">团购订单</span>
                                              <span  v-else-if="item.order_type == 'ys'">预售订单</span>
                                          </dt>
                                          <dt><u-icon name="clock"></u-icon>  订单时间：{{item.addtime}}</dt>                                        
                                           <dt><u-icon name="map"></u-icon> 配送地址：<span class="b1">{{item.address.address}}</span></dt>
                                          <dt v-if="item.notice === 'null'" ><u-icon name="chat"></u-icon> 备注信息：无</dt>
                                           <dt v-else ><u-icon name="chat"></u-icon> 备注信息：{{item.notice}}</dt>
                                          <dt><u-icon name="more-circle"></u-icon>标识编码：<span class="b1">{{item.tp_code}}</span></dt>
                                       </dl>
                                </div>
                                <div class="t3">
                                     <div class="t3_btn_finish"><u-icon name="checkbox-mark"></u-icon> 配送成功</div>
                                    <div class="clear"></div>
                                </div>
                            </li>
                        </ul>
                  </div>	
				  <u-empty v-else="" text="暂无记录" margin-top="200" mode="list"></u-empty>
			 </view>
			
			
		 </view>
		 
		 <u-toast ref="uToast" />
		 <u-modal v-model="show" :content="content" @confirm="confirm"></u-modal>
		 <u-modal v-model="show_ps" :show-cancel-button="true" :content="content_ps" @confirm="confirm_ps"></u-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				list: [
					{
						name: '商铺订单'
					}, 
					{
						name: '我的配送'
					}, 
					{
						name: '配送完成'
					}
				],
				show:false,
				content:'',
				current: 1,
				wx_user_info:'',  //核销人
                serice_id:'',
                shop_order_list:'',
                service_order_list:'',
                servoce_forder_list:'',
				show_ps:false,
				content_ps:'确定本单配送成功吗！',
				ps_send:'', //临时数据
			}
		},
		filters: {
			fee_file(value) {			
			        let realVal = ''
			        if (!isNaN(value) && value!== '') { 
			          let tempVal = parseFloat(value).toFixed(3)
			          realVal = tempVal.substring(0, tempVal.length - 1)
			        } else {
			          realVal = '--'
			        }
			        return realVal
			}
		},
		onLoad(options){		 
  			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     }else{ //登陆后检测手机状态					
					this.$Basic._check_reg_user('wx','mobile',this.$store.getters.get_wx_user.openid)  //获取用户信息
				 }	
				 this._get_service(this.$store.getters.get_wx_user.openid) //获取用户地址列表	  
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}					 
			    }else{ //登陆后检测手机状态				
					this.$Basic._check_reg_user('ali','mobile',this.$store.getters.get_ali_user.user_id)  //获取用户信息
				}	
				this._get_service(this.$store.getters.get_ali_user.user_id) //获取用户地址列表 
			 }			  
			//#endif
 
			
		},
		methods: {
			//#ifdef H5	
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },	
			 async _wx_get_code(){ //获取code
				   const res_wx = await this.$AjaxRequest({
					url: '/get_config',
					method:'POST',
					data:{value_data:{}}
				   })	
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					 window.location.href = auth_get_code_url
			 },	
			//#endif		
			//核销信息查询
			_get_service (openid) { //获取核销信息
			    //#ifdef H5
				     let value
					 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
						value = {'wx_openid':openid}			 
					 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
						value = {'ali_openid':openid}						 
					 }
			    //#endif			  
				const res = this.$AjaxRequest({
					url: 'service_find',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {
					 if(res.sta == 'success') { //正常
					    this.serice_id = res.data.id
					    this._get_shop_order(res.data.id,res.data.shop_id) 
					 }else{ //无权限
						this.$refs.uToast.show({
						    title: '权限异常！',
							type: 'error',
							url : '/pages2/index/index'
						}) 
					 }
				}) 	 
			},
			_get_shop_order(service_id,shop_id){ //获取订单数据
				const res = this.$AjaxRequest({
					url: 'service_order',
					method:'post',
					data:{value_data:{'service_id':service_id,'shop_id':shop_id}}  //
				}).then((res) => {
					if(res.sta == 'success'){
						console.log(res)
                        this.shop_order_list = res.shop_order
                        this.service_order_list = res.service_order
                        this.servoce_forder_list = res.service_forder					 
                     }
				})
			},
			 //拉取订单
			bind_ps(order_id,order_type,serice_id){
				const res = this.$AjaxRequest({
					url: 'order_bind_service',
					method:'post',
					data:{value_data:{'order_id': order_id,'order_type':order_type,'serice_id':serice_id}}  //
				}).then((res) => {
					if(res.sta == 'success'){
						this.show = true;
						this.content = "订单操作成功";                        		 
                    }else{
						this.show = true;
						this.content = "订单操作失败";
					}
				})							
			},	
			confirm(){//确认刷新页面
				location.reload()				
			},
			//查看订单详情
            show_order(order_type,order_id,service_id){				 
 				 uni.navigateTo({
				    url: '/pages2/service/service_show_orders?order_type='+order_type+'&order_id='+order_id+'&service_id='+service_id
				 })
              },
			  //配送成功
             change_order(order_id,order_type,service_id){
				   this.ps_send = {'order_id':order_id,'order_type':order_type,'service_id':service_id}
				   this.show_ps = true              
             },
			confirm_ps(){ //订单确认配送			 
 				this.$AjaxRequest({
					url: 'order_ps_success',
					method:'post',
					data:{value_data:this.ps_send}  //
				}).then((res) => {
					if(res.sta == 'success'){
						this.show = true;
						this.content = "订单操作成功";                        		 
				    }else{
						this.show = true;
						this.content = "订单操作失败";
					}
				})					
			},
			sectionChange(index) { //Tab切换
				this.current = index; //0商铺订单  1 我的配送  2 配送完成
					
			}
						
						
		}
	}
</script>

<style  scoped>
 .t3{width: 98%;height: 60rpx;margin:0 auto;margin-top:20rpx;margin-bottom: 20rpx;}
    .t3_btn{width: 220rpx;height: 60rpx;border:2rpx #66CCCC solid;float: right;text-align: center;line-height: 60rpx;border-radius: 360px;color:#66CCCC;}
   .t3  i{top:4rpx;}
   .b1{color:#333;font-weight:650;}
    .t3_btn_left{width: 200rpx;height: 60rpx;float:left;border:2rpx #99CCFF solid;text-align: center;line-height: 60rpx;border-radius: 360px;color:#99CCFF;margin-left:5%;font-size: 28rpx;}
    .t3_btn_right{width: 200rpx;height: 60rpx;float: right;border:2rpx #FF9900 solid;text-align: center;line-height: 60rpx;border-radius: 360px;color:#FF9900;margin-right:5%;font-size: 28rpx;}
   .t3_btn_finish{width: 200rpx;height: 60rpx;float:right;border:2rpx #CCCCCC solid;text-align: center;line-height: 60rpx;border-radius: 360px;color:#CCCCCC;margin-right:5%;font-size: 28rpx;}

    .t2{width: 98%;height: auto;line-height: 70rpx;margin:0 auto;font-size: 28rpx;margin-top:40rpx;border-bottom: 4rpx #ddd dotted;padding-bottom: 20rpx;}
    .t2 dt{width: 98%;height: 50rpx;line-height: 50rpx;margin:0 auto;color:#666;}
   .t2 i{top:4rpx;}

    .shop_order_box{width: 98%;height: auto;margin:0 auto;padding-bottom: 100rpx;}
    .shop_order_box li{margin-bottom: 40rpx;background:#FFFFFF;height: auto;border:4rpx #f5f5f5 solid;border-radius: 40rpx;border-bottom: 20rpx #f5f5f5 solid;padding: 1%;margin-top:40rpx;}
    .t1{width: 98%;height: 70rpx;line-height: 70rpx;border-bottom: 2rpx #f5f5f5 solid;margin:0 auto;font-size: 30rpx;}
  .t1  i{top:4rpx;}
  .t1_left{width: 75%;height: 70rpx;float: left;}
  .t1_right{width: 22%;height: 70rpx;float: right;}

     .body{width:100%;height: 100%;position: absolute;bottom:0px;}
    .htop{width: 100%;height: auto;}
</style>
