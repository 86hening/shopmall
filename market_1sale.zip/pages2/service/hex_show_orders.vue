<template>
	<view>
		<u-navbar :is-back="true" back-text="返回" title="订单详情"></u-navbar>	
		 <view class="htops" v-cloak>
              <view class="htops_left">
                  <view class="htops_1">
                      <span v-if="orderinfo.order_type =='act' " style="color:white">【活动单】</span>
                      <span v-else-if="orderinfo.order_type =='tg' "  style="color:white" >【团购单】</span>
                       <span v-else-if="orderinfo.order_type =='ys' " style="color:white">【预售单】</span>
                      待核销 <u-icon name="arrow-right"></u-icon></view>
                  <view class="htops_2">标识编码：{{orderinfo.tp_code}}</view>
              </view>
              <view class="htops_right" v-if="orderinfo.ps_fs == '1'"><img src="~@/static/svg/shop_ps_ico.svg"></view>
              <view class="clear"></view>
          </view>
          <view class="ht2">
			  <u-steps :list="numList" :current="2" mode="number" icon="checkmark" active-color="#2CBAF9"	></u-steps>              
          </view>

          <view class="title_b"> <u-icon name="order"></u-icon> 联系信息 </view>
           <view class="ulbox">
                 <ul>
                        <li ><u-icon name="man-add"></u-icon> 联系姓名：{{orderinfo.username}}</li>
                        <li><u-icon name="phone"></u-icon> 联系电话：{{orderinfo.mobile}}</li>
                        <li><u-icon name="map"></u-icon> 联系地址：{{orderinfo.address}}</li>
                  </ul>
          </view>
         <view class="title_b"><u-icon name="grid"></u-icon> 商品信息 </view>
          <view class="probox">
              <ul>
                   <li v-for="(item,index) in orderinfo.product">
                      <view class="pro_left"><img :src="item.pic"></view>
                      <view class="pro_right">
                          <view class="pro_title">
                              {{item.product_name}}</view>
                          <view  class="pro_price"><span class="price_font">￥{{item.sale_price | filters}}</span> <span class="fright">× {{item.buy_num}}</span></view>
                      </view>
                      <view class="clear"></view>
                  </li>

              </ul>
          </view>
              <view class="title_b"><u-icon name="rmb-circle-fill"></u-icon> 支付信息 </view>
            <view class="pric_ulbox">
                 <ul>
                     <li><u-icon name="rmb-circle"></u-icon>商品总价：<span class="price_bt">￥{{orderinfo.order_fee | filters}}</span></li>
                     <li><u-icon name="rmb-circle"></u-icon>配送费用：<span class="price_bt">￥{{orderinfo.delivery_fee | filters}}</span></li>
                     <li><u-icon name="rmb-circle"></u-icon>包装费用：<span class="price_bt">￥{{orderinfo.packag_fee | filters}}</span></li>
                     <li><u-icon name="rmb-circle"></u-icon>合计支付：<span class="price_bt">￥ {{orderinfo.order_fee | filters}}</span></li>
                 </ul>
          </view>

          <view class="btn_box">
              <view class="btn_left"  @click="$router.go(-1)"><u-icon name="arrow-left"></u-icon> 返回列表</view>
               <view class="clear"></view>
          </view>

	</view>
</template>

<script>
	export default {
		data() {
			return {
				numList: [{
					name: '买家下单'
				}, {
					name: '商家接单'
				}, {
					name: '门店自取'
				}, {
					name: '交易完成'
				}, 
				],
				 order_id:'',
                service_id:'',
                orderinfo:'',
                order_type:'',
			}
		},
		onLoad(options){
			this.order_type = options.order_type
		    this.order_id = options.order_id
		    this.service_id = options.service_id
		 
			this._get_orders(options.order_type,options.order_id,options.service_id)
		},
		filters: {
			fee_file(value) {			
			        let realVal = ''
			        if (!isNaN(value) && value!== '') { 
			          let tempVal = parseFloat(value).toFixed(3)
			          realVal = tempVal.substring(0, tempVal.length - 1)
			        } else {
			          realVal = '--'
			        }
			        return realVal
			}
		},
		methods: {
			async _get_orders (order_type,order_id,service_id) { //获取订单信息
				const res = await this.$AjaxRequest({
					url: 'order_show_service',
					method:'post',
					data:{value_data:{'order_type':order_type,'order_id':order_id,'service_id':service_id}}  //					
				}).then((res) => {
					 console.log(res)
					 this.orderinfo=res.data					 
				}) 	 
			},
		}
	}
</script>

<style  scoped>
.pric_ulbox{width: 98%;height: 140rpx;margin:0 auto;background: white;}
    .pric_ulbox  li{width: 50%;height: 70rpx;line-height: 70rpx;float: left;color:#666;}
    .price_bt{color:#ff0000;font-weight: 650;}

    .btn_box{width: 100%;height: 120rpx;margin:0 auto;padding-top:40rpx;background: white;border-top:4rpx #66CCFF solid;}
    .btn_left{width: 80%;height: 80rpx;background: #2CBAF9;border-radius: 10rpx;margin:0 auto;text-align: center;color:#ffffff;line-height:80rpx;}
    .btn_right{width: 220rpx;height: 70rpx;float:right;background: #FFCC33;border-radius: 360rpx;margin-right:5%;text-align: center;color:#ffffff;line-height:70rpx;}
 
    .probox{width: 96%;height: auto;margin:0 auto;margin-top:20rpx;}
     .probox  li{width: 98%;height: auto;margin-bottom: 20rpx;border-bottom: 2rpx #f5f5f5 solid;}
    .pro_left{width: 30%;height: 160rpx;float: left; overflow: hidden;}
    .pro_left img{width: 90%;height: 90%;margin-top:5%;}
    .pro_right{width: 69%;height: 160rpx;float: right; }
   .pro_title{width: 100%;height: 80rpx;line-height: 40rpx;font-size: 26rpx;color:#666; text-overflow: -o-ellipsis-lastline;
  overflow: hidden; text-overflow: ellipsis; display: -webkit-box; -webkit-line-clamp: 2; line-clamp: 2; -webkit-box-orient: vertical;}
 .pro_price{width: 98%;height: 60rpx;line-height: 60rpx;}
 .price_font{color:#ff0000;font-weight: 650}
 .fright{float: right;font-weight: 650}

    .ulbox{ width: 96%;height: auto;margin:0 auto; padding-top: 20rpx;background: white;}
    .ulbox  li{line-height: 60rpx;height: 60rpx;color:#999;font-size: 28rpx;}

    .title_b{width: 96%;height: 70rpx;line-height: 70rpx;margin:0 auto;margin-top:20rpx;border-bottom: 2rpx #f5f5f5 solid;font-weight:700;font-size: 14px;}
   
    .ht2{width: 96%;height: 80rpx;margin:0 auto;margin-top:20rpx;margin-bottom: 40rpx;}

    .htops{width: 100%;height:180rpx;background: #2CBAF9;}
    .htops_left {width: 70%;height: 120rpx;float: left;margin-top:20rpx;}
    .htops_right{width: 25%;height: 120rpx;float: right;text-align: center;margin-top:20rpx;}
    .htops_right  img{width: 90%;height: 90%;margin-top:5%;}

    .htops_1{width: 96%;font-size: 36rpx;line-height:70rpx;height:70rpx;margin:0 auto;color:#ffffff;}
 
     .htops_2{width: 96%;line-height:60rpx;height: 60rpx;margin:0 auto;color:#ffffff;font-size:32rpx;}
</style>
