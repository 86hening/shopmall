<template>
	<view>
		<view class="top_head">{{shop_info.shop_name}}</view>
               <view class="serv_box">
                   <view class="serv_box_left"><img :src="service_avatar"></view>
                   <view class="serv_box_right">
                         <ul>
                             <li>姓名：{{service_info.real_name}}</li>
                              <li>电话：{{service_info.mobile}}</li>
                         </ul>
                   </view>
                 <view class="clear"></view>
        </view>
		<view class="shop_order_box" v-if="order_list != '' ">
                        <ul>
                            <li  v-for="(item,index)  in order_list">
                                <view class="t1">
                                    <view class="t1_left"><u-icon name="attach"></u-icon>
                                        <text v-if="item.order_type =='act' " style="color:#FF9933">【活动单】</text>
                                         <text v-else-if="item.order_type =='tg' "  style="color:#FF6666" >【团购单】</text>
                                         <text v-else-if="item.order_type =='ys' " style="color:#FF99CC">【预售单】</text>
                                         {{item.address.username}}</view>
                                    <view class="t1_right"><u-icon name="info-circle"></u-icon> 待自取</view>
                                    <view class="clear"></view>
                                </view>
                                <view class="t2">
                                      <dl>
										  <dt v-if="item.source_id== 0"><u-icon name="list"></u-icon> 订单类型：公众号订单</dt>
										  <dt v-else-if="item.source_id== 1"><u-icon name="list"></u-icon> 订单类型：小程序订单</dt>
										  <dt v-else-if="item.source_id== 2"><u-icon name="list"></u-icon> 订单类型：支付宝订单</dt>
                                          <dt><u-icon name="clock"></u-icon> 订单时间：{{item.addtime}}</dt>                                            
                                          <dt><u-icon name="phone"></u-icon> 手机号码：{{item.address.mobile}}</dt>
                                          <dt v-if="item.notice === 'null'" ><u-icon name="grid"></u-icon> 备注信息：无</dt>
                                           <dt v-else ><u-icon name="grid"></u-icon> 备注信息：{{item.notice}}</dt>
                                          <dt><u-icon name="more-circle"></u-icon>标识编码：<b><text style='color:#1eb5f8'>{{item.tp_code}} </text></b></dt>
                                       </dl>
                                </view>
                                <view class="t3">
                                    <view class="t3_btn_left"  @click="show_order(item.order_type,item.id,item.confirm_user)"><u-icon name="file-text"></u-icon> 查看订单</view>
                                    <view class="t3_btn_right"  @click="change_order(item.id,item.order_type,service_info.id)"><u-icon name="checkbox-mark"></u-icon>立即核销</view>
                                    <view class="clear"></view>
                                </view>
                            </li>
                        </ul>
                  </view>
				  <u-empty v-else="" margin-top="200" text="暂无记录" mode="list"></u-empty>
		<u-modal v-model="show" :content="content" @confirm="confirm"></u-modal>
		<u-modal v-model="show_ps" :show-cancel-button="true" :content="content_ps" @confirm="confirm_ps"></u-modal>
	</view>
</template>

<script>
	export default {
		data() {
			return {				 
                 wx_user_info:'',  //核销人个人信息
                 service_info:'', //核销
                 shop_info: '', //商铺信息
                 order_list:'',
				 show_ps:false,
				 content_ps:'确定核销本订单吗！',
				 ps_send:'', //临时数据
				 show:false,
				 content:'',
				 service_avatar:'',
				 user_wx_openid:'',
 				 user_ali_openid:'',
			}
		},
		created() {			
			 
		},
		onLoad(options){	
			if(options.user_wx_openid != undefined || options.user_wx_openid !=''){
				this.user_wx_openid = options.user_wx_openid
			}else if(options.user_ali_openid != undefined || options.user_ali_openid !=''){
				this.user_ali_openid = options.user_ali_openid
			}			
			//微信公众号
			 //#ifdef H5 
			 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			     if(this.$store.getters.get_wx_user ==""){ //本地用户信息为空，在线获取用户信息
			     	if(options.code == null || options.code === ''){			     		 
			     			 this._wx_get_code()  //本页面方法 	 
			     	}else{
			     		this.$Basic._get_wx_user(options.code)  //获取用户信息
			     	}
			     } 
				 this.service_avatar = this.$store.getters.get_wx_user.headimgurl
				 this._get_service(this.$store.getters.get_wx_user.openid) //获取核销人信息	  
			 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端					
			    if(this.$store.getters.get_ali_user =="" || this.$store.getters.get_ali_user == undefined){ //本地9用户信息为空，在线获取用户信息					
			    	if(options.auth_code == null || options.auth_code === ''){			     
			    			 this._ali_get_code() //本页面方法 	 
			    	}else{
			    		this.$Basic._get_ali_user(options.auth_code)  //获取用户信息
			    	}					 
			    } 	
				this.service_avatar = this.$store.getters.get_ali_user.avatar
				this._get_service(this.$store.getters.get_ali_user.user_id) //获取核销人信息
			 }			  
			//#endif			 
		},
		methods: {
			 //查看订单详情
			show_order(order_type,order_id,service_id){
				uni.navigateTo({
				   url: '/pages2/service/hex_show_orders?order_type='+order_type+'&order_id='+order_id+'&service_id='+service_id
				})			
			},
			//配送成功
			 change_order(order_id,order_type,service_id){
				   this.ps_send = {'order_id':order_id,'order_type':order_type,'service_id':service_id}
				   this.show_ps = true              
			 },
			 confirm(){//确认刷新页面
			 	location.reload()				
			 },
			confirm_ps(){ //订单确认配送			 
				this.$AjaxRequest({
					url: 'order_ps_success',
					method:'post',
					data:{value_data:this.ps_send}  //
				}).then((res) => {
					if(res.sta == 'success'){
						this.show = true;
						this.content = "订单操作成功";                        		 
				    }else{
						this.show = true;
						this.content = "订单操作失败";
					}
				})					
			},
			//#ifdef H5
			async  _ali_get_code(){ //支付宝授权 获取code
			    const res =  await this.$AjaxRequest_ali({
			    	url: '/get_appid',
			    	method:'POST',
			    	data:{value_data:{'a':'0'}}
			    }).then((res) => { 			
						let urls= window.location.href
						let auth_get_code_url = "https://openauth.alipay.com/oauth2/publicAppAuthorize.htm?app_id="+res.ali_appid+"&scope=auth_user&redirect_uri="+urls+"";
						window.location.href = auth_get_code_url						
			     })				  
			 },		
				async _wx_get_code(){ //微信获取code
				   const res_wx = await this.$AjaxRequest({
					url: '/get_config',
					method:'POST',
					data:{value_data:{}}
				   })	
					let urls= window.location.href
					let auth_get_code_url =  "https://open.weixin.qq.com/connect/oauth2/authorize?appid="+res_wx.data.wx_appid+"&redirect_uri="+urls+"&response_type=code&scope=snsapi_userinfo&state=123#wechat_redirect"
					 window.location.href = auth_get_code_url
				},	
			//#endif		 
			_get_service (openid) { //获取核销信息
			   //#ifdef H5
			     let value
			   	 if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			   		value = {'wx_openid':openid}			 
			   	 }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
			   		value = {'ali_openid':openid}						 
			   	 }
			   //#endif			   
				const res = this.$AjaxRequest({
					url: 'service_find',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {
 					 if(res.sta == 'success') { //正常		
						this.service_info = res.data		
					    this._get_shop (res.data.shop_id)
					    this._get_user_order(res.data.shop_id)
					 }else{ //无权限
						this.$refs.uToast.show({
						    title: '权限异常！',
							type: 'error',
							url : '/pages/index/index'
						}) 
					 }
				}) 	 
			},
			_get_shop(shop_id){ //获取商铺信息
				const res = this.$AjaxRequest({
					url: 'shop_find',
					method:'post',
					data:{value_data:{id:shop_id}}  //
				}).then((res) => {		
 					this.shop_info = res.data					 
				}) 	 
			},
			_get_user_order(shop_id){ //获取该用户在本店铺订单
			    let value
			    if (/MicroMessenger/.test(window.navigator.userAgent)){	//微信客户端		 
			    	value = {'shop_id':shop_id,'user_wx_openid':this.$store.getters.get_wx_user.openid}		 
			    }else if (/AlipayClient/.test(window.navigator.userAgent)){  //支付宝客户端
			    	value = {'shop_id':shop_id,'user_ali_openid':this.$store.getters.get_ali_user.user_id}		 			 			 
			    }
				const res = this.$AjaxRequest({
					url: 'hex_order_list',
					method:'post',
					data:{value_data:value}  //
				}).then((res) => {	
					console.log(res)
 					this.order_list = res.data
				}) 
			},
			
			
		}
	}
</script>

<style  scoped>
 .serv_box{width: 100%;height: 120rpx;background: white;}
    .serv_box_left{width: 120rpx;height: 120rpx;float: left;text-align: center;margin-left:10rpx;margin-right: 10rpx;}
    .serv_box_left  img{width: 100rpx;height: 100rpx;border-radius: 10rpx;margin-top: 10rpx;}
    .serv_box_right{height: 120rpx;float: left;}
    .serv_box_right li{width: 100%;height: 48rpx;line-height: 48rpx;margin-top:6rpx;color:#666;}

  .top_head{width: 100%;height: 80rpx;background: white;text-align: center;line-height: 80rpx;color:#1eb5f8;border-bottom: 2rpx #f5f5f5 solid;}

    .t3{width: 98%;height: 60rpx;margin:0 auto;margin-top:20rpx;margin-bottom: 20rpx;}
    .t3_btn{width: 120rpx;height: 60rpx;border:2rpx #66CCCC solid;float: right;text-align: center;line-height: 60rpx;border-radius: 180px;color:#66CCCC;}
   .t3  i{top:4rpx;}
   .b1{color:#333;font-weight:650;}
    .t3_btn_left{width: 200rpx;height: 60rpx;float:left;border:2rpx #99CCFF solid;text-align: center;line-height: 60rpx;border-radius: 180px;color:#99CCFF;margin-left:5%;font-size: 28rpx;}
    .t3_btn_right{width: 200rpx;height: 60rpx;float: right;border:2rpx #FF9900 solid;text-align: center;line-height: 60rpx;border-radius: 180px;color:#FF9900;margin-right:5%;font-size: 28rpx;}
   .t3_btn_finish{width: 200rpx;height: 60rpx;float:right;border:2rpx #CCCCCC solid;text-align: center;line-height: 60rpx;border-radius: 180px;color:#CCCCCC;margin-right:5%;font-size: 28rpx;}

    .t2{width: 98%;height: auto;line-height: 70rpx;margin:0 auto;font-size: 28rpx;margin-top:20rpx;border-bottom: 4rpx #ddd dotted;padding-bottom: 10rpx;}
    .t2 dt{width: 98%;height: 50rpx;line-height: 50rpx;margin:0 auto;color:#666;}
   
    .shop_order_box{width: 98%;height: auto;margin:0 auto;padding-bottom: 100rpx;}
    .shop_order_box    li{margin-bottom: 20rpx;background:#FFFFFF;height: auto;border:4rpx #f5f5f5 solid;border-radius: 20rpx;border-bottom: 10rpx #f5f5f5 solid;padding: 1%;margin-top:20rpx;}
    .t1{width: 98%;height: 70rpx;line-height: 70rpx;border-bottom: 2rpx #f5f5f5 solid;margin:0 auto;font-size: 30rpx;}
   .t1_left{width: 75%;height: 70rpx;float: left;font-weight: 650;font-size: 28rpx;color:#1eb5f8;}
  .t1_right{width: 22%;height: 70rpx;float: right;}

     .body{width:100%;height: 100%;position: absolute;bottom:0px;}
</style>
